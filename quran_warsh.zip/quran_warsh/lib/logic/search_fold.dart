/// Search folding. Mirrors tools/fold.py exactly. A Dart test compares this function with the
/// folded values stored in the reference database for every ayah and surah name.
///
/// The folded text is for SEARCH ONLY. It is never displayed and never replaces Quran text.
const int _alef = 0x0627;

int? _mapped(int cp) {
  switch (cp) {
    case 0x0622:
    case 0x0623:
    case 0x0625:
    case 0x0671:
      return _alef;
    case 0x0624:
      return 0x0648;
    case 0x0626:
    case 0x0649:
    case 0x06CC:
    case 0x06D2:
      return 0x064A;
  }
  if (cp >= 0x0870 && cp <= 0x0882) return _alef;
  return null;
}

bool _isSpace(int cp) =>
    cp == 0x20 || cp == 0xA0 || cp == 0x09 || cp == 0x0A || cp == 0x0D || cp == 0x2009;

String foldArabic(String text) {
  final out = StringBuffer();
  for (final cp in text.runes) {
    final m = _mapped(cp);
    if (m != null) {
      out.writeCharCode(m);
    } else if ((cp >= 0x0622 && cp <= 0x063A) || (cp >= 0x0641 && cp <= 0x064A)) {
      out.writeCharCode(cp);
    } else if (_isSpace(cp)) {
      out.write(' ');
    }
    // hamza U+0621 and every other code point are dropped
  }
  var s = out.toString();
  while (s.contains('  ')) {
    s = s.replaceAll('  ', ' ');
  }
  return s.trim();
}

/// foldArabic with every alef removed (second search column).
String looseArabic(String text) => foldArabic(text).replaceAll('ا', '');

const Map<String, String> _latinMap = {
  'ā': 'a', 'ī': 'i', 'ū': 'u', 'ḥ': 'h', 'ḍ': 'd', 'ṣ': 's', 'ṭ': 't', 'ẓ': 'z',
  'ʿ': '', 'ʾ': '', '’': '', '‘': '', "'": '', '-': ' ', 'á': 'a', 'à': 'a',
  'â': 'a', 'é': 'e', 'ê': 'e', 'ô': 'o', 'û': 'u', 'ḳ': 'q',
};

/// Lower-case Latin text without diacritics, for matching transliterated surah names.
String foldLatin(String text) {
  final b = StringBuffer();
  for (final ch in text.toLowerCase().split('')) {
    final m = _latinMap[ch];
    b.write(m ?? ch);
  }
  return b.toString().replaceAll(RegExp(r'\s+'), ' ').trim();
}
