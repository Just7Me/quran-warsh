import 'package:flutter/material.dart';

import '../core/ayah_ref.dart';
import '../data/repositories/settings_repo.dart';
import '../data/services.dart';

/// Turns any exception into a short Arabic message for the user.
String friendlyError(Object e) {
  if (e is ArgumentError && e.message != null) return e.message.toString();
  if (e is StateError) return e.message;
  return e.toString();
}

class AppState extends ChangeNotifier {
  AppState(this.services);

  final Services services;

  ThemeMode themeMode = ThemeMode.system;
  double fontSize = 30;
  bool autoSave = true;

  /// Incremented after every change to user data so open screens can reload.
  int dataVersion = 0;

  /// Range being selected in the reader (start and end may be in different surahs).
  AyahRef? rangeStart;
  AyahRef? rangeEnd;

  /// A message for the user that could not be shown where it happened (for example a
  /// failure while leaving the reader). The shell shows it and clears it.
  String? pendingError;

  static const double minFont = 22;
  static const double maxFont = 44;

  Future<void> load() async {
    final all = await services.settings.all();
    themeMode = _parseTheme(all[SettingsRepo.kThemeMode]);
    final f = double.tryParse(all[SettingsRepo.kFontSize] ?? '');
    if (f != null && f >= minFont && f <= maxFont) fontSize = f;
    autoSave = (all[SettingsRepo.kAutoSave] ?? '1') != '0';
    notifyListeners();
  }

  static ThemeMode _parseTheme(String? v) {
    switch (v) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }

  static String _themeName(ThemeMode m) {
    switch (m) {
      case ThemeMode.light:
        return 'light';
      case ThemeMode.dark:
        return 'dark';
      case ThemeMode.system:
        return 'system';
    }
  }

  Future<void> setThemeMode(ThemeMode m) async {
    await services.settings.set(SettingsRepo.kThemeMode, _themeName(m));
    themeMode = m;
    notifyListeners();
  }

  Future<void> setFontSize(double v) async {
    final x = v.clamp(minFont, maxFont).toDouble();
    await services.settings.set(SettingsRepo.kFontSize, x.toStringAsFixed(0));
    fontSize = x;
    notifyListeners();
  }

  /// Live preview while the slider moves (not saved until the slider is released).
  void previewFontSize(double v) {
    fontSize = v;
    notifyListeners();
  }

  Future<void> setAutoSave(bool v) async {
    await services.settings.set(SettingsRepo.kAutoSave, v ? '1' : '0');
    autoSave = v;
    notifyListeners();
  }

  void bump() {
    dataVersion++;
    notifyListeners();
  }

  // ---- range selection

  void setRangeStart(AyahRef r) {
    rangeStart = r;
    notifyListeners();
  }

  void setRangeEnd(AyahRef r) {
    rangeEnd = r;
    notifyListeners();
  }

  void clearRange() {
    rangeStart = null;
    rangeEnd = null;
    notifyListeners();
  }

  /// Start and end in mushaf order, or null until both are chosen. The two ends may have been
  /// picked in any order; they are put in order here and the preview says so.
  ({int start, int end})? get orderedRange {
    final a = rangeStart;
    final b = rangeEnd;
    if (a == null || b == null) return null;
    return a.id <= b.id ? (start: a.id, end: b.id) : (start: b.id, end: a.id);
  }

  void reportError(String message) {
    pendingError = message;
    notifyListeners();
  }

  void clearError() {
    pendingError = null;
  }

  /// Reloads settings from the database (after a restore) and refreshes screens.
  Future<void> reloadAfterRestore() async {
    await load();
    clearRange();
    bump();
  }
}
