import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

import 'data/reference_db.dart';
import 'data/services.dart';
import 'data/user_db.dart';
import 'state/app_state.dart';
import 'ui/shell.dart';
import 'ui/theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BootstrapApp());
}

/// Opens both databases before showing the app. If the Quran data fails its integrity check the
/// app shows the error instead of continuing with doubtful data.
class BootstrapApp extends StatefulWidget {
  const BootstrapApp({super.key});

  @override
  State<BootstrapApp> createState() => _BootstrapAppState();
}

class _BootstrapAppState extends State<BootstrapApp> {
  late Future<AppState> _future;

  @override
  void initState() {
    super.initState();
    _future = _init();
  }

  Future<AppState> _init() async {
    final dir = await getApplicationSupportDirectory();
    final reference = await ReferenceDb.openFromAssets();
    final userDb = await UserDb.openInApp(dir.path);
    final services = Services(reference: reference, userDb: userDb, directory: dir.path);
    final state = AppState(services);
    await state.load();
    return state;
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<AppState>(
      future: _future,
      builder: (context, snap) {
        if (snap.hasError) {
          return _plain(
            Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.error_outline, size: 48),
                  const SizedBox(height: 12),
                  const Text('تعذّر فتح بيانات التطبيق', style: TextStyle(fontSize: 20)),
                  const SizedBox(height: 8),
                  Text('${snap.error}', textAlign: TextAlign.center),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: () => setState(() => _future = _init()),
                    child: const Text('إعادة المحاولة'),
                  ),
                ],
              ),
            ),
          );
        }
        if (!snap.hasData) {
          return _plain(const CircularProgressIndicator());
        }
        return ChangeNotifierProvider<AppState>.value(
          value: snap.data!,
          child: const QuranApp(),
        );
      },
    );
  }

  Widget _plain(Widget child) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: Scaffold(body: Center(child: child)),
    );
  }
}

class QuranApp extends StatelessWidget {
  const QuranApp({super.key});

  @override
  Widget build(BuildContext context) {
    final mode = context.select<AppState, ThemeMode>((s) => s.themeMode);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'مصحف ورش',
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: buildTheme(Brightness.light),
      darkTheme: buildTheme(Brightness.dark),
      themeMode: mode,
      home: const Shell(),
    );
  }
}
