import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/arabic_text.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import 'nav.dart';
import 'theme.dart';
import 'widgets/ayah_marker.dart';

/// The ayahs whose state is "needs review", in mushaf order, always one tap from the reader.
class NeedsReviewScreen extends StatefulWidget {
  const NeedsReviewScreen({super.key});

  @override
  State<NeedsReviewScreen> createState() => _NeedsReviewScreenState();
}

class _NeedsReviewScreenState extends State<NeedsReviewScreen> {
  List<Ayah>? _ayahs;
  String? _error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final app = context.read<AppState>();
    try {
      final ids = await app.services.memorization.idsWithStatus(MemStatus.needsReview);
      final list = <Ayah>[];
      for (final id in ids) {
        final a = await app.services.reference.ayahById(id);
        if (a != null) list.add(a);
      }
      if (!mounted) return;
      setState(() {
        _ayahs = list;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = 'تعذّر التحميل: ${friendlyError(e)}');
    }
  }

  Future<void> _setStatus(Ayah a, MemStatus s) async {
    final app = context.read<AppState>();
    try {
      await app.services.memorization.setSingle(a.id, s);
      app.bump();
      await _load();
    } catch (e) {
      if (!mounted) return;
      showMessage(context, 'تعذّر تغيير الحالة: ${friendlyError(e)}');
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final ref = app.services.reference;
    return Scaffold(
      appBar: AppBar(title: const Text('محفوظ يحتاج إلى مراجعة')),
      body: _error != null
          ? Center(child: Text(_error!))
          : _ayahs == null
              ? const Center(child: CircularProgressIndicator())
              : _ayahs!.isEmpty
                  ? const Center(child: Text('لا توجد آيات بهذه الحالة'))
                  : ListView.builder(
                      itemCount: _ayahs!.length,
                      itemBuilder: (context, i) {
                        final a = _ayahs![i];
                        return Card(
                          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Text('${ref.surah(a.surah).nameAr} • آية ${toArabicDigits(a.ayah)}',
                                    style: Theme.of(context).textTheme.titleSmall),
                                const SizedBox(height: 4),
                                Text.rich(
                                  TextSpan(
                                    children: [
                                      TextSpan(text: a.text),
                                      const TextSpan(text: ' '),
                                      WidgetSpan(
                                        alignment: PlaceholderAlignment.middle,
                                        child: AyahMarker(number: a.ayah, size: app.fontSize * 0.8),
                                      ),
                                    ],
                                    style: quranStyle(context, app.fontSize),
                                  ),
                                  textAlign: TextAlign.justify,
                                  textDirection: TextDirection.rtl,
                                ),
                                Wrap(
                                  spacing: 8,
                                  children: [
                                    TextButton(
                                      onPressed: () => openReader(context, surah: a.surah, ayah: a.ayah),
                                      child: const Text('فتح في المصحف'),
                                    ),
                                    TextButton(
                                      onPressed: () => _setStatus(a, MemStatus.memorized),
                                      child: const Text('أصبحت محفوظة'),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
    );
  }
}
