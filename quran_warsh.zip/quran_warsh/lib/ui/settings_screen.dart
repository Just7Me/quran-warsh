import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';

import '../core/arabic_text.dart';
import '../data/backup_service.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import 'nav.dart';
import 'theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _busy = false;
  String? _sampleText;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadSample());
  }

  /// The font preview uses a real ayah from the reference database, never text typed in code.
  Future<void> _loadSample() async {
    final app = context.read<AppState>();
    try {
      final a = await app.services.reference.ayahById(1002);
      if (mounted && a != null) setState(() => _sampleText = a.text);
    } catch (_) {
      // The preview is optional; the settings still work without it.
    }
  }

  Future<void> _export(AppState app) async {
    setState(() => _busy = true);
    try {
      final json = await app.services.backup.exportJson();
      final dir = await getTemporaryDirectory();
      final now = DateTime.now();
      String two(int v) => v.toString().padLeft(2, '0');
      final name = 'quran_warsh_backup_${now.year}${two(now.month)}${two(now.day)}_${two(now.hour)}${two(now.minute)}.json';
      final file = File(p.join(dir.path, name));
      await file.writeAsString(json, flush: true);
      // Read it back to be sure what was written is a valid backup before offering it.
      await app.services.backup.inspect(await file.readAsString());
      await Share.shareXFiles([XFile(file.path, mimeType: 'application/json')],
          subject: 'نسخة احتياطية - مصحف ورش');
    } catch (e) {
      if (mounted) showMessage(context, 'تعذّر إنشاء النسخة الاحتياطية: ${friendlyError(e)}');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _import(AppState app) async {
    setState(() => _busy = true);
    try {
      final picked = await FilePicker.platform.pickFiles(type: FileType.any, withData: false);
      if (picked == null || picked.files.isEmpty) return;
      final path = picked.files.single.path;
      if (path == null) throw BackupException('تعذّر الوصول إلى الملف المختار.');
      final content = await File(path).readAsString();
      final summary = await app.services.backup.inspect(content); // validates everything
      if (!mounted) return;
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('استعادة نسخة احتياطية'),
          content: Text(
            'تاريخ النسخة: ${formatDate(summary.createdAt)}\n'
            'علامات مرجعية: ${toArabicDigits(summary.bookmarks)}\n'
            'آيات لها حالة حفظ: ${toArabicDigits(summary.memorization)}\n'
            'نطاقات مراجعة: ${toArabicDigits(summary.reviewRanges)}\n'
            'جلسات مراجعة: ${toArabicDigits(summary.reviewSessions)}\n\n'
            'ستحلّ هذه البيانات محل بياناتك الحالية. تُحفظ نسخة من بياناتك الحالية '
            'تلقائيًا قبل الاستبدال. نص القرآن لا يتأثر.',
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('استعادة')),
          ],
        ),
      );
      if (ok != true) return;
      final safety = await app.services.backup.restore(content);
      final safetyFile = File(p.join(app.services.directory, 'pre_restore_backup.json'));
      await safetyFile.writeAsString(safety, flush: true);
      await app.reloadAfterRestore();
      if (mounted) showMessage(context, 'تمت الاستعادة بنجاح');
    } on BackupException catch (e) {
      if (mounted) showMessage(context, e.message);
    } catch (e) {
      if (mounted) showMessage(context, 'تعذّرت الاستعادة: ${friendlyError(e)}');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final meta = app.services.reference.meta;
    final disputed = app.services.reference.disputed.length;
    final brightness = Theme.of(context).brightness;
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('المظهر', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          SegmentedButton<ThemeMode>(
            segments: const [
              ButtonSegment(value: ThemeMode.light, label: Text('فاتح'), icon: Icon(Icons.light_mode)),
              ButtonSegment(value: ThemeMode.dark, label: Text('داكن'), icon: Icon(Icons.dark_mode)),
              ButtonSegment(value: ThemeMode.system, label: Text('حسب الجهاز'), icon: Icon(Icons.phone_android)),
            ],
            selected: {app.themeMode},
            onSelectionChanged: (s) async {
              try {
                await app.setThemeMode(s.first);
              } catch (e) {
                if (context.mounted) showMessage(context, 'تعذّر حفظ المظهر: ${friendlyError(e)}');
              }
            },
          ),
          const SizedBox(height: 20),
          Text('حجم الخط', style: Theme.of(context).textTheme.titleMedium),
          Slider(
            value: app.fontSize,
            min: AppState.minFont,
            max: AppState.maxFont,
            divisions: (AppState.maxFont - AppState.minFont).round(),
            label: toArabicDigits(app.fontSize.round()),
            onChanged: app.previewFontSize,
            onChangeEnd: (v) async {
              try {
                await app.setFontSize(v);
              } catch (e) {
                if (context.mounted) showMessage(context, 'تعذّر حفظ حجم الخط: ${friendlyError(e)}');
              }
            },
          ),
          if (_sampleText != null)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
              ),
              child: Text(_sampleText!,
                  textAlign: TextAlign.justify,
                  textDirection: TextDirection.rtl,
                  style: quranStyle(context, app.fontSize)),
            ),
          const SizedBox(height: 12),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('حفظ موضع القراءة تلقائيًا'),
            subtitle: const Text(
                'يُحفظ بعد التوقف ثلاث ثوانٍ عن التصفح وعند الخروج. الموضع الذي تحدده بنفسك لا يتراجع تلقائيًا.'),
            value: app.autoSave,
            onChanged: (v) async {
              try {
                await app.setAutoSave(v);
              } catch (e) {
                if (context.mounted) showMessage(context, 'تعذّر الحفظ: ${friendlyError(e)}');
              }
            },
          ),
          const Divider(height: 32),
          Text('ألوان حالة الحفظ', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          for (final s in MemStatus.values)
            Row(
              children: [
                Container(
                  width: 14,
                  height: 14,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: s == MemStatus.notStarted ? null : statusColor(s, brightness),
                    border: Border.all(color: Theme.of(context).colorScheme.outline),
                  ),
                ),
                const SizedBox(width: 10),
                Text(s.label),
              ],
            ),
          const Divider(height: 32),
          Text('النسخ الاحتياطي', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          const Text(
              'تُحفظ بيانات التقدم والحفظ والمراجعة والعلامات على هذا الجهاز فقط. '
              'النسخة الاحتياطية لا تحتوي نص القرآن ولا يمكنها تغييره.'),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: [
              FilledButton.icon(
                icon: const Icon(Icons.upload_file),
                label: const Text('تصدير نسخة احتياطية'),
                onPressed: _busy ? null : () => _export(app),
              ),
              OutlinedButton.icon(
                icon: const Icon(Icons.download),
                label: const Text('استعادة من ملف'),
                onPressed: _busy ? null : () => _import(app),
              ),
            ],
          ),
          const Divider(height: 32),
          Text('عن بيانات المصحف', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Text('الرواية: ${meta['riwayah']}'),
          Text('المصدر: مجمع الملك فهد لطباعة المصحف الشريف — ${meta['text_package']}'),
          Text('عدد السور: ${toArabicDigits(app.services.reference.surahs.length)} • عدد الآيات: ${toArabicDigits(app.services.reference.totalAyahs)}'),
          Text('بصمة الحزمة (SHA-256):\n${meta['text_package_sha256']}', textDirection: TextDirection.ltr),
          Text('بصمة نص الآيات:\n${meta['ayah_text_digest_sha256']}', textDirection: TextDirection.ltr),
          const SizedBox(height: 6),
          Text(
            disputed == 0
                ? 'لا توجد آيات غير محسومة.'
                : 'آيات تختلف بين إصداري المجمع ولم تُحسم: ${toArabicDigits(disputed)} (تظهر عليها علامة تنبيه).',
          ),
          const SizedBox(height: 6),
          Text(
            meta['official_checksum_verified'] == 'true'
                ? 'تمت مطابقة بصمة الحزمة مع البصمة الرسمية.'
                : 'لم تُطابَق بصمة الحزمة مع بصمة رسمية من المجمع. راجع تقرير صحة بيانات القرآن.',
            style: TextStyle(color: Theme.of(context).colorScheme.error),
          ),
          const SizedBox(height: 6),
          const Text('الخط: «KFGQPC Warsh Uthmanic Script» من مجمع الملك فهد، ويخضع لشروط المجمع.'),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}
