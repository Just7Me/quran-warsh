import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/arabic_text.dart';
import '../core/ayah_ref.dart';
import '../data/models.dart';
import '../state/app_state.dart';

/// History of review sessions, exactly as recorded.
class SessionsScreen extends StatelessWidget {
  const SessionsScreen({super.key});

  static String _outcome(String o) {
    switch (o) {
      case 'completed':
        return 'مراجعة تامة للنطاق';
      case 'partial':
        return 'مراجعة جزئية';
      default:
        return 'غير منتهية';
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final ref = app.services.reference;
    return Scaffold(
      appBar: AppBar(title: const Text('سجل جلسات المراجعة')),
      body: FutureBuilder<List<ReviewSession>>(
        future: app.services.review.listSessions(),
        builder: (context, snap) {
          if (snap.hasError) {
            return Center(child: Text('تعذّر التحميل: ${friendlyError(snap.error!)}'));
          }
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final list = snap.data!;
          if (list.isEmpty) return const Center(child: Text('لا توجد جلسات مسجلة بعد'));
          return ListView.separated(
            itemCount: list.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, i) {
              final s = list[i];
              final a = AyahRef.fromId(s.startId);
              final b = AyahRef.fromId(s.endId);
              final total = ref.ordinalOf(s.endId) - ref.ordinalOf(s.startId) + 1;
              return ListTile(
                title: Text(s.rangeName),
                subtitle: Text(
                  '${_outcome(s.outcome)} • راجعتَ ${toArabicDigits(s.reviewedCount)} من ${toArabicDigits(total)} آية\n'
                  'من ${ref.surah(a.surah).nameAr} ${toArabicDigits(a.ayah)} '
                  'إلى ${ref.surah(b.surah).nameAr} ${toArabicDigits(b.ayah)}\n'
                  '${formatDate(s.startedAt)}',
                ),
                isThreeLine: true,
              );
            },
          );
        },
      ),
    );
  }
}
