import 'package:flutter/material.dart';

import '../data/models.dart';

const String quranFont = 'UthmanicWarsh';

ThemeData buildTheme(Brightness brightness) {
  final dark = brightness == Brightness.dark;
  final scheme = ColorScheme.fromSeed(
    seedColor: const Color(0xFF1B6B57),
    brightness: brightness,
  );
  final background = dark ? const Color(0xFF121614) : const Color(0xFFFBF8F1);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: background,
    appBarTheme: AppBarTheme(
      backgroundColor: background,
      foregroundColor: scheme.onSurface,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: true,
    ),
    visualDensity: VisualDensity.standard,
  );
}

/// Bar / label colour of a memorization state (readable in both themes).
Color statusColor(MemStatus s, Brightness b) {
  final dark = b == Brightness.dark;
  switch (s) {
    case MemStatus.notStarted:
      return Colors.transparent;
    case MemStatus.learning:
      return dark ? const Color(0xFFFFC94D) : const Color(0xFFB8860B);
    case MemStatus.memorized:
      return dark ? const Color(0xFF5CD08A) : const Color(0xFF2E8B57);
    case MemStatus.needsReview:
      return dark ? const Color(0xFFFF9A62) : const Color(0xFFD9632A);
  }
}

/// Very light background tint so the Quran text stays fully readable.
Color statusTint(MemStatus s, Brightness b) {
  final c = statusColor(s, b);
  if (s == MemStatus.notStarted) return Colors.transparent;
  return c.withAlpha(b == Brightness.dark ? 28 : 26);
}

TextStyle quranStyle(BuildContext context, double size) {
  return TextStyle(
    fontFamily: quranFont,
    fontSize: size,
    height: 2.1,
    color: Theme.of(context).colorScheme.onSurface,
  );
}

TextStyle surahNameStyle(BuildContext context, double size, {Color? color}) {
  return TextStyle(
    fontFamily: quranFont,
    fontSize: size,
    height: 1.6,
    color: color ?? Theme.of(context).colorScheme.onSurface,
  );
}
