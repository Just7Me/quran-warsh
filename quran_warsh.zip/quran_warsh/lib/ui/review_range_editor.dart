import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/arabic_text.dart';
import '../core/ayah_ref.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import 'nav.dart';
import 'widgets/range_form.dart';

/// Creates a review range, or edits the name and limits of an existing one.
class ReviewRangeEditor extends StatefulWidget {
  const ReviewRangeEditor({super.key, this.existing});

  final ReviewRange? existing;

  @override
  State<ReviewRangeEditor> createState() => _ReviewRangeEditorState();
}

class _ReviewRangeEditorState extends State<ReviewRangeEditor> {
  late final TextEditingController _name;
  ({int start, int end})? _range;
  DateTime? _next;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: widget.existing?.name ?? '');
    if (widget.existing != null) {
      _range = (start: widget.existing!.startId, end: widget.existing!.endId);
      final n = widget.existing!.nextReviewAt;
      _next = n == null ? null : DateTime.fromMillisecondsSinceEpoch(n);
    }
  }

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: _next ?? now.add(const Duration(days: 1)),
      firstDate: DateTime(now.year - 1),
      lastDate: DateTime(now.year + 5),
      helpText: 'موعد المراجعة التالية',
    );
    if (d != null) setState(() => _next = d);
  }

  Future<void> _save(AppState app) async {
    final r = _range;
    final name = _name.text.trim();
    if (name.isEmpty) {
      showMessage(context, 'اكتب اسمًا لنطاق المراجعة');
      return;
    }
    if (r == null) {
      showMessage(context, 'اختر بداية النطاق ونهايته');
      return;
    }
    setState(() => _busy = true);
    try {
      if (widget.existing == null) {
        await app.services.review.createRange(
          name: name,
          startId: r.start,
          endId: r.end,
          nextReviewAt: _next?.millisecondsSinceEpoch,
        );
      } else {
        await app.services.review.updateRange(
          id: widget.existing!.id,
          name: name,
          startId: r.start,
          endId: r.end,
        );
        await app.services.review.setNextReview(widget.existing!.id, _next?.millisecondsSinceEpoch);
      }
      app.bump();
      if (!mounted) return;
      Navigator.of(context).pop();
    } catch (e) {
      if (!mounted) return;
      setState(() => _busy = false);
      showMessage(context, 'تعذّر الحفظ: ${friendlyError(e)}');
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.read<AppState>();
    final ex = widget.existing;
    return Scaffold(
      appBar: AppBar(title: Text(ex == null ? 'نطاق مراجعة جديد' : 'تعديل نطاق المراجعة')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _name,
            maxLength: 80,
            decoration: const InputDecoration(
              labelText: 'اسم النطاق',
              hintText: 'مثل: مراجعة سورة البقرة',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          RangeForm(
            reference: app.services.reference,
            initialStart: ex == null ? null : AyahRef.fromId(ex.startId),
            initialEnd: ex == null ? null : AyahRef.fromId(ex.endId),
            onChanged: (v) => setState(() => _range = v),
          ),
          const SizedBox(height: 16),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.event),
            title: Text(_next == null
                ? 'موعد المراجعة التالية (اختياري)'
                : 'الموعد: ${formatDate(_next!.millisecondsSinceEpoch)}'),
            trailing: _next == null
                ? null
                : IconButton(
                    icon: const Icon(Icons.clear),
                    tooltip: 'إلغاء الموعد',
                    onPressed: () => setState(() => _next = null),
                  ),
            onTap: _pickDate,
          ),
          const SizedBox(height: 12),
          FilledButton(
            onPressed: _busy ? null : () => _save(app),
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
  }
}
