import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/arabic_text.dart';
import '../data/models.dart';
import '../data/repositories/memorization_repo.dart';
import '../state/app_state.dart';
import 'nav.dart';
import 'range_status_page.dart';
import 'theme.dart';

class _MemData {
  _MemData(this.counts, this.perSurah, this.canUndo);
  final Map<MemStatus, int> counts;
  final List<SurahMemCounts> perSurah;
  final bool canUndo;
}

class MemorizationTab extends StatefulWidget {
  const MemorizationTab({super.key});

  @override
  State<MemorizationTab> createState() => _MemorizationTabState();
}

class _MemorizationTabState extends State<MemorizationTab> {
  int _loadedVersion = -1;
  Future<_MemData>? _future;

  Future<_MemData> _load(AppState app) async {
    final repo = app.services.memorization;
    return _MemData(await repo.counts(), await repo.perSurah(), await repo.canUndo());
  }

  Future<void> _undo(AppState app) async {
    try {
      final n = await app.services.memorization.undoLast();
      app.bump();
      if (!mounted) return;
      showMessage(context,
          n == null ? 'لا يوجد ما يمكن التراجع عنه' : 'تم التراجع عن ${toArabicDigits(n)} آية');
    } catch (e) {
      if (!mounted) return;
      showMessage(context, 'تعذّر التراجع: ${friendlyError(e)}');
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    if (_loadedVersion != app.dataVersion || _future == null) {
      _loadedVersion = app.dataVersion;
      _future = _load(app);
    }
    final reference = app.services.reference;
    return FutureBuilder<_MemData>(
      future: _future,
      builder: (context, snap) {
        if (snap.hasError) {
          return Center(child: Text('تعذّر التحميل: ${friendlyError(snap.error!)}'));
        }
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final d = snap.data!;
        final brightness = Theme.of(context).brightness;
        return ListView(
          padding: const EdgeInsets.all(12),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('حالة الحفظ (عدد الآيات)', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 8),
                    for (final s in const [
                      MemStatus.memorized,
                      MemStatus.learning,
                      MemStatus.needsReview,
                    ])
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 2),
                        child: Row(
                          children: [
                            Icon(Icons.circle, size: 14, color: statusColor(s, brightness)),
                            const SizedBox(width: 8),
                            Text('${s.label}: ${toArabicDigits(d.counts[s] ?? 0)}'),
                          ],
                        ),
                      ),
                    Text('بقية الآيات لم تُبدأ بعد (من إجمالي '
                        '${toArabicDigits(reference.totalAyahs)} آية).',
                        style: Theme.of(context).textTheme.bodySmall),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            FilledButton.icon(
              icon: const Icon(Icons.tune),
              label: const Text('تغيير حالة نطاق من الآيات'),
              onPressed: () => Navigator.of(context).push<void>(
                MaterialPageRoute<void>(builder: (_) => const RangeStatusPage()),
              ),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              icon: const Icon(Icons.undo),
              label: const Text('التراجع عن آخر تغيير'),
              onPressed: d.canUndo ? () => _undo(app) : null,
            ),
            const SizedBox(height: 16),
            Text('حسب السور', style: Theme.of(context).textTheme.titleMedium),
            if (d.perSurah.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text('لم تُحدَّد حالة حفظ لأي آية بعد. اضغط على أي آية أثناء القراءة لتغيير حالتها.'),
              ),
            for (final c in d.perSurah)
              ListTile(
                title: Text(reference.surah(c.surah).nameAr, style: surahNameStyle(context, 22)),
                subtitle: Text([
                  if (c.memorized > 0) 'محفوظة ${toArabicDigits(c.memorized)}',
                  if (c.learning > 0) 'قيد الحفظ ${toArabicDigits(c.learning)}',
                  if (c.needsReview > 0) 'تحتاج مراجعة ${toArabicDigits(c.needsReview)}',
                ].join(' • ')),
                trailing: Text('من ${toArabicDigits(reference.surah(c.surah).ayahCount)}'),
                onTap: () => openReader(context, surah: c.surah),
              ),
          ],
        );
      },
    );
  }
}
