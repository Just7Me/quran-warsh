import 'package:flutter/material.dart';

import 'reader_screen.dart';

/// Opens the reader at the given ayah (by surah number and ayah number).
Future<void> openReader(BuildContext context, {required int surah, int ayah = 1}) {
  return Navigator.of(context).push<void>(
    MaterialPageRoute<void>(builder: (_) => ReaderScreen(surah: surah, initialAyah: ayah)),
  );
}

void showMessage(BuildContext context, String message) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message)));
}
