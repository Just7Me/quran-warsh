import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/arabic_text.dart';
import '../data/models.dart';
import '../data/reference_db.dart';
import '../logic/search_fold.dart';
import '../state/app_state.dart';
import 'nav.dart';
import 'theme.dart';

/// What a search box input means.
class SearchPlan {
  SearchPlan({this.ayahTarget, this.error, this.surahs = const [], this.words});

  /// (surah, ayah) written explicitly, already validated against the reference database.
  final (int, int)? ayahTarget;

  /// A clear message when a surah or ayah number is outside the real range.
  final String? error;
  final List<Surah> surahs;
  final String? words;
}

/// Parses the text typed in the search box. Pure function over the reference data so it can be
/// tested: "2:255", "٢ ٢٥٥", "البقرة 255", "البقرة", "255" (surah number) or any word.
SearchPlan planSearch(ReferenceDb ref, String input) {
  final q = input.trim();
  if (q.isEmpty) return SearchPlan();

  // 1) numbers only: "2:255", "2 255", "2/255", "٢:٢٥٥" or a single surah number
  final pair = RegExp(r'^([0-9٠-٩۰-۹]+)\s*[:：/\-،.\s]\s*([0-9٠-٩۰-۹]+)$').firstMatch(q);
  if (pair != null) {
    final s = parseDigits(pair.group(1)!);
    final a = parseDigits(pair.group(2)!);
    return _checked(ref, s, a);
  }
  final single = parseDigits(q);
  if (single != null) {
    if (single < 1 || single > ref.surahs.length) {
      return SearchPlan(error: 'رقم السورة يجب أن يكون بين ١ و ${toArabicDigits(ref.surahs.length)}');
    }
    return SearchPlan(surahs: [ref.surah(single)]);
  }

  // 2) "<surah name> <ayah number>"
  final named = RegExp(r'^(.+?)\s+([0-9٠-٩۰-۹]+)$').firstMatch(q);
  if (named != null) {
    final matches = ref.searchSurahs(named.group(1)!);
    final a = parseDigits(named.group(2)!);
    if (matches.length == 1 && a != null) {
      return _checked(ref, matches.first.number, a);
    }
    if (matches.length > 1) {
      return SearchPlan(
          surahs: matches, error: 'عدة سور تطابق الاسم، اختر السورة ثم الآية');
    }
  }

  // 3) surah names, then words
  final surahs = ref.searchSurahs(q);
  final words = looseArabic(q).length >= 2 ? q : null;
  return SearchPlan(surahs: surahs, words: words);
}

SearchPlan _checked(ReferenceDb ref, int? s, int? a) {
  if (s == null || a == null) return SearchPlan(error: 'اكتب رقم السورة والآية بالأرقام');
  if (s < 1 || s > ref.surahs.length) {
    return SearchPlan(error: 'رقم السورة يجب أن يكون بين ١ و ${toArabicDigits(ref.surahs.length)}');
  }
  final surah = ref.surah(s);
  if (a < 1 || a > surah.ayahCount) {
    return SearchPlan(
        error: 'الآية ${toArabicDigits(a)} غير موجودة: سورة ${surah.nameAr} فيها ${toArabicDigits(surah.ayahCount)} آية');
  }
  return SearchPlan(ayahTarget: (s, a));
}

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _ctrl = TextEditingController();
  SearchPlan _plan = SearchPlan();
  List<Ayah> _hits = const [];
  bool _searching = false;
  int _token = 0;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _run(String text) async {
    final app = context.read<AppState>();
    final ref = app.services.reference;
    final plan = planSearch(ref, text);
    final my = ++_token;
    setState(() {
      _plan = plan;
      _hits = const [];
      _searching = plan.words != null;
    });
    if (plan.words == null) return;
    try {
      final hits = await ref.searchWords(plan.words!);
      if (!mounted || my != _token) return;
      setState(() {
        _hits = hits;
        _searching = false;
      });
    } catch (e) {
      if (!mounted || my != _token) return;
      setState(() => _searching = false);
      showMessage(context, 'تعذّر البحث: ${friendlyError(e)}');
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final ref = app.services.reference;
    final plan = _plan;
    final children = <Widget>[];

    if (plan.error != null) {
      children.add(Padding(
        padding: const EdgeInsets.all(16),
        child: Text(plan.error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
      ));
    }
    if (plan.ayahTarget != null) {
      final (s, a) = plan.ayahTarget!;
      children.add(ListTile(
        leading: const Icon(Icons.my_location),
        title: Text('الانتقال إلى ${ref.surah(s).nameAr} • آية ${toArabicDigits(a)}'),
        onTap: () => openReader(context, surah: s, ayah: a),
      ));
    }
    for (final s in plan.surahs) {
      children.add(ListTile(
        leading: CircleAvatar(child: Text(toArabicDigits(s.number), style: const TextStyle(fontSize: 13))),
        title: Text('سورة ${s.nameAr}', style: surahNameStyle(context, 22)),
        subtitle: Text('${toArabicDigits(s.ayahCount)} آية'),
        onTap: () => openReader(context, surah: s.number),
      ));
    }
    if (plan.words != null) {
      if (_searching) {
        children.add(const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator())));
      } else if (_hits.isEmpty) {
        children.add(const Padding(padding: EdgeInsets.all(16), child: Text('لا توجد آيات تطابق هذه الكلمات')));
      } else {
        children.add(Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
          child: Text(
            'نتائج الكلمات: ${toArabicDigits(_hits.length)}${_hits.length >= 200 ? ' (أول ٢٠٠ نتيجة)' : ''}',
            style: Theme.of(context).textTheme.titleSmall,
          ),
        ));
        for (final a in _hits) {
          children.add(ListTile(
            title: Text('${ref.surah(a.surah).nameAr} • آية ${toArabicDigits(a.ayah)}'),
            subtitle: Text(a.text,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                textDirection: TextDirection.rtl,
                style: quranStyle(context, 20).copyWith(height: 1.6)),
            onTap: () => openReader(context, surah: a.surah, ayah: a.ayah),
          ));
        }
      }
    }

    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _ctrl,
          autofocus: true,
          textInputAction: TextInputAction.search,
          decoration: const InputDecoration(
            hintText: 'سورة، أو «البقرة ٢٥٥»، أو ٢:٢٥٥، أو كلمة',
            border: InputBorder.none,
          ),
          onChanged: _run,
          onSubmitted: _run,
        ),
      ),
      body: ListView(children: children),
    );
  }
}
