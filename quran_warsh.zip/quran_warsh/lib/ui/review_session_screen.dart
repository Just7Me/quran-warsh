import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/arabic_text.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import 'nav.dart';
import 'theme.dart';
import 'widgets/ayah_marker.dart';

/// A review session over a range, ayahs in mushaf order. Each ayah can be marked "reviewed"
/// or "needs more review" (which also sets its memorization state to needs_review).
/// Finishing computes the outcome from the recorded marks: completed only if every ayah of the
/// range has a mark, otherwise partial. A partly reviewed range is never counted as finished.
class ReviewSessionScreen extends StatefulWidget {
  const ReviewSessionScreen({super.key, required this.rangeId, required this.sessionId});

  final int rangeId;
  final int sessionId;

  @override
  State<ReviewSessionScreen> createState() => _ReviewSessionScreenState();
}

class _ReviewSessionScreenState extends State<ReviewSessionScreen> {
  ReviewRange? _range;
  List<Ayah> _ayahs = const [];
  Map<int, String> _results = {};
  Map<int, MemStatus> _statuses = {};
  String? _error;
  bool _loaded = false;
  late AppState _app;
  bool _appReady = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_appReady) {
      _app = context.read<AppState>();
      _appReady = true;
      _load();
    }
  }

  Future<void> _load() async {
    try {
      final sv = _app.services;
      final range = await sv.review.getRange(widget.rangeId);
      if (range == null) throw StateError('نطاق المراجعة غير موجود');
      final ayahs = await sv.reference.ayahsInRange(range.startId, range.endId);
      final results = await sv.review.sessionResults(widget.sessionId);
      final statuses = <int, MemStatus>{};
      final lo = range.startId, hi = range.endId;
      for (var s = lo ~/ 1000; s <= hi ~/ 1000; s++) {
        statuses.addAll(await sv.memorization.statusesForSurah(s));
      }
      if (!mounted) return;
      setState(() {
        _range = range;
        _ayahs = ayahs;
        _results = results;
        _statuses = statuses;
        _loaded = true;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = 'تعذّر تحميل جلسة المراجعة: ${friendlyError(e)}');
    }
  }

  Future<void> _mark(Ayah a, {required bool needsMore}) async {
    try {
      final current = _results[a.id];
      final want = needsMore ? 'needs_more' : 'reviewed';
      if (current == want) {
        await _app.services.review.clearAyahMark(widget.sessionId, a.id);
        setState(() => _results.remove(a.id));
        return;
      }
      await _app.services.review
          .markAyah(sessionId: widget.sessionId, ayahId: a.id, needsMore: needsMore);
      setState(() {
        _results[a.id] = want;
        if (needsMore) _statuses[a.id] = MemStatus.needsReview;
      });
      _app.bump();
    } catch (e) {
      if (!mounted) return;
      showMessage(context, 'تعذّر تسجيل النتيجة: ${friendlyError(e)}');
    }
  }

  Future<void> _finish() async {
    final total = _ayahs.length;
    final done = _results.length;
    final whole = done >= total && total > 0;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('إنهاء جلسة المراجعة'),
        content: Text(whole
            ? 'راجعتَ كل آيات النطاق (${toArabicDigits(done)} من ${toArabicDigits(total)}). سيُسجَّل النطاق مُنتهيًا.'
            : 'راجعتَ ${toArabicDigits(done)} من ${toArabicDigits(total)} آية فقط. '
                'ستُسجَّل مراجعة جزئية ولن يُعدّ النطاق منتهيًا.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('رجوع')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('إنهاء')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      final outcome = await _app.services.review
          .finishSession(sessionId: widget.sessionId, totalAyahs: total);
      _app.bump();
      if (!mounted) return;
      showMessage(context, outcome == 'completed' ? 'تم تسجيل مراجعة تامة للنطاق' : 'تم تسجيل مراجعة جزئية');
      Navigator.of(context).pop();
    } catch (e) {
      if (!mounted) return;
      showMessage(context, 'تعذّر إنهاء الجلسة: ${friendlyError(e)}');
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final reference = app.services.reference;
    final brightness = Theme.of(context).brightness;
    return Scaffold(
      appBar: AppBar(
        title: Text(_range?.name ?? 'مراجعة'),
        actions: [
          TextButton(onPressed: _loaded ? _finish : null, child: const Text('إنهاء')),
        ],
      ),
      body: _error != null
          ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_error!)))
          : !_loaded
              ? const Center(child: CircularProgressIndicator())
              : Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          LinearProgressIndicator(
                              value: _ayahs.isEmpty ? 0 : _results.length / _ayahs.length,
                              minHeight: 6),
                          const SizedBox(height: 6),
                          Text('تمت مراجعة ${toArabicDigits(_results.length)} من ${toArabicDigits(_ayahs.length)} آية'),
                        ],
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        itemCount: _ayahs.length,
                        itemBuilder: (context, i) {
                          final a = _ayahs[i];
                          final res = _results[a.id];
                          final st = _statuses[a.id] ?? MemStatus.notStarted;
                          final showSurahHeader = i == 0 || _ayahs[i - 1].surah != a.surah;
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              if (showSurahHeader)
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                                  child: Text('سورة ${reference.surah(a.surah).nameAr}',
                                      style: surahNameStyle(context, 24,
                                          color: Theme.of(context).colorScheme.primary)),
                                ),
                              Card(
                                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                color: res == null ? null : Theme.of(context).colorScheme.surfaceContainerHigh,
                                child: Padding(
                                  padding: const EdgeInsets.all(12),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.stretch,
                                    children: [
                                      Text.rich(
                                        TextSpan(
                                          children: [
                                            TextSpan(text: a.text),
                                            const TextSpan(text: ' '),
                                            WidgetSpan(
                                              alignment: PlaceholderAlignment.middle,
                                              child: AyahMarker(number: a.ayah, size: app.fontSize * 0.8),
                                            ),
                                          ],
                                          style: quranStyle(context, app.fontSize),
                                        ),
                                        textAlign: TextAlign.justify,
                                        textDirection: TextDirection.rtl,
                                      ),
                                      const SizedBox(height: 4),
                                      Row(
                                        children: [
                                          if (st != MemStatus.notStarted)
                                            Padding(
                                              padding: const EdgeInsetsDirectional.only(end: 8),
                                              child: Text(st.label,
                                                  style: TextStyle(
                                                      fontSize: 12, color: statusColor(st, brightness))),
                                            ),
                                          const Spacer(),
                                          FilterChip(
                                            label: const Text('راجعتها'),
                                            selected: res == 'reviewed',
                                            onSelected: (_) => _mark(a, needsMore: false),
                                          ),
                                          const SizedBox(width: 8),
                                          FilterChip(
                                            label: const Text('تحتاج مراجعة'),
                                            selected: res == 'needs_more',
                                            onSelected: (_) => _mark(a, needsMore: true),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                    ),
                  ],
                ),
    );
  }
}
