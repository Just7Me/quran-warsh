import 'package:flutter/material.dart';

import '../../core/arabic_text.dart';
import '../../core/ayah_ref.dart';
import '../../data/reference_db.dart';
import '../theme.dart';

/// Chooses one ayah by surah (list) and ayah number (typed). It reports a valid [AyahRef] only
/// when the number exists in the surah, and shows a clear message otherwise.
class AyahPicker extends StatefulWidget {
  const AyahPicker({
    super.key,
    required this.reference,
    required this.label,
    required this.onChanged,
    this.initial,
  });

  final ReferenceDb reference;
  final String label;
  final AyahRef? initial;

  /// Called with the valid ayah, or null while the input is not valid.
  final ValueChanged<AyahRef?> onChanged;

  @override
  State<AyahPicker> createState() => _AyahPickerState();
}

class _AyahPickerState extends State<AyahPicker> {
  late int _surah;
  late final TextEditingController _ayah;
  String? _error;

  @override
  void initState() {
    super.initState();
    _surah = widget.initial?.surah ?? 1;
    _ayah = TextEditingController(
        text: widget.initial == null ? '' : widget.initial!.ayah.toString());
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _validate();
    });
  }

  @override
  void dispose() {
    _ayah.dispose();
    super.dispose();
  }

  void _validate() {
    final n = parseDigits(_ayah.text);
    final s = widget.reference.surah(_surah);
    String? err;
    AyahRef? ok;
    if (_ayah.text.trim().isEmpty) {
      err = null;
    } else if (n == null) {
      err = 'اكتب رقم الآية بالأرقام فقط';
    } else if (n < 1 || n > s.ayahCount) {
      err = 'الآية $n خارج النطاق: سورة ${s.nameAr} فيها ${s.ayahCount} آية';
    } else {
      ok = AyahRef(_surah, n);
    }
    setState(() => _error = err);
    widget.onChanged(ok);
  }

  @override
  Widget build(BuildContext context) {
    final surahs = widget.reference.surahs;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(widget.label, style: Theme.of(context).textTheme.titleSmall),
        const SizedBox(height: 6),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 3,
              child: DropdownButtonFormField<int>(
                value: _surah,
                isExpanded: true,
                decoration: const InputDecoration(
                  labelText: 'السورة',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
                items: [
                  for (final s in surahs)
                    DropdownMenuItem<int>(
                      value: s.number,
                      child: Text('${toArabicDigits(s.number)}. ${s.nameAr}',
                          style: surahNameStyle(context, 18)),
                    ),
                ],
                onChanged: (v) {
                  if (v == null) return;
                  _surah = v;
                  _validate();
                },
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              flex: 2,
              child: TextField(
                controller: _ayah,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'رقم الآية',
                  border: const OutlineInputBorder(),
                  isDense: true,
                  helperText: 'من ١ إلى ${toArabicDigits(widget.reference.surah(_surah).ayahCount)}',
                ),
                onChanged: (_) => _validate(),
              ),
            ),
          ],
        ),
        if (_error != null)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          ),
      ],
    );
  }
}
