import 'package:flutter/material.dart';

import '../../core/arabic_text.dart';
import '../../core/ayah_ref.dart';
import '../../data/reference_db.dart';
import 'ayah_picker.dart';

/// Two ayah pickers (start and end) plus a preview. The end may be in a later surah. If the user
/// enters them in reverse order they are put in order and the preview says so.
class RangeForm extends StatefulWidget {
  const RangeForm({
    super.key,
    required this.reference,
    required this.onChanged,
    this.initialStart,
    this.initialEnd,
  });

  final ReferenceDb reference;
  final AyahRef? initialStart;
  final AyahRef? initialEnd;

  /// (startId, endId) in mushaf order, or null while the input is incomplete or invalid.
  final ValueChanged<({int start, int end})?> onChanged;

  @override
  State<RangeForm> createState() => _RangeFormState();
}

class _RangeFormState extends State<RangeForm> {
  AyahRef? _a;
  AyahRef? _b;

  void _emit() {
    if (_a == null || _b == null) {
      widget.onChanged(null);
    } else {
      final lo = _a!.id <= _b!.id ? _a! : _b!;
      final hi = _a!.id <= _b!.id ? _b! : _a!;
      widget.onChanged((start: lo.id, end: hi.id));
    }
    setState(() {});
  }

  String? _preview() {
    if (_a == null || _b == null) return null;
    final reversed = _a!.id > _b!.id;
    final lo = reversed ? _b! : _a!;
    final hi = reversed ? _a! : _b!;
    final r = widget.reference;
    final count = r.ordinalOf(hi.id) - r.ordinalOf(lo.id) + 1;
    final text = 'من ${r.surah(lo.surah).nameAr} (${toArabicDigits(lo.surah)}) آية ${toArabicDigits(lo.ayah)}'
        ' إلى ${r.surah(hi.surah).nameAr} (${toArabicDigits(hi.surah)}) آية ${toArabicDigits(hi.ayah)}'
        ' — ${toArabicDigits(count)} آية';
    return reversed ? '$text\n(تم ترتيب البداية والنهاية تلقائيًا)' : text;
  }

  @override
  Widget build(BuildContext context) {
    final preview = _preview();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        AyahPicker(
          reference: widget.reference,
          label: 'بداية النطاق',
          initial: widget.initialStart,
          onChanged: (v) {
            _a = v;
            _emit();
          },
        ),
        const SizedBox(height: 16),
        AyahPicker(
          reference: widget.reference,
          label: 'نهاية النطاق',
          initial: widget.initialEnd,
          onChanged: (v) {
            _b = v;
            _emit();
          },
        ),
        const SizedBox(height: 16),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Text(
            preview ?? 'اختر بداية النطاق ونهايته لتظهر المعاينة',
            style: Theme.of(context).textTheme.bodyLarge,
          ),
        ),
      ],
    );
  }
}
