import 'package:flutter/material.dart';

import '../../core/arabic_text.dart';

/// End-of-ayah marker: the ayah number inside a circle. Drawn as a widget (not as text) so it
/// looks the same on every device and never depends on shaping of the number sign character.
class AyahMarker extends StatelessWidget {
  const AyahMarker({super.key, required this.number, required this.size});

  final int number;
  final double size;

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.primary;
    final digits = toArabicDigits(number);
    final d = size * (digits.length > 2 ? 1.55 : 1.25);
    return Container(
      width: d,
      height: d,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: color, width: 1.4),
      ),
      child: Text(
        digits,
        style: TextStyle(fontSize: size * 0.52, color: color, height: 1.0),
      ),
    );
  }
}
