import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/arabic_text.dart';
import '../core/ayah_ref.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import 'nav.dart';
import 'theme.dart';

class _HomeData {
  _HomeData({
    required this.position,
    required this.counts,
    required this.due,
    required this.inProgress,
  });
  final PositionRow? position;
  final Map<MemStatus, int> counts;
  final List<ReviewRange> due;
  final int inProgress;
}

class HomeTab extends StatefulWidget {
  const HomeTab({super.key, required this.onOpenTab});

  /// 1 = surahs, 2 = memorization, 3 = review
  final ValueChanged<int> onOpenTab;

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  int _loadedVersion = -1;
  Future<_HomeData>? _future;

  Future<_HomeData> _load(AppState app) async {
    final sv = app.services;
    final position = await sv.position.get();
    final counts = await sv.memorization.counts();
    final due = await sv.review.dueRanges(DateTime.now().millisecondsSinceEpoch);
    final stats = await sv.review.stats();
    return _HomeData(position: position, counts: counts, due: due, inProgress: stats.inProgress);
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    if (_loadedVersion != app.dataVersion || _future == null) {
      _loadedVersion = app.dataVersion;
      _future = _load(app);
    }
    return FutureBuilder<_HomeData>(
      future: _future,
      builder: (context, snap) {
        if (snap.hasError) {
          return Center(child: Text('تعذّر تحميل الصفحة الرئيسية: ${friendlyError(snap.error!)}'));
        }
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        return _content(context, app, snap.data!);
      },
    );
  }

  Widget _content(BuildContext context, AppState app, _HomeData d) {
    final reference = app.services.reference;
    final total = reference.totalAyahs;
    final memorized = d.counts[MemStatus.memorized] ?? 0;
    final learning = d.counts[MemStatus.learning] ?? 0;
    final needs = d.counts[MemStatus.needsReview] ?? 0;
    final theme = Theme.of(context);

    Widget continueCard;
    if (d.position == null) {
      continueCard = Card(
        child: ListTile(
          leading: const Icon(Icons.menu_book),
          title: const Text('ابدأ القراءة'),
          subtitle: const Text('لم يُسجَّل موضع قراءة بعد'),
          trailing: const Icon(Icons.chevron_left),
          onTap: () => openReader(context, surah: 1),
        ),
      );
    } else {
      final r = AyahRef.fromId(d.position!.ayahId);
      final s = reference.surah(r.surah);
      final ordinal = reference.ordinalOf(d.position!.ayahId);
      continueCard = Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('مواصلة القراءة', style: theme.textTheme.titleMedium),
              const SizedBox(height: 8),
              Text('سورة ${s.nameAr} • آية ${toArabicDigits(r.ayah)}',
                  style: surahNameStyle(context, 24)),
              const SizedBox(height: 4),
              Text(
                '${d.position!.manual ? 'حدّدتَ هذا الموضع بنفسك' : 'حُفظ تلقائيًا'} • '
                'الآية رقم ${toArabicDigits(ordinal)} من ${toArabicDigits(total)} في ترتيب المصحف '
                '• ${formatDate(d.position!.updatedAt)}',
                style: theme.textTheme.bodySmall,
              ),
              const SizedBox(height: 12),
              FilledButton.icon(
                icon: const Icon(Icons.play_arrow),
                label: const Text('مواصلة القراءة'),
                onPressed: () => openReader(context, surah: r.surah, ayah: r.ayah),
              ),
            ],
          ),
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        continueCard,
        const SizedBox(height: 8),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('تقدم الحفظ', style: theme.textTheme.titleMedium),
                const SizedBox(height: 8),
                LinearProgressIndicator(value: total == 0 ? 0 : memorized / total, minHeight: 8),
                const SizedBox(height: 8),
                Text('محفوظة: ${toArabicDigits(memorized)} من ${toArabicDigits(total)} آية'),
                Text('قيد الحفظ: ${toArabicDigits(learning)} آية'),
                Text('تحتاج إلى مراجعة: ${toArabicDigits(needs)} آية'),
                const SizedBox(height: 4),
                Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: TextButton(
                    onPressed: () => widget.onOpenTab(2),
                    child: const Text('إدارة الحفظ'),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('المراجعة', style: theme.textTheme.titleMedium),
                const SizedBox(height: 8),
                Text('آيات محفوظة تحتاج إلى مراجعة: ${toArabicDigits(needs)}'),
                Text('نطاقات حان موعد مراجعتها: ${toArabicDigits(d.due.length)}'),
                for (final r in d.due) Text('• ${r.name}', style: theme.textTheme.bodySmall),
                Text('جلسات مراجعة غير منتهية: ${toArabicDigits(d.inProgress)}'),
                const SizedBox(height: 4),
                Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: TextButton(
                    onPressed: () => widget.onOpenTab(3),
                    child: const Text('الذهاب إلى المراجعة'),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        Card(
          child: ListTile(
            leading: const Icon(Icons.list),
            title: const Text('قائمة السور'),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => widget.onOpenTab(1),
          ),
        ),
      ],
    );
  }
}
