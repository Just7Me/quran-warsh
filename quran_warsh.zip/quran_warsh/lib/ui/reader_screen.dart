import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';

import '../core/arabic_text.dart';
import '../core/ayah_ref.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import 'theme.dart';
import 'widgets/ayah_marker.dart';
import 'widgets/ayah_picker.dart';

class ReaderScreen extends StatefulWidget {
  const ReaderScreen({super.key, required this.surah, this.initialAyah = 1});

  final int surah;
  final int initialAyah;

  @override
  State<ReaderScreen> createState() => _ReaderScreenState();
}

class _ReaderData {
  _ReaderData(this.ayahs, this.statuses, this.bookmarkCounts);
  final List<Ayah> ayahs;
  Map<int, MemStatus> statuses;
  Map<int, int> bookmarkCounts;
}

class _ReaderScreenState extends State<ReaderScreen> {
  late int _surah;
  late int _initialAyah;
  late AppState _app;
  bool _appReady = false;

  _ReaderData? _data;
  String? _error;
  int _positionAyahId = 0; // saved reading position (for the marker on screen)

  final ItemScrollController _scroll = ItemScrollController();
  final ItemPositionsListener _positions = ItemPositionsListener.create();
  Timer? _debounce;
  bool _userTouched = false;
  int _topAyah = 1;
  int _lastSavedId = -1;

  @override
  void initState() {
    super.initState();
    _surah = widget.surah;
    _initialAyah = widget.initialAyah;
    _topAyah = widget.initialAyah;
    _positions.itemPositions.addListener(_onPositions);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_appReady) {
      _app = context.read<AppState>();
      _appReady = true;
      _load();
    }
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _positions.itemPositions.removeListener(_onPositions);
    // Leaving the reader: save the place reached, but only if the user actually read/scrolled.
    _persistPosition();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final sv = _app.services;
      final ayahs = await sv.reference.ayahsOfSurah(_surah);
      final statuses = await sv.memorization.statusesForSurah(_surah);
      final bms = await sv.bookmarks.forSurah(_surah);
      final counts = <int, int>{};
      for (final b in bms) {
        counts[b.ayahId] = (counts[b.ayahId] ?? 0) + 1;
      }
      final pos = await sv.position.get();
      if (!mounted) return;
      setState(() {
        _data = _ReaderData(ayahs, statuses, counts);
        _positionAyahId = pos?.ayahId ?? 0;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = 'تعذّر تحميل السورة: ${friendlyError(e)}');
    }
  }

  /// Refreshes states and bookmarks without rebuilding the list (keeps the scroll position).
  Future<void> _reloadMeta() async {
    try {
      final sv = _app.services;
      final statuses = await sv.memorization.statusesForSurah(_surah);
      final bms = await sv.bookmarks.forSurah(_surah);
      final counts = <int, int>{};
      for (final b in bms) {
        counts[b.ayahId] = (counts[b.ayahId] ?? 0) + 1;
      }
      final pos = await sv.position.get();
      if (!mounted || _data == null) return;
      setState(() {
        _data!.statuses = statuses;
        _data!.bookmarkCounts = counts;
        _positionAyahId = pos?.ayahId ?? 0;
      });
    } catch (e) {
      _toast('تعذّر تحديث الشاشة: ${friendlyError(e)}');
    }
  }

  void _toast(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  // ------------------------------------------------------------ position tracking

  void _onPositions() {
    final items = _positions.itemPositions.value;
    final data = _data;
    if (items.isEmpty || data == null) return;
    ItemPosition? top;
    for (final p in items) {
      if (p.itemTrailingEdge > 0.05 && (top == null || p.index < top.index)) top = p;
    }
    if (top == null) return;
    final n = data.ayahs.length;
    final idx = top.index;
    final a = idx < 1 ? 1 : (idx > n ? n : idx); // index 0 is the surah header
    if (a == _topAyah) return;
    _topAyah = a;
    if (!_userTouched) return; // jumps made by the app itself never overwrite the position
    _debounce?.cancel();
    _debounce = Timer(const Duration(seconds: 3), _persistPosition);
  }

  Future<void> _persistPosition() async {
    if (!_userTouched || !_appReady || !_app.autoSave || _data == null) return;
    final id = _surah * 1000 + _topAyah;
    if (id == _lastSavedId) return;
    _lastSavedId = id;
    try {
      final changed = await _app.services.position.saveAuto(id);
      if (changed) _app.bump();
    } catch (e) {
      _app.reportError('تعذّر حفظ موضع القراءة: ${friendlyError(e)}');
    }
  }

  Future<void> _setManualPosition(int ayahId) async {
    try {
      await _app.services.position.setManual(ayahId);
      _lastSavedId = ayahId;
      _app.bump();
      await _reloadMeta();
      final r = AyahRef.fromId(ayahId);
      _toast('تم تحديد ${_app.services.reference.surah(r.surah).nameAr} آية ${toArabicDigits(r.ayah)} كآخر موضع');
    } catch (e) {
      _toast('تعذّر حفظ الموضع: ${friendlyError(e)}');
    }
  }

  // ------------------------------------------------------------ navigation

  Future<void> _switchSurah(int surah, {int ayah = 1}) async {
    _debounce?.cancel();
    await _persistPosition();
    if (!mounted) return;
    setState(() {
      _surah = surah;
      _initialAyah = ayah;
      _topAyah = ayah;
      _lastSavedId = -1;
      _userTouched = false;
      _data = null;
      _error = null;
    });
    await _load();
  }

  Future<void> _goToAyahDialog() async {
    final reference = _app.services.reference;
    AyahRef? chosen;
    final result = await showDialog<AyahRef>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('الانتقال إلى آية'),
          content: SingleChildScrollView(
            child: AyahPicker(
              reference: reference,
              label: 'اختر السورة ورقم الآية',
              initial: AyahRef(_surah, _topAyah),
              onChanged: (v) => setLocal(() => chosen = v),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
            FilledButton(
              onPressed: chosen == null ? null : () => Navigator.pop(ctx, chosen),
              child: const Text('انتقال'),
            ),
          ],
        ),
      ),
    );
    if (result == null || !mounted) return;
    if (result.surah != _surah) {
      await _switchSurah(result.surah, ayah: result.ayah);
    } else {
      _jumpToAyah(result.ayah);
    }
  }

  void _jumpToAyah(int ayah) {
    if (!_scroll.isAttached) return;
    _scroll.jumpTo(index: ayah);
  }

  // ------------------------------------------------------------ actions on one ayah

  Future<String?> _askNote({String? initial, required String title}) async {
    final ctrl = TextEditingController(text: initial ?? '');
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: ctrl,
          maxLength: 500,
          maxLines: 3,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: 'وصف اختياري، مثل: وصلت هنا في قراءة المساء',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text), child: const Text('حفظ')),
        ],
      ),
    );
    ctrl.dispose();
    return result;
  }

  Future<void> _addBookmark(Ayah a) async {
    final note = await _askNote(title: 'إضافة علامة مرجعية');
    if (note == null) return;
    try {
      await _app.services.bookmarks.add(a.id, note: note);
      _app.bump();
      await _reloadMeta();
      _toast('تمت إضافة العلامة');
    } catch (e) {
      _toast('تعذّر حفظ العلامة: ${friendlyError(e)}');
    }
  }

  Future<void> _setStatus(Ayah a, MemStatus s) async {
    try {
      final res = await _app.services.memorization.setSingle(a.id, s);
      _app.bump();
      await _reloadMeta();
      if (res.changed > 0) {
        _toast('تم تعيين الحالة: ${s.label}');
      }
    } catch (e) {
      _toast('تعذّر تغيير الحالة: ${friendlyError(e)}');
    }
  }

  Future<void> _applyRange(MemStatus s, {required int start, required int end}) async {
    final reference = _app.services.reference;
    final ids = await reference.idsInRange(start, end);
    final a = AyahRef.fromId(start);
    final b = AyahRef.fromId(end);
    if (!mounted) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تأكيد تغيير حالة النطاق'),
        content: Text(
          'سيتم تعيين الحالة «${s.label}» لـ ${toArabicDigits(ids.length)} آية\n'
          'من ${reference.surah(a.surah).nameAr} آية ${toArabicDigits(a.ayah)}\n'
          'إلى ${reference.surah(b.surah).nameAr} آية ${toArabicDigits(b.ayah)}\n\n'
          'لن تتأثر أي آية خارج هذا النطاق، ويمكنك التراجع بعد التطبيق.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('تطبيق')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    try {
      final res = await _app.services.memorization
          .applyToIds(ids: ids, status: s, startId: start, endId: end);
      _app.clearRange();
      _app.bump();
      await _reloadMeta();
      if (!mounted) return;
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(
          content: Text(res.changed == 0
              ? 'لا تغيير: كل آيات النطاق بهذه الحالة أصلًا'
              : 'تم تغيير ${toArabicDigits(res.changed)} آية'),
          action: res.changed == 0
              ? null
              : SnackBarAction(label: 'تراجع', onPressed: _undo),
          duration: const Duration(seconds: 8),
        ));
    } catch (e) {
      _toast('تعذّر تطبيق الحالة على النطاق: ${friendlyError(e)}');
    }
  }

  Future<void> _undo() async {
    try {
      final n = await _app.services.memorization.undoLast();
      _app.bump();
      await _reloadMeta();
      _toast(n == null ? 'لا يوجد ما يمكن التراجع عنه' : 'تم التراجع عن ${toArabicDigits(n)} آية');
    } catch (e) {
      _toast('تعذّر التراجع: ${friendlyError(e)}');
    }
  }

  Future<void> _showActions(Ayah a) async {
    final reference = _app.services.reference;
    final current = _data?.statuses[a.id] ?? MemStatus.notStarted;
    final disputed = reference.disputed[a.id];
    final bmCount = _data?.bookmarkCounts[a.id] ?? 0;
    final surahName = reference.surah(a.surah).nameAr;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) {
        return SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'سورة $surahName • آية ${toArabicDigits(a.ayah)}',
                  style: Theme.of(ctx).textTheme.titleMedium,
                ),
                if (disputed != null) ...[
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Theme.of(ctx).colorScheme.errorContainer,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      'تنبيه: هذه الآية تختلف في الرسم أو الضبط بين إصداري مجمع الملك فهد '
                      '(٢٠٢٢ و٢٠٢٦) ولم يُحسم الاختلاف آليًا. راجعها في المصحف المطبوع. '
                      'اسم الملف المرجعي وتفاصيل الاختلاف في تقرير صحة البيانات.',
                      style: TextStyle(color: Theme.of(ctx).colorScheme.onErrorContainer),
                    ),
                  ),
                ],
                const SizedBox(height: 12),
                Text('حالة الحفظ', style: Theme.of(ctx).textTheme.titleSmall),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: [
                    for (final s in MemStatus.values)
                      ChoiceChip(
                        label: Text(s.label),
                        selected: s == current,
                        onSelected: (_) {
                          Navigator.pop(ctx);
                          _setStatus(a, s);
                        },
                      ),
                  ],
                ),
                const Divider(height: 24),
                ListTile(
                  leading: const Icon(Icons.bookmark_border),
                  title: Text(bmCount == 0 ? 'إضافة علامة مرجعية' : 'إضافة علامة أخرى (يوجد ${toArabicDigits(bmCount)})'),
                  onTap: () {
                    Navigator.pop(ctx);
                    _addBookmark(a);
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.push_pin_outlined),
                  title: const Text('تحديد كآخر موضع وصلت إليه'),
                  onTap: () {
                    Navigator.pop(ctx);
                    _setManualPosition(a.id);
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.flag_outlined),
                  title: const Text('تحديد كبداية للنطاق'),
                  onTap: () {
                    Navigator.pop(ctx);
                    _app.setRangeStart(a.ref);
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.outlined_flag),
                  title: const Text('تحديد كنهاية للنطاق'),
                  onTap: () {
                    Navigator.pop(ctx);
                    _app.setRangeEnd(a.ref);
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ------------------------------------------------------------ build

  Widget _rangeBanner(AppState app) {
    final reference = app.services.reference;
    final a = app.rangeStart;
    final b = app.rangeEnd;
    if (a == null && b == null) return const SizedBox.shrink();
    String label(AyahRef r) => '${reference.surah(r.surah).nameAr} ${toArabicDigits(r.ayah)}';
    final ordered = app.orderedRange;
    var text = '';
    if (ordered == null) {
      text = a != null
          ? 'بداية النطاق: ${label(a)} — اضغط آية أخرى واختر «نهاية للنطاق»'
          : 'نهاية النطاق: ${label(b!)} — اضغط آية واختر «بداية للنطاق»';
    } else {
      final lo = AyahRef.fromId(ordered.start);
      final hi = AyahRef.fromId(ordered.end);
      final count = reference.ordinalOf(ordered.end) - reference.ordinalOf(ordered.start) + 1;
      text = 'النطاق: من ${label(lo)} إلى ${label(hi)} — ${toArabicDigits(count)} آية';
    }
    return Material(
      color: Theme.of(context).colorScheme.secondaryContainer,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(text, style: TextStyle(color: Theme.of(context).colorScheme.onSecondaryContainer)),
            Wrap(
              spacing: 6,
              children: [
                if (ordered != null)
                  for (final s in MemStatus.values)
                    ActionChip(
                      label: Text(s.label),
                      onPressed: () => _applyRange(s, start: ordered.start, end: ordered.end),
                    ),
                TextButton(onPressed: app.clearRange, child: const Text('مسح النطاق')),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final surah = app.services.reference.surah(_surah);
    return Scaffold(
      appBar: AppBar(
        title: Text(surah.nameAr, style: surahNameStyle(context, 24)),
        actions: [
          IconButton(
            icon: const Icon(Icons.push_pin_outlined),
            tooltip: 'حفظ موضعي الحالي',
            onPressed: _data == null ? null : () => _setManualPosition(_surah * 1000 + _topAyah),
          ),
          IconButton(
            icon: const Icon(Icons.format_list_numbered),
            tooltip: 'الانتقال إلى آية',
            onPressed: _data == null ? null : _goToAyahDialog,
          ),
        ],
      ),
      body: Column(
        children: [
          _rangeBanner(app),
          Expanded(child: _buildBody(app, surah)),
        ],
      ),
    );
  }

  Widget _buildBody(AppState app, Surah surah) {
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(_error!, textAlign: TextAlign.center),
              const SizedBox(height: 12),
              FilledButton(onPressed: _load, child: const Text('إعادة المحاولة')),
            ],
          ),
        ),
      );
    }
    final data = _data;
    if (data == null) return const Center(child: CircularProgressIndicator());
    final reference = app.services.reference;
    final brightness = Theme.of(context).brightness;
    final n = data.ayahs.length;
    final ordered = app.orderedRange;
    final initialIndex = _initialAyah <= 1 ? 0 : (_initialAyah > n ? n : _initialAyah);

    return Listener(
      onPointerDown: (_) => _userTouched = true,
      child: ScrollablePositionedList.builder(
        key: ValueKey('reader-$_surah'),
        itemScrollController: _scroll,
        itemPositionsListener: _positions,
        initialScrollIndex: initialIndex,
        itemCount: n + 2,
        itemBuilder: (context, index) {
          if (index == 0) return _header(surah, app);
          if (index == n + 1) return _footer();
          final a = data.ayahs[index - 1];
          final status = data.statuses[a.id] ?? MemStatus.notStarted;
          final inRange = ordered != null && a.id >= ordered.start && a.id <= ordered.end;
          return _AyahTile(
            ayah: a,
            status: status,
            bookmarkCount: data.bookmarkCounts[a.id] ?? 0,
            disputed: reference.disputed.containsKey(a.id),
            inRange: inRange,
            isRangeStart: app.rangeStart?.id == a.id,
            isRangeEnd: app.rangeEnd?.id == a.id,
            isPosition: _positionAyahId == a.id,
            fontSize: app.fontSize,
            brightness: brightness,
            onTap: () => _showActions(a),
          );
        },
      ),
    );
  }

  Widget _header(Surah surah, AppState app) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
              border: Border.all(color: Theme.of(context).colorScheme.primary, width: 1.2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              children: [
                Text(surah.heading,
                    textAlign: TextAlign.center,
                    textDirection: TextDirection.rtl,
                    style: surahNameStyle(context, app.fontSize * 0.9,
                        color: Theme.of(context).colorScheme.primary)),
                Text('عدد الآيات: ${toArabicDigits(surah.ayahCount)}',
                    style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
          if (surah.basmalah != null && surah.basmalah!.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Text(
                surah.basmalah!,
                textAlign: TextAlign.center,
                textDirection: TextDirection.rtl,
                style: quranStyle(context, app.fontSize),
              ),
            ),
        ],
      ),
    );
  }

  Widget _footer() {
    final reference = _app.services.reference;
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          if (_surah > 1)
            Expanded(
              child: OutlinedButton(
                onPressed: () => _switchSurah(_surah - 1),
                child: Text('السابقة: ${reference.surah(_surah - 1).nameAr}'),
              ),
            ),
          if (_surah > 1 && _surah < 114) const SizedBox(width: 10),
          if (_surah < 114)
            Expanded(
              child: FilledButton(
                onPressed: () => _switchSurah(_surah + 1),
                child: Text('التالية: ${reference.surah(_surah + 1).nameAr}'),
              ),
            ),
        ],
      ),
    );
  }
}

class _AyahTile extends StatelessWidget {
  const _AyahTile({
    required this.ayah,
    required this.status,
    required this.bookmarkCount,
    required this.disputed,
    required this.inRange,
    required this.isRangeStart,
    required this.isRangeEnd,
    required this.isPosition,
    required this.fontSize,
    required this.brightness,
    required this.onTap,
  });

  final Ayah ayah;
  final MemStatus status;
  final int bookmarkCount;
  final bool disputed;
  final bool inRange;
  final bool isRangeStart;
  final bool isRangeEnd;
  final bool isPosition;
  final double fontSize;
  final Brightness brightness;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final bar = statusColor(status, brightness);
    final tint = statusTint(status, brightness);
    final chips = <Widget>[];
    Widget chip(IconData icon, String label, Color color) => Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 16, color: color),
            const SizedBox(width: 3),
            Text(label, style: TextStyle(fontSize: 12, color: color)),
          ],
        );
    if (status != MemStatus.notStarted) chips.add(chip(Icons.circle, status.label, bar));
    if (bookmarkCount > 0) chips.add(chip(Icons.bookmark, 'علامة', scheme.primary));
    if (isPosition) chips.add(chip(Icons.push_pin, 'آخر موضع', scheme.tertiary));
    if (isRangeStart) chips.add(chip(Icons.flag, 'بداية النطاق', scheme.secondary));
    if (isRangeEnd) chips.add(chip(Icons.outlined_flag, 'نهاية النطاق', scheme.secondary));
    if (disputed) chips.add(chip(Icons.warning_amber_rounded, 'تختلف بين إصداري المجمع', scheme.error));

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Material(
          color: tint,
          child: InkWell(
            onTap: onTap,
            child: Container(
              decoration: inRange
                  ? BoxDecoration(
                      border: Border.all(color: scheme.secondary, width: 1.5),
                      borderRadius: BorderRadius.circular(10),
                    )
                  : null,
              child: Stack(
                children: [
                  Padding(
                    padding: const EdgeInsetsDirectional.fromSTEB(18, 8, 12, 8),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text.rich(
                          TextSpan(
                            children: [
                              TextSpan(text: ayah.text),
                              const TextSpan(text: ' '),
                              WidgetSpan(
                                alignment: PlaceholderAlignment.middle,
                                child: AyahMarker(number: ayah.ayah, size: fontSize * 0.8),
                              ),
                            ],
                            style: quranStyle(context, fontSize),
                          ),
                          textAlign: TextAlign.justify,
                          textDirection: TextDirection.rtl,
                        ),
                        if (chips.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 2),
                            child: Wrap(spacing: 12, runSpacing: 2, children: chips),
                          ),
                      ],
                    ),
                  ),
                  PositionedDirectional(
                    start: 0,
                    top: 0,
                    bottom: 0,
                    width: 5,
                    child: ColoredBox(color: bar),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
