import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import 'bookmarks_screen.dart';
import 'home_tab.dart';
import 'memorization_tab.dart';
import 'review_tab.dart';
import 'search_screen.dart';
import 'settings_screen.dart';
import 'surahs_tab.dart';

/// Main screen: four tabs and shortcuts to search, bookmarks and settings.
class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _index = 0;

  static const _titles = ['مصحف ورش', 'السور', 'الحفظ', 'المراجعة'];

  void _push(Widget page) {
    Navigator.of(context).push<void>(MaterialPageRoute<void>(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    // Errors that could not be shown where they happened (for example while leaving the reader).
    if (app.pendingError != null) {
      final msg = app.pendingError!;
      app.clearError();
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        ScaffoldMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 8)));
      });
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(_titles[_index]),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            tooltip: 'بحث',
            onPressed: () => _push(const SearchScreen()),
          ),
          IconButton(
            icon: const Icon(Icons.bookmarks_outlined),
            tooltip: 'العلامات المرجعية',
            onPressed: () => _push(const BookmarksScreen()),
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            tooltip: 'الإعدادات',
            onPressed: () => _push(const SettingsScreen()),
          ),
        ],
      ),
      body: IndexedStack(
        index: _index,
        children: [
          HomeTab(onOpenTab: (i) => setState(() => _index = i)),
          const SurahsTab(),
          const MemorizationTab(),
          const ReviewTab(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'السور'),
          NavigationDestination(icon: Icon(Icons.school_outlined), selectedIcon: Icon(Icons.school), label: 'الحفظ'),
          NavigationDestination(icon: Icon(Icons.replay_outlined), selectedIcon: Icon(Icons.replay), label: 'المراجعة'),
        ],
      ),
    );
  }
}
