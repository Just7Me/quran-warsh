import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/arabic_text.dart';
import '../core/ayah_ref.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import 'nav.dart';
import 'widgets/range_form.dart';

/// Change the memorization state of a chosen range (one ayah or many, possibly across surahs).
class RangeStatusPage extends StatefulWidget {
  const RangeStatusPage({super.key});

  @override
  State<RangeStatusPage> createState() => _RangeStatusPageState();
}

class _RangeStatusPageState extends State<RangeStatusPage> {
  ({int start, int end})? _range;
  MemStatus _status = MemStatus.memorized;
  bool _busy = false;

  Future<void> _apply(AppState app) async {
    final r = _range;
    if (r == null || _busy) return;
    final reference = app.services.reference;
    final a = AyahRef.fromId(r.start);
    final b = AyahRef.fromId(r.end);
    // Both ends are re-validated against the reference database before anything is written.
    if (!reference.isValid(a.surah, a.ayah) || !reference.isValid(b.surah, b.ayah)) {
      showMessage(context, 'النطاق غير صحيح');
      return;
    }
    final ids = await reference.idsInRange(r.start, r.end);
    if (!mounted) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تأكيد'),
        content: Text(
          'سيتم تعيين الحالة «${_status.label}» لـ ${toArabicDigits(ids.length)} آية\n'
          'من ${reference.surah(a.surah).nameAr} آية ${toArabicDigits(a.ayah)}\n'
          'إلى ${reference.surah(b.surah).nameAr} آية ${toArabicDigits(b.ayah)}',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('تطبيق')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    setState(() => _busy = true);
    try {
      final res = await app.services.memorization
          .applyToIds(ids: ids, status: _status, startId: r.start, endId: r.end);
      app.bump();
      if (!mounted) return;
      showMessage(
          context,
          res.changed == 0
              ? 'لا تغيير: كل الآيات بهذه الحالة أصلًا'
              : 'تم تغيير ${toArabicDigits(res.changed)} آية. يمكنك التراجع من شاشة الحفظ.');
      Navigator.of(context).pop();
    } catch (e) {
      if (!mounted) return;
      setState(() => _busy = false);
      showMessage(context, 'تعذّر تطبيق الحالة: ${friendlyError(e)}');
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.read<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('تغيير حالة نطاق')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          RangeForm(
            reference: app.services.reference,
            onChanged: (v) => setState(() => _range = v),
          ),
          const SizedBox(height: 16),
          Text('الحالة الجديدة', style: Theme.of(context).textTheme.titleSmall),
          for (final s in MemStatus.values)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(s == _status ? Icons.radio_button_checked : Icons.radio_button_off),
              title: Text(s.label),
              onTap: () => setState(() => _status = s),
            ),
          const SizedBox(height: 8),
          FilledButton(
            onPressed: (_range == null || _busy) ? null : () => _apply(app),
            child: _busy
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('تطبيق على النطاق'),
          ),
        ],
      ),
    );
  }
}
