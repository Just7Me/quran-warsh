import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/arabic_text.dart';
import '../data/repositories/memorization_repo.dart';
import '../state/app_state.dart';
import 'nav.dart';
import 'theme.dart';

class SurahsTab extends StatefulWidget {
  const SurahsTab({super.key});

  @override
  State<SurahsTab> createState() => _SurahsTabState();
}

class _SurahsTabState extends State<SurahsTab> {
  int _loadedVersion = -1;
  Future<Map<int, SurahMemCounts>>? _future;

  Future<Map<int, SurahMemCounts>> _load(AppState app) async {
    final list = await app.services.memorization.perSurah();
    return {for (final c in list) c.surah: c};
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    if (_loadedVersion != app.dataVersion || _future == null) {
      _loadedVersion = app.dataVersion;
      _future = _load(app);
    }
    final surahs = app.services.reference.surahs;
    return FutureBuilder<Map<int, SurahMemCounts>>(
      future: _future,
      builder: (context, snap) {
        final counts = snap.data ?? const <int, SurahMemCounts>{};
        return ListView.separated(
          itemCount: surahs.length,
          separatorBuilder: (_, __) => const Divider(height: 1),
          itemBuilder: (context, i) {
            final s = surahs[i];
            final c = counts[s.number];
            final parts = <String>['${toArabicDigits(s.ayahCount)} آية'];
            if (c != null && c.memorized > 0) parts.add('محفوظ ${toArabicDigits(c.memorized)}');
            if (c != null && c.needsReview > 0) parts.add('مراجعة ${toArabicDigits(c.needsReview)}');
            return ListTile(
              leading: CircleAvatar(
                backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                foregroundColor: Theme.of(context).colorScheme.onPrimaryContainer,
                child: Text(toArabicDigits(s.number), style: const TextStyle(fontSize: 14)),
              ),
              title: Text(s.nameAr, style: surahNameStyle(context, 24)),
              subtitle: Text(parts.join(' • ')),
              onTap: () => openReader(context, surah: s.number),
            );
          },
        );
      },
    );
  }
}
