import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/arabic_text.dart';
import '../core/ayah_ref.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import 'nav.dart';
import 'review_range_editor.dart';
import 'review_session_screen.dart';
import 'sessions_screen.dart';
import 'needs_review_screen.dart';

class _ReviewData {
  _ReviewData(this.ranges, this.needsCount, this.stats);
  final List<ReviewRange> ranges;
  final int needsCount;
  final ({int sessions, int completed, int partial, int inProgress, int? lastAt}) stats;
}

class ReviewTab extends StatefulWidget {
  const ReviewTab({super.key});

  @override
  State<ReviewTab> createState() => _ReviewTabState();
}

class _ReviewTabState extends State<ReviewTab> {
  int _loadedVersion = -1;
  Future<_ReviewData>? _future;

  Future<_ReviewData> _load(AppState app) async {
    final sv = app.services;
    final ranges = await sv.review.listRanges();
    final counts = await sv.memorization.counts();
    final stats = await sv.review.stats();
    return _ReviewData(ranges, counts[MemStatus.needsReview] ?? 0, stats);
  }

  String _rangeText(AppState app, ReviewRange r) {
    final ref = app.services.reference;
    final a = AyahRef.fromId(r.startId);
    final b = AyahRef.fromId(r.endId);
    final count = ref.ordinalOf(r.endId) - ref.ordinalOf(r.startId) + 1;
    return 'من ${ref.surah(a.surah).nameAr} ${toArabicDigits(a.ayah)} '
        'إلى ${ref.surah(b.surah).nameAr} ${toArabicDigits(b.ayah)} '
        '(${toArabicDigits(count)} آية)';
  }

  Future<void> _start(AppState app, ReviewRange r) async {
    try {
      final id = await app.services.review.startOrResume(r);
      app.bump();
      if (!mounted) return;
      await Navigator.of(context).push<void>(MaterialPageRoute<void>(
        builder: (_) => ReviewSessionScreen(rangeId: r.id, sessionId: id),
      ));
      app.bump();
    } catch (e) {
      if (!mounted) return;
      showMessage(context, 'تعذّر بدء المراجعة: ${friendlyError(e)}');
    }
  }

  Future<void> _pickNextReview(AppState app, ReviewRange r) async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: r.nextReviewAt != null
          ? DateTime.fromMillisecondsSinceEpoch(r.nextReviewAt!)
          : now.add(const Duration(days: 1)),
      firstDate: DateTime(now.year - 1),
      lastDate: DateTime(now.year + 5),
      helpText: 'موعد المراجعة التالية',
    );
    if (picked == null) return;
    try {
      await app.services.review.setNextReview(r.id, picked.millisecondsSinceEpoch);
      app.bump();
    } catch (e) {
      if (!mounted) return;
      showMessage(context, 'تعذّر حفظ الموعد: ${friendlyError(e)}');
    }
  }

  Future<void> _delete(AppState app, ReviewRange r) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف نطاق المراجعة'),
        content: Text('سيُحذف النطاق «${r.name}». يبقى سجل جلسات المراجعة السابقة، ولا تتأثر حالات الحفظ.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await app.services.review.deleteRange(r.id);
      app.bump();
    } catch (e) {
      if (!mounted) return;
      showMessage(context, 'تعذّر الحذف: ${friendlyError(e)}');
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    if (_loadedVersion != app.dataVersion || _future == null) {
      _loadedVersion = app.dataVersion;
      _future = _load(app);
    }
    return FutureBuilder<_ReviewData>(
      future: _future,
      builder: (context, snap) {
        if (snap.hasError) {
          return Center(child: Text('تعذّر التحميل: ${friendlyError(snap.error!)}'));
        }
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final d = snap.data!;
        final theme = Theme.of(context);
        return Scaffold(
          backgroundColor: Colors.transparent,
          floatingActionButton: FloatingActionButton.extended(
            icon: const Icon(Icons.add),
            label: const Text('نطاق مراجعة جديد'),
            onPressed: () async {
              await Navigator.of(context).push<void>(
                MaterialPageRoute<void>(builder: (_) => const ReviewRangeEditor()),
              );
            },
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 96),
            children: [
              Card(
                child: ListTile(
                  leading: const Icon(Icons.priority_high),
                  title: const Text('محفوظ يحتاج إلى مراجعة'),
                  subtitle: Text('${toArabicDigits(d.needsCount)} آية'),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.of(context).push<void>(
                    MaterialPageRoute<void>(builder: (_) => const NeedsReviewScreen()),
                  ),
                ),
              ),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.history),
                  title: const Text('سجل جلسات المراجعة'),
                  subtitle: Text(
                    d.stats.sessions == 0
                        ? 'لا توجد جلسات مسجلة بعد'
                        : 'تامة: ${toArabicDigits(d.stats.completed)} • جزئية: ${toArabicDigits(d.stats.partial)}'
                            ' • غير منتهية: ${toArabicDigits(d.stats.inProgress)}'
                            '${d.stats.lastAt != null ? ' • آخر نشاط ${formatDate(d.stats.lastAt!)}' : ''}',
                  ),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.of(context).push<void>(
                    MaterialPageRoute<void>(builder: (_) => const SessionsScreen()),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Text('نطاقات المراجعة', style: theme.textTheme.titleMedium),
              if (d.ranges.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  child: Text('لم تُنشئ نطاقات مراجعة بعد. اضغط «نطاق مراجعة جديد».'),
                ),
              for (final r in d.ranges)
                Card(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(child: Text(r.name, style: theme.textTheme.titleSmall)),
                            PopupMenuButton<String>(
                              onSelected: (v) async {
                                if (v == 'edit') {
                                  await Navigator.of(context).push<void>(MaterialPageRoute<void>(
                                    builder: (_) => ReviewRangeEditor(existing: r),
                                  ));
                                } else if (v == 'date') {
                                  await _pickNextReview(app, r);
                                } else if (v == 'cleardate') {
                                  await app.services.review.setNextReview(r.id, null);
                                  app.bump();
                                } else if (v == 'extra') {
                                  await app.services.review.setNeedsExtra(r.id, !r.needsExtra);
                                  app.bump();
                                } else if (v == 'delete') {
                                  await _delete(app, r);
                                }
                              },
                              itemBuilder: (_) => [
                                const PopupMenuItem(value: 'edit', child: Text('تعديل الاسم والنطاق')),
                                const PopupMenuItem(value: 'date', child: Text('تحديد موعد المراجعة التالية')),
                                if (r.nextReviewAt != null)
                                  const PopupMenuItem(value: 'cleardate', child: Text('إلغاء الموعد')),
                                PopupMenuItem(
                                  value: 'extra',
                                  child: Text(r.needsExtra
                                      ? 'إزالة علامة «يحتاج مراجعة إضافية»'
                                      : 'الإشارة إلى أنه يحتاج مراجعة إضافية'),
                                ),
                                const PopupMenuItem(value: 'delete', child: Text('حذف النطاق')),
                              ],
                            ),
                          ],
                        ),
                        Text(_rangeText(app, r), style: theme.textTheme.bodySmall),
                        const SizedBox(height: 6),
                        Wrap(
                          spacing: 8,
                          runSpacing: 4,
                          children: [
                            if (r.inProgressSessionId != null)
                              const Chip(label: Text('بدأتَ مراجعته ولم تنتهِ')),
                            if (r.needsExtra) const Chip(label: Text('يحتاج مراجعة إضافية')),
                            if (r.nextReviewAt != null)
                              Chip(label: Text('الموعد: ${formatDate(r.nextReviewAt!)}')),
                            if (r.lastCompletedAt != null)
                              Chip(label: Text('آخر مراجعة تامة: ${formatDate(r.lastCompletedAt!)}')),
                          ],
                        ),
                        const SizedBox(height: 6),
                        FilledButton.tonal(
                          onPressed: () => _start(app, r),
                          child: Text(r.inProgressSessionId != null ? 'متابعة المراجعة' : 'بدء المراجعة'),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}
