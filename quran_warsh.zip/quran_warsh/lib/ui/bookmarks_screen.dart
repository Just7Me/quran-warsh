import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/arabic_text.dart';
import '../core/ayah_ref.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import 'nav.dart';

/// All bookmarks. Each can be opened, edited (its optional description) or deleted.
class BookmarksScreen extends StatefulWidget {
  const BookmarksScreen({super.key});

  @override
  State<BookmarksScreen> createState() => _BookmarksScreenState();
}

class _BookmarksScreenState extends State<BookmarksScreen> {
  List<Bookmark>? _items;
  String? _error;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    final app = context.read<AppState>();
    try {
      final list = await app.services.bookmarks.list();
      if (!mounted) return;
      setState(() {
        _items = list;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = 'تعذّر تحميل العلامات: ${friendlyError(e)}');
    }
  }

  Future<void> _edit(Bookmark b) async {
    final app = context.read<AppState>();
    final ctrl = TextEditingController(text: b.note ?? '');
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تعديل وصف العلامة'),
        content: TextField(
          controller: ctrl,
          maxLength: 500,
          maxLines: 3,
          autofocus: true,
          decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'وصف اختياري'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text), child: const Text('حفظ')),
        ],
      ),
    );
    ctrl.dispose();
    if (result == null) return;
    try {
      await app.services.bookmarks.updateNote(b.id, result);
      app.bump();
      await _load();
    } catch (e) {
      if (!mounted) return;
      showMessage(context, 'تعذّر تعديل العلامة: ${friendlyError(e)}');
    }
  }

  Future<void> _delete(Bookmark b) async {
    final app = context.read<AppState>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف العلامة'),
        content: const Text('هل تريد حذف هذه العلامة المرجعية؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حذف')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await app.services.bookmarks.delete(b.id);
      app.bump();
      await _load();
    } catch (e) {
      if (!mounted) return;
      showMessage(context, 'تعذّر حذف العلامة: ${friendlyError(e)}');
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final ref = app.services.reference;
    return Scaffold(
      appBar: AppBar(title: const Text('العلامات المرجعية')),
      body: _error != null
          ? Center(child: Text(_error!))
          : _items == null
              ? const Center(child: CircularProgressIndicator())
              : _items!.isEmpty
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.all(24),
                        child: Text('لا توجد علامات بعد. اضغط على أي آية أثناء القراءة لإضافة علامة.',
                            textAlign: TextAlign.center),
                      ),
                    )
                  : ListView.separated(
                      itemCount: _items!.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (context, i) {
                        final b = _items![i];
                        final r = AyahRef.fromId(b.ayahId);
                        return ListTile(
                          leading: const Icon(Icons.bookmark),
                          title: Text('${ref.surah(r.surah).nameAr} • آية ${toArabicDigits(r.ayah)}'),
                          subtitle: Text(
                            [
                              if (b.note != null && b.note!.isNotEmpty) b.note!,
                              formatDate(b.createdAt),
                            ].join('\n'),
                          ),
                          isThreeLine: b.note != null && b.note!.isNotEmpty,
                          onTap: () => openReader(context, surah: r.surah, ayah: r.ayah),
                          trailing: PopupMenuButton<String>(
                            onSelected: (v) => v == 'edit' ? _edit(b) : _delete(b),
                            itemBuilder: (_) => const [
                              PopupMenuItem(value: 'edit', child: Text('تعديل الوصف')),
                              PopupMenuItem(value: 'delete', child: Text('حذف')),
                            ],
                          ),
                        );
                      },
                    ),
    );
  }
}
