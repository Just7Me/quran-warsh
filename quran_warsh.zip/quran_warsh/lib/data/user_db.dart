import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// The user's own data (position, bookmarks, memorization, review, settings).
/// Stored in a separate database file from the Quran text.
class UserDb {
  UserDb._(this.db, this.path);

  final Database db;
  final String path;

  static const String schemaAsset = 'assets/sql/user_schema.sql';
  static const String fileName = 'user_data.db';
  static const int schemaVersion = 1;

  static Future<UserDb> openInApp(String directory) async {
    final schema = await rootBundle.loadString(schemaAsset);
    return open(p.join(directory, fileName), schema);
  }

  /// [path] may be [inMemoryDatabasePath] in tests.
  static Future<UserDb> open(String path, String schemaSql) async {
    final db = await openDatabase(
      path,
      version: schemaVersion,
      singleInstance: false,
      onConfigure: (d) async {
        await d.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (d, version) async {
        for (final stmt in splitStatements(schemaSql)) {
          await d.execute(stmt);
        }
      },
      onUpgrade: (d, oldVersion, newVersion) async {
        // No migrations yet. Future versions add explicit steps here and never drop user data.
      },
    );
    return UserDb._(db, path);
  }

  Future<void> close() => db.close();

  /// Splits a schema file into statements. Comment lines are removed first.
  static List<String> splitStatements(String sql) {
    final lines = sql.split('\n').where((l) => !l.trimLeft().startsWith('--')).join('\n');
    return lines.split(';').map((s) => s.trim()).where((s) => s.isNotEmpty).toList();
  }
}
