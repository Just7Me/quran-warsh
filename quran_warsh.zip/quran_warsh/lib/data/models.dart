import '../core/ayah_ref.dart';

class Surah {
  const Surah({
    required this.number,
    required this.nameAr,
    required this.nameEn,
    required this.heading,
    required this.basmalah,
    required this.ayahCount,
    required this.nameFold,
  });

  final int number;
  final String nameAr;
  final String nameEn;
  final String heading;
  final String? basmalah;
  final int ayahCount;
  final String nameFold;

  int get firstId => number * 1000 + 1;
  int get lastId => number * 1000 + ayahCount;

  factory Surah.fromRow(Map<String, Object?> r) => Surah(
        number: r['number']! as int,
        nameAr: (r['name_ar']! as String).trim(),
        nameEn: (r['name_en']! as String).trim(),
        heading: (r['heading']! as String).trim(),
        basmalah: (r['basmalah'] as String?)?.trim(),
        ayahCount: r['ayah_count']! as int,
        nameFold: r['name_fold']! as String,
      );
}

class Ayah {
  const Ayah({required this.id, required this.surah, required this.ayah, required this.text});

  final int id;
  final int surah;
  final int ayah;
  final String text;

  AyahRef get ref => AyahRef(surah, ayah);

  factory Ayah.fromRow(Map<String, Object?> r) => Ayah(
        id: r['id']! as int,
        surah: r['surah']! as int,
        ayah: r['ayah']! as int,
        text: r['text']! as String,
      );
}

/// Memorization state of one ayah. [notStarted] is stored as the absence of a row.
enum MemStatus {
  notStarted('not_started', 'لم أبدأ'),
  learning('learning', 'قيد الحفظ'),
  memorized('memorized', 'محفوظة'),
  needsReview('needs_review', 'تحتاج إلى مراجعة');

  const MemStatus(this.dbValue, this.label);
  final String dbValue;
  final String label;

  static MemStatus fromDb(String? v) {
    for (final s in MemStatus.values) {
      if (s.dbValue == v) return s;
    }
    return MemStatus.notStarted;
  }

  static MemStatus? tryParse(Object? v) {
    if (v is! String) return null;
    for (final s in MemStatus.values) {
      if (s.dbValue == v) return s;
    }
    return null;
  }
}

class PositionRow {
  const PositionRow({required this.ayahId, required this.manual, required this.updatedAt});
  final int ayahId;
  final bool manual;
  final int updatedAt;
}

class Bookmark {
  const Bookmark({
    required this.id,
    required this.ayahId,
    required this.note,
    required this.createdAt,
    required this.updatedAt,
  });

  final int id;
  final int ayahId;
  final String? note;
  final int createdAt;
  final int updatedAt;

  factory Bookmark.fromRow(Map<String, Object?> r) => Bookmark(
        id: r['id']! as int,
        ayahId: r['ayah_id']! as int,
        note: r['note'] as String?,
        createdAt: r['created_at']! as int,
        updatedAt: r['updated_at']! as int,
      );
}

class ReviewRange {
  const ReviewRange({
    required this.id,
    required this.name,
    required this.startId,
    required this.endId,
    required this.nextReviewAt,
    required this.needsExtra,
    required this.inProgressSessionId,
    required this.lastCompletedAt,
  });

  final int id;
  final String name;
  final int startId;
  final int endId;
  final int? nextReviewAt;
  final bool needsExtra;

  /// A session that was started and neither completed nor closed as partial.
  final int? inProgressSessionId;

  /// Finish time of the most recent session whose outcome was `completed`.
  final int? lastCompletedAt;
}

class ReviewSession {
  const ReviewSession({
    required this.id,
    required this.rangeId,
    required this.rangeName,
    required this.startId,
    required this.endId,
    required this.startedAt,
    required this.finishedAt,
    required this.outcome,
    required this.reviewedCount,
  });

  final int id;
  final int? rangeId;
  final String rangeName;
  final int startId;
  final int endId;
  final int startedAt;
  final int? finishedAt;

  /// in_progress, completed or partial
  final String outcome;
  final int reviewedCount;
}

class SearchHit {
  const SearchHit({required this.ayah});
  final Ayah ayah;
}
