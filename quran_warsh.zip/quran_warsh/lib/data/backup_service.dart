import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:sqflite/sqflite.dart';

import 'models.dart';
import 'reference_db.dart';

class BackupException implements Exception {
  BackupException(this.message);
  final String message;
  @override
  String toString() => message;
}

class BackupSummary {
  const BackupSummary({
    required this.bookmarks,
    required this.memorization,
    required this.reviewRanges,
    required this.reviewSessions,
    required this.createdAt,
    required this.hasPosition,
  });
  final int bookmarks;
  final int memorization;
  final int reviewRanges;
  final int reviewSessions;
  final int createdAt;
  final bool hasPosition;
}

/// Backup of the USER's data only. It contains ayah ids and the user's own notes, never any
/// Quran text. On restore, a file containing anything outside the allowed shape is rejected,
/// every ayah id is checked against the reference database, and the whole restore runs in one
/// transaction: if anything fails nothing is changed. The reference database is a different
/// file and is never opened for writing, so a backup cannot alter or replace the Quran text.
class BackupService {
  BackupService({required this.userDb, required this.reference});

  final Database userDb;
  final ReferenceDb reference;

  static const String format = 'quran-warsh-backup';
  static const int version = 1;
  static const Set<String> _allowedSettingKeys = {'theme_mode', 'font_size', 'auto_save'};
  static const int _maxNoteLength = 500;
  static const int _maxRows = 100000;

  // ---------------------------------------------------------------- export

  Future<String> exportJson() async {
    final data = <String, Object?>{
      'settings': [
        for (final r in await userDb.query('app_settings', orderBy: 'key'))
          if (_allowedSettingKeys.contains(r['key'])) {'key': r['key'], 'value': r['value']},
      ],
      'position': [
        for (final r in await userDb.query('reading_position'))
          {'ayah_id': r['ayah_id'], 'source': r['source'], 'updated_at': r['updated_at']},
      ],
      'bookmarks': [
        for (final r in await userDb.query('bookmarks', orderBy: 'id'))
          {
            'ayah_id': r['ayah_id'],
            'note': r['note'],
            'created_at': r['created_at'],
            'updated_at': r['updated_at'],
          },
      ],
      'memorization': [
        for (final r in await userDb.query('memorization', orderBy: 'ayah_id'))
          {'ayah_id': r['ayah_id'], 'status': r['status'], 'updated_at': r['updated_at']},
      ],
      'review_ranges': [
        for (final r in await userDb.query('review_ranges', orderBy: 'id'))
          {
            'id': r['id'],
            'name': r['name'],
            'start_id': r['start_id'],
            'end_id': r['end_id'],
            'next_review_at': r['next_review_at'],
            'needs_extra': r['needs_extra'],
            'created_at': r['created_at'],
            'updated_at': r['updated_at'],
          },
      ],
      'review_sessions': [
        for (final r in await userDb.query('review_sessions', orderBy: 'id'))
          {
            'id': r['id'],
            'range_id': r['range_id'],
            'range_name': r['range_name'],
            'start_id': r['start_id'],
            'end_id': r['end_id'],
            'started_at': r['started_at'],
            'finished_at': r['finished_at'],
            'outcome': r['outcome'],
          },
      ],
      'review_session_ayahs': [
        for (final r in await userDb.query('review_session_ayahs', orderBy: 'session_id, ayah_id'))
          {'session_id': r['session_id'], 'ayah_id': r['ayah_id'], 'result': r['result']},
      ],
    };
    final dataJson = jsonEncode(data);
    final file = <String, Object?>{
      'format': format,
      'version': version,
      'created_at': DateTime.now().millisecondsSinceEpoch,
      'reference_text_digest': reference.meta['ayah_text_digest_sha256'],
      'data': data,
      'checksum_sha256': sha256.convert(utf8.encode(dataJson)).toString(),
    };
    return jsonEncode(file);
  }

  // ---------------------------------------------------------------- validate

  /// Fully validates the file without changing anything. Throws [BackupException] with a clear
  /// Arabic message on the first problem.
  Future<ParsedBackup> validate(String content) async {
    Object? decoded;
    try {
      decoded = jsonDecode(content);
    } catch (_) {
      throw BackupException('الملف ليس نسخة احتياطية صالحة (تعذّرت قراءة JSON).');
    }
    if (decoded is! Map<String, Object?>) {
      throw BackupException('بنية الملف غير صحيحة.');
    }
    const topKeys = {
      'format', 'version', 'created_at', 'reference_text_digest', 'data', 'checksum_sha256'
    };
    for (final k in decoded.keys) {
      if (!topKeys.contains(k)) throw BackupException('الملف يحتوي حقلًا غير مسموح به: $k');
    }
    if (decoded['format'] != format) {
      throw BackupException('هذا الملف ليس نسخة احتياطية لهذا التطبيق.');
    }
    final v = decoded['version'];
    if (v is! int) throw BackupException('رقم إصدار النسخة غير صحيح.');
    if (v != version) {
      throw BackupException('إصدار النسخة ($v) غير مدعوم. المدعوم: $version.');
    }
    final createdAt = decoded['created_at'];
    if (createdAt is! int) throw BackupException('تاريخ النسخة غير صحيح.');
    final data = decoded['data'];
    if (data is! Map<String, Object?>) throw BackupException('بيانات النسخة غير صحيحة.');
    final checksum = decoded['checksum_sha256'];
    if (checksum is! String ||
        checksum != sha256.convert(utf8.encode(jsonEncode(data))).toString()) {
      throw BackupException('بصمة الملف لا تطابق محتواه: الملف تالف أو تم تعديله. لم يتم تغيير أي بيانات.');
    }
    const dataKeys = {
      'settings', 'position', 'bookmarks', 'memorization', 'review_ranges',
      'review_sessions', 'review_session_ayahs'
    };
    for (final k in data.keys) {
      if (!dataKeys.contains(k)) throw BackupException('الملف يحتوي قسمًا غير مسموح به: $k');
    }

    List<Map<String, Object?>> rows(String key, Set<String> allowed, Set<String> required) {
      final raw = data[key];
      if (raw == null) return const [];
      if (raw is! List) throw BackupException('القسم "$key" غير صحيح.');
      if (raw.length > _maxRows) throw BackupException('القسم "$key" كبير بصورة غير معتادة.');
      final out = <Map<String, Object?>>[];
      for (final item in raw) {
        if (item is! Map<String, Object?>) throw BackupException('عنصر غير صحيح في "$key".');
        for (final k in item.keys) {
          if (!allowed.contains(k)) {
            throw BackupException('حقل غير مسموح "$k" في "$key". النسخة لا تقبل نصوصًا قرآنية.');
          }
        }
        for (final k in required) {
          if (!item.containsKey(k)) throw BackupException('حقل ناقص "$k" في "$key".');
        }
        out.add(item);
      }
      return out;
    }

    int intOf(Map<String, Object?> m, String k, String where) {
      final x = m[k];
      if (x is! int) throw BackupException('قيمة "$k" في "$where" يجب أن تكون رقمًا صحيحًا.');
      return x;
    }

    int? intOrNull(Map<String, Object?> m, String k, String where) {
      final x = m[k];
      if (x == null) return null;
      if (x is! int) throw BackupException('قيمة "$k" في "$where" غير صحيحة.');
      return x;
    }

    String stringOf(Map<String, Object?> m, String k, String where, {int max = 200}) {
      final x = m[k];
      if (x is! String) throw BackupException('قيمة "$k" في "$where" يجب أن تكون نصًا.');
      if (x.length > max) throw BackupException('قيمة "$k" في "$where" طويلة جدًا.');
      return x;
    }

    final ids = await reference.allIds();
    void checkId(int id, String where) {
      if (!ids.contains(id)) {
        throw BackupException('آية غير موجودة في المصحف المعتمد ($id) في "$where".');
      }
    }

    final settings = <Map<String, Object?>>[];
    for (final m in rows('settings', {'key', 'value'}, {'key', 'value'})) {
      final key = stringOf(m, 'key', 'settings');
      final value = stringOf(m, 'value', 'settings');
      if (!_allowedSettingKeys.contains(key)) continue; // unknown settings are ignored
      if (key == 'theme_mode' && !{'system', 'light', 'dark'}.contains(value)) {
        throw BackupException('قيمة سمة غير صحيحة.');
      }
      if (key == 'font_size') {
        final d = double.tryParse(value);
        if (d == null || d < 16 || d > 60) throw BackupException('حجم خط غير صحيح.');
      }
      if (key == 'auto_save' && value != '0' && value != '1') {
        throw BackupException('قيمة حفظ تلقائي غير صحيحة.');
      }
      settings.add({'key': key, 'value': value});
    }

    final position = <Map<String, Object?>>[];
    for (final m in rows('position', {'ayah_id', 'source', 'updated_at'},
        {'ayah_id', 'source', 'updated_at'})) {
      final id = intOf(m, 'ayah_id', 'position');
      checkId(id, 'position');
      final src = stringOf(m, 'source', 'position');
      if (src != 'auto' && src != 'manual') throw BackupException('مصدر موضع غير صحيح.');
      position.add({'ayah_id': id, 'source': src, 'updated_at': intOf(m, 'updated_at', 'position')});
    }
    if (position.length > 1) throw BackupException('أكثر من موضع قراءة واحد.');

    final bookmarks = <Map<String, Object?>>[];
    for (final m in rows('bookmarks', {'ayah_id', 'note', 'created_at', 'updated_at'},
        {'ayah_id', 'created_at', 'updated_at'})) {
      final id = intOf(m, 'ayah_id', 'bookmarks');
      checkId(id, 'bookmarks');
      final note = m['note'];
      if (note != null && note is! String) throw BackupException('وصف علامة غير صحيح.');
      if (note is String && note.length > _maxNoteLength) {
        throw BackupException('وصف علامة طويل جدًا.');
      }
      bookmarks.add({
        'ayah_id': id,
        'note': note,
        'created_at': intOf(m, 'created_at', 'bookmarks'),
        'updated_at': intOf(m, 'updated_at', 'bookmarks'),
      });
    }

    final memorization = <Map<String, Object?>>[];
    final seenMem = <int>{};
    for (final m in rows('memorization', {'ayah_id', 'status', 'updated_at'},
        {'ayah_id', 'status', 'updated_at'})) {
      final id = intOf(m, 'ayah_id', 'memorization');
      checkId(id, 'memorization');
      if (!seenMem.add(id)) throw BackupException('آية مكررة في الحفظ: $id');
      final st = MemStatus.tryParse(m['status']);
      if (st == null || st == MemStatus.notStarted) {
        throw BackupException('حالة حفظ غير صحيحة.');
      }
      memorization.add({
        'ayah_id': id,
        'status': st.dbValue,
        'updated_at': intOf(m, 'updated_at', 'memorization'),
      });
    }

    final ranges = <Map<String, Object?>>[];
    final rangeIds = <int>{};
    for (final m in rows(
        'review_ranges',
        {'id', 'name', 'start_id', 'end_id', 'next_review_at', 'needs_extra', 'created_at', 'updated_at'},
        {'id', 'name', 'start_id', 'end_id', 'needs_extra', 'created_at', 'updated_at'})) {
      final id = intOf(m, 'id', 'review_ranges');
      if (!rangeIds.add(id)) throw BackupException('نطاق مراجعة مكرر.');
      final s = intOf(m, 'start_id', 'review_ranges');
      final e = intOf(m, 'end_id', 'review_ranges');
      checkId(s, 'review_ranges');
      checkId(e, 'review_ranges');
      if (s > e) throw BackupException('نطاق مراجعة بدايته بعد نهايته.');
      final extra = intOf(m, 'needs_extra', 'review_ranges');
      if (extra != 0 && extra != 1) throw BackupException('قيمة غير صحيحة في نطاق مراجعة.');
      ranges.add({
        'id': id,
        'name': stringOf(m, 'name', 'review_ranges', max: 80),
        'start_id': s,
        'end_id': e,
        'next_review_at': intOrNull(m, 'next_review_at', 'review_ranges'),
        'needs_extra': extra,
        'created_at': intOf(m, 'created_at', 'review_ranges'),
        'updated_at': intOf(m, 'updated_at', 'review_ranges'),
      });
    }

    final sessions = <Map<String, Object?>>[];
    final sessionIds = <int>{};
    final sessionBounds = <int, List<int>>{};
    for (final m in rows(
        'review_sessions',
        {'id', 'range_id', 'range_name', 'start_id', 'end_id', 'started_at', 'finished_at', 'outcome'},
        {'id', 'range_name', 'start_id', 'end_id', 'started_at', 'outcome'})) {
      final id = intOf(m, 'id', 'review_sessions');
      if (!sessionIds.add(id)) throw BackupException('جلسة مراجعة مكررة.');
      final s = intOf(m, 'start_id', 'review_sessions');
      final e = intOf(m, 'end_id', 'review_sessions');
      checkId(s, 'review_sessions');
      checkId(e, 'review_sessions');
      if (s > e) throw BackupException('جلسة مراجعة بدايتها بعد نهايتها.');
      final outcome = stringOf(m, 'outcome', 'review_sessions');
      if (!{'in_progress', 'completed', 'partial'}.contains(outcome)) {
        throw BackupException('نتيجة جلسة مراجعة غير صحيحة.');
      }
      final rid = intOrNull(m, 'range_id', 'review_sessions');
      sessionBounds[id] = [s, e];
      sessions.add({
        'id': id,
        'range_id': (rid != null && rangeIds.contains(rid)) ? rid : null,
        'range_name': stringOf(m, 'range_name', 'review_sessions', max: 80),
        'start_id': s,
        'end_id': e,
        'started_at': intOf(m, 'started_at', 'review_sessions'),
        'finished_at': intOrNull(m, 'finished_at', 'review_sessions'),
        'outcome': outcome,
      });
    }

    final sessionAyahs = <Map<String, Object?>>[];
    final seenSa = <String>{};
    for (final m in rows('review_session_ayahs', {'session_id', 'ayah_id', 'result'},
        {'session_id', 'ayah_id', 'result'})) {
      final sid = intOf(m, 'session_id', 'review_session_ayahs');
      final aid = intOf(m, 'ayah_id', 'review_session_ayahs');
      checkId(aid, 'review_session_ayahs');
      final b = sessionBounds[sid];
      if (b == null) throw BackupException('نتيجة مراجعة لجلسة غير موجودة.');
      if (aid < b[0] || aid > b[1]) throw BackupException('نتيجة مراجعة خارج نطاق جلستها.');
      if (!seenSa.add('$sid:$aid')) throw BackupException('نتيجة مراجعة مكررة.');
      final res = stringOf(m, 'result', 'review_session_ayahs');
      if (res != 'reviewed' && res != 'needs_more') {
        throw BackupException('نتيجة مراجعة غير صحيحة.');
      }
      sessionAyahs.add({'session_id': sid, 'ayah_id': aid, 'result': res});
    }

    return ParsedBackup(
      createdAt: createdAt,
      settings: settings,
      position: position,
      bookmarks: bookmarks,
      memorization: memorization,
      ranges: ranges,
      sessions: sessions,
      sessionAyahs: sessionAyahs,
    );
  }

  Future<BackupSummary> inspect(String content) async {
    final p = await validate(content);
    return BackupSummary(
      bookmarks: p.bookmarks.length,
      memorization: p.memorization.length,
      reviewRanges: p.ranges.length,
      reviewSessions: p.sessions.length,
      createdAt: p.createdAt,
      hasPosition: p.position.isNotEmpty,
    );
  }

  // ---------------------------------------------------------------- restore

  /// Replaces the user's data with the backup, atomically. Returns a JSON snapshot of the data
  /// as it was just before the restore, so the caller can keep a safety copy.
  Future<String> restore(String content) async {
    final parsed = await validate(content); // throws before anything is touched
    final safety = await exportJson();
    try {
      await userDb.transaction((txn) async {
        await txn.delete('review_session_ayahs');
        await txn.delete('review_sessions');
        await txn.delete('review_ranges');
        await txn.delete('memorization_batch_items');
        await txn.delete('memorization_batches');
        await txn.delete('memorization');
        await txn.delete('bookmarks');
        await txn.delete('reading_position');
        await txn.delete('app_settings');
        final b = txn.batch();
        for (final r in parsed.settings) {
          b.insert('app_settings', r);
        }
        for (final r in parsed.position) {
          b.insert('reading_position', {'id': 1, ...r});
        }
        for (final r in parsed.bookmarks) {
          b.insert('bookmarks', r);
        }
        for (final r in parsed.memorization) {
          b.insert('memorization', r);
        }
        for (final r in parsed.ranges) {
          b.insert('review_ranges', r);
        }
        for (final r in parsed.sessions) {
          b.insert('review_sessions', r);
        }
        for (final r in parsed.sessionAyahs) {
          b.insert('review_session_ayahs', r);
        }
        await b.commit(noResult: true);
      });
    } catch (e) {
      throw BackupException('فشلت الاستعادة ولم يتم تغيير أي بيانات: $e');
    }
    return safety;
  }
}

class ParsedBackup {
  ParsedBackup({
    required this.createdAt,
    required this.settings,
    required this.position,
    required this.bookmarks,
    required this.memorization,
    required this.ranges,
    required this.sessions,
    required this.sessionAyahs,
  });
  final int createdAt;
  final List<Map<String, Object?>> settings;
  final List<Map<String, Object?>> position;
  final List<Map<String, Object?>> bookmarks;
  final List<Map<String, Object?>> memorization;
  final List<Map<String, Object?>> ranges;
  final List<Map<String, Object?>> sessions;
  final List<Map<String, Object?>> sessionAyahs;
}
