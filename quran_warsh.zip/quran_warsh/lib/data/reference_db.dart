import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import '../logic/search_fold.dart';
import 'models.dart';

/// Read-only access to the Quran reference database built from the official KFGQPC package.
/// Nothing in the app writes to this database, and backups never touch it.
class ReferenceDb {
  ReferenceDb._(this._db, this.surahs, this.meta, this.disputed);

  final Database _db;
  final List<Surah> surahs;
  final Map<String, String> meta;

  /// Ayahs whose text differs between the two official releases and could not be settled.
  final Map<int, String> disputed;

  static const String assetPath = 'assets/data/quran_warsh.db';
  static const String fileName = 'quran_warsh_reference.db';

  /// Copies the bundled database to app storage when missing or different, then opens it
  /// read-only. The copy is compared byte-for-byte (SHA-256) on every start, so a damaged or
  /// altered copy is replaced by the bundled original.
  static Future<ReferenceDb> openFromAssets() async {
    final dir = await getApplicationSupportDirectory();
    final path = p.join(dir.path, fileName);
    final data = await rootBundle.load(assetPath);
    final bytes = data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
    final expected = sha256.convert(bytes).toString();
    final file = File(path);
    var same = false;
    if (await file.exists()) {
      same = sha256.convert(await file.readAsBytes()).toString() == expected;
    }
    if (!same) {
      final tmp = File('$path.tmp');
      await tmp.writeAsBytes(bytes, flush: true);
      if (await file.exists()) await file.delete();
      await tmp.rename(path);
    }
    return openAtPath(path);
  }

  static Future<ReferenceDb> openAtPath(String path) async {
    final db = await openDatabase(path, readOnly: true, singleInstance: false);
    try {
      return await _load(db);
    } catch (_) {
      await db.close();
      rethrow;
    }
  }

  static Future<ReferenceDb> _load(Database db) async {
    final surahRows = await db.rawQuery('SELECT * FROM surahs ORDER BY number');
    final surahs = surahRows.map(Surah.fromRow).toList();
    final metaRows = await db.rawQuery('SELECT key, value FROM meta');
    final meta = <String, String>{
      for (final r in metaRows) r['key']! as String: r['value']! as String,
    };
    final disputedRows =
        await db.rawQuery("SELECT ayah_id, note FROM verification WHERE status = 'disputed'");
    final disputed = <int, String>{
      for (final r in disputedRows) r['ayah_id']! as int: (r['note'] as String?) ?? '',
    };

    final ayahTotal = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM ayahs')) ?? -1;
    final expectedTotal = int.tryParse(meta['ayah_count'] ?? '') ?? -2;
    final sum = surahs.fold<int>(0, (a, s) => a + s.ayahCount);
    if (surahs.length != 114 || ayahTotal != expectedTotal || sum != ayahTotal) {
      throw StateError('بيانات المصحف المرجعية غير سليمة: '
          'سور=${surahs.length} آيات=$ayahTotal المتوقع=$expectedTotal مجموع السور=$sum');
    }
    for (var i = 0; i < surahs.length; i++) {
      if (surahs[i].number != i + 1) {
        throw StateError('ترتيب السور في بيانات المصحف غير سليم عند ${i + 1}');
      }
    }
    return ReferenceDb._(db, surahs, meta, disputed);
  }

  Future<void> close() => _db.close();

  int get totalAyahs => int.parse(meta['ayah_count']!);

  Surah surah(int number) => surahs[number - 1];

  /// True only when (surah, ayah) exists in the source numbering.
  bool isValid(int surahNumber, int ayah) {
    if (surahNumber < 1 || surahNumber > surahs.length) return false;
    return ayah >= 1 && ayah <= surahs[surahNumber - 1].ayahCount;
  }

  bool isValidId(int id) => isValid(id ~/ 1000, id % 1000);

  /// 1-based position of an ayah in mushaf order.
  int ordinalOf(int id) {
    final s = id ~/ 1000;
    var before = 0;
    for (var i = 0; i < s - 1; i++) {
      before += surahs[i].ayahCount;
    }
    return before + id % 1000;
  }

  Future<List<Ayah>> ayahsOfSurah(int surahNumber) async {
    final rows = await _db.rawQuery(
        'SELECT id, surah, ayah, text FROM ayahs WHERE surah = ? ORDER BY ayah', [surahNumber]);
    return rows.map(Ayah.fromRow).toList();
  }

  Future<Ayah?> ayahById(int id) async {
    final rows = await _db.rawQuery('SELECT id, surah, ayah, text FROM ayahs WHERE id = ?', [id]);
    return rows.isEmpty ? null : Ayah.fromRow(rows.first);
  }

  /// All ayah ids from [startId] to [endId] inclusive, in mushaf order. Works across surahs.
  Future<List<int>> idsInRange(int startId, int endId) async {
    final rows = await _db.rawQuery(
        'SELECT id FROM ayahs WHERE id BETWEEN ? AND ? ORDER BY id', [startId, endId]);
    return rows.map((r) => r['id']! as int).toList();
  }

  Future<int> countInRange(int startId, int endId) async {
    return Sqflite.firstIntValue(await _db
            .rawQuery('SELECT COUNT(*) FROM ayahs WHERE id BETWEEN ? AND ?', [startId, endId])) ??
        0;
  }

  Future<List<Ayah>> ayahsInRange(int startId, int endId) async {
    final rows = await _db.rawQuery(
        'SELECT id, surah, ayah, text FROM ayahs WHERE id BETWEEN ? AND ? ORDER BY id',
        [startId, endId]);
    return rows.map(Ayah.fromRow).toList();
  }

  Future<Set<int>> allIds() async {
    final rows = await _db.rawQuery('SELECT id FROM ayahs');
    return rows.map((r) => r['id']! as int).toSet();
  }

  /// Word / phrase search over the folded copy stored in the reference database.
  Future<List<Ayah>> searchWords(String query, {int limit = 200}) async {
    final l = looseArabic(query);
    if (l.length < 2) return const [];
    final rows = await _db.rawQuery(
        'SELECT a.id AS id, a.surah AS surah, a.ayah AS ayah, a.text AS text '
        'FROM ayah_search s JOIN ayahs a ON a.id = s.id '
        'WHERE s.loose LIKE ? ORDER BY a.id LIMIT ?',
        ['%$l%', limit]);
    return rows.map(Ayah.fromRow).toList();
  }

  /// Surahs whose Arabic or transliterated name contains [query].
  List<Surah> searchSurahs(String query) {
    final fa = foldArabic(query);
    final fl = foldLatin(query);
    if (fa.isEmpty && fl.isEmpty) return const [];
    final out = <Surah>[];
    for (final s in surahs) {
      final arabicHit = fa.isNotEmpty && s.nameFold.contains(fa);
      final latinHit = fl.isNotEmpty && foldLatin(s.nameEn).contains(fl);
      if (arabicHit || latinHit) out.add(s);
    }
    return out;
  }
}
