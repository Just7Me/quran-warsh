import 'backup_service.dart';
import 'reference_db.dart';
import 'repositories/bookmarks_repo.dart';
import 'repositories/memorization_repo.dart';
import 'repositories/position_repo.dart';
import 'repositories/review_repo.dart';
import 'repositories/settings_repo.dart';
import 'user_db.dart';

/// Everything the UI needs, created once at start-up.
class Services {
  Services({required this.reference, required this.userDb, required this.directory})
      : settings = SettingsRepo(userDb.db),
        position = PositionRepo(userDb.db),
        bookmarks = BookmarksRepo(userDb.db),
        memorization = MemorizationRepo(userDb.db),
        review = ReviewRepo(userDb.db),
        backup = BackupService(userDb: userDb.db, reference: reference);

  final ReferenceDb reference;
  final UserDb userDb;

  /// App storage directory (used for the safety copy written before a restore).
  final String directory;

  final SettingsRepo settings;
  final PositionRepo position;
  final BookmarksRepo bookmarks;
  final MemorizationRepo memorization;
  final ReviewRepo review;
  final BackupService backup;
}
