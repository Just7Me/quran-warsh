import 'dart:math';

import 'package:sqflite/sqflite.dart';

import '../models.dart';

class RangeApplyResult {
  const RangeApplyResult({required this.batchId, required this.changed, required this.total});

  /// Null when nothing had to change (every ayah already had that state).
  final int? batchId;
  final int changed;
  final int total;
}

class SurahMemCounts {
  const SurahMemCounts(this.surah, this.learning, this.memorized, this.needsReview);
  final int surah;
  final int learning;
  final int memorized;
  final int needsReview;
  int get total => learning + memorized + needsReview;
}

/// Per-ayah memorization state. Only the ayahs the user touched have a row; a missing row
/// means "not started". Changing the state of a range never touches ayahs outside it.
class MemorizationRepo {
  MemorizationRepo(this.db);
  final Database db;

  static const int _maxHistory = 50;

  Future<MemStatus> statusOf(int ayahId) async {
    final rows = await db.query('memorization',
        columns: ['status'], where: 'ayah_id = ?', whereArgs: [ayahId], limit: 1);
    return rows.isEmpty ? MemStatus.notStarted : MemStatus.fromDb(rows.first['status'] as String?);
  }

  Future<Map<int, MemStatus>> statusesForSurah(int surah) async {
    final rows = await db.query(
      'memorization',
      where: 'ayah_id BETWEEN ? AND ?',
      whereArgs: [surah * 1000 + 1, surah * 1000 + 999],
    );
    return {
      for (final r in rows) r['ayah_id']! as int: MemStatus.fromDb(r['status'] as String?),
    };
  }

  /// Sets the state of exactly the given ayahs (the caller obtains [ids] from the reference
  /// database for the chosen range, so ids that do not exist can never be written).
  /// Records an undo batch. Atomic: either every ayah changes or none does.
  Future<RangeApplyResult> applyToIds({
    required List<int> ids,
    required MemStatus status,
    required int startId,
    required int endId,
  }) async {
    if (ids.isEmpty) return const RangeApplyResult(batchId: null, changed: 0, total: 0);
    return db.transaction<RangeApplyResult>((txn) async {
      final lo = ids.reduce(min);
      final hi = ids.reduce(max);
      final existing = await txn.query(
        'memorization',
        where: 'ayah_id BETWEEN ? AND ?',
        whereArgs: [lo, hi],
      );
      final old = <int, String>{
        for (final r in existing) r['ayah_id']! as int: r['status']! as String,
      };
      final changedIds = <int>[];
      for (final id in ids) {
        final before = old[id];
        final same = status == MemStatus.notStarted ? before == null : before == status.dbValue;
        if (!same) changedIds.add(id);
      }
      if (changedIds.isEmpty) {
        return RangeApplyResult(batchId: null, changed: 0, total: ids.length);
      }
      final now = DateTime.now().millisecondsSinceEpoch;
      final batchId = await txn.insert('memorization_batches', {
        'created_at': now,
        'new_status': status.dbValue,
        'start_id': startId,
        'end_id': endId,
        'undone': 0,
      });
      final b = txn.batch();
      for (final id in changedIds) {
        b.insert('memorization_batch_items',
            {'batch_id': batchId, 'ayah_id': id, 'old_status': old[id]});
        if (status == MemStatus.notStarted) {
          b.delete('memorization', where: 'ayah_id = ?', whereArgs: [id]);
        } else {
          b.insert(
            'memorization',
            {'ayah_id': id, 'status': status.dbValue, 'updated_at': now},
            conflictAlgorithm: ConflictAlgorithm.replace,
          );
        }
      }
      await b.commit(noResult: true);
      await txn.rawDelete(
          'DELETE FROM memorization_batches WHERE id NOT IN '
          '(SELECT id FROM memorization_batches ORDER BY id DESC LIMIT ?)',
          [_maxHistory]);
      return RangeApplyResult(batchId: batchId, changed: changedIds.length, total: ids.length);
    });
  }

  Future<RangeApplyResult> setSingle(int ayahId, MemStatus status) =>
      applyToIds(ids: [ayahId], status: status, startId: ayahId, endId: ayahId);

  /// Undoes the most recent change that has not been undone. Returns the number of ayahs
  /// restored, or null when there is nothing to undo.
  Future<int?> undoLast() async {
    return db.transaction<int?>((txn) async {
      final batches = await txn.query('memorization_batches',
          where: 'undone = 0', orderBy: 'id DESC', limit: 1);
      if (batches.isEmpty) return null;
      final batchId = batches.first['id']! as int;
      final items =
          await txn.query('memorization_batch_items', where: 'batch_id = ?', whereArgs: [batchId]);
      final now = DateTime.now().millisecondsSinceEpoch;
      final b = txn.batch();
      for (final it in items) {
        final id = it['ayah_id']! as int;
        final before = it['old_status'] as String?;
        if (before == null) {
          b.delete('memorization', where: 'ayah_id = ?', whereArgs: [id]);
        } else {
          b.insert(
            'memorization',
            {'ayah_id': id, 'status': before, 'updated_at': now},
            conflictAlgorithm: ConflictAlgorithm.replace,
          );
        }
      }
      b.update('memorization_batches', {'undone': 1}, where: 'id = ?', whereArgs: [batchId]);
      await b.commit(noResult: true);
      return items.length;
    });
  }

  Future<bool> canUndo() async {
    final n = Sqflite.firstIntValue(
        await db.rawQuery('SELECT COUNT(*) FROM memorization_batches WHERE undone = 0'));
    return (n ?? 0) > 0;
  }

  Future<Map<MemStatus, int>> counts() async {
    final rows =
        await db.rawQuery('SELECT status, COUNT(*) AS n FROM memorization GROUP BY status');
    final out = <MemStatus, int>{for (final s in MemStatus.values) s: 0};
    for (final r in rows) {
      out[MemStatus.fromDb(r['status'] as String?)] = r['n']! as int;
    }
    return out;
  }

  Future<List<SurahMemCounts>> perSurah() async {
    final rows = await db.rawQuery(
        'SELECT ayah_id / 1000 AS s, status, COUNT(*) AS n FROM memorization '
        'GROUP BY s, status ORDER BY s');
    final bySurah = <int, List<int>>{};
    for (final r in rows) {
      final s = r['s']! as int;
      final list = bySurah.putIfAbsent(s, () => [0, 0, 0]);
      final st = MemStatus.fromDb(r['status'] as String?);
      final n = r['n']! as int;
      if (st == MemStatus.learning) list[0] += n;
      if (st == MemStatus.memorized) list[1] += n;
      if (st == MemStatus.needsReview) list[2] += n;
    }
    final keys = bySurah.keys.toList()..sort();
    return [for (final k in keys) SurahMemCounts(k, bySurah[k]![0], bySurah[k]![1], bySurah[k]![2])];
  }

  /// Ayah ids with the given state, in mushaf order.
  Future<List<int>> idsWithStatus(MemStatus status, {int? limit}) async {
    final rows = await db.query(
      'memorization',
      columns: ['ayah_id'],
      where: 'status = ?',
      whereArgs: [status.dbValue],
      orderBy: 'ayah_id',
      limit: limit,
    );
    return rows.map((r) => r['ayah_id']! as int).toList();
  }
}
