import 'package:sqflite/sqflite.dart';

import '../models.dart';

/// "Continue reading" position. Reading progress is kept apart from memorization data:
/// reaching an ayah while reading never means it was memorized.
class PositionRepo {
  PositionRepo(this.db);
  final Database db;

  Future<PositionRow?> get() async {
    final rows = await db.query('reading_position', where: 'id = 1', limit: 1);
    if (rows.isEmpty) return null;
    final r = rows.first;
    return PositionRow(
      ayahId: r['ayah_id']! as int,
      manual: r['source'] == 'manual',
      updatedAt: r['updated_at']! as int,
    );
  }

  /// The user explicitly marks this ayah as the last place reached.
  Future<void> setManual(int ayahId) async {
    await db.insert(
      'reading_position',
      {
        'id': 1,
        'ayah_id': ayahId,
        'source': 'manual',
        'updated_at': DateTime.now().millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  /// Automatic save while reading. A manual position is never moved BACKWARDS by an automatic
  /// save (so browsing earlier text does not erase it); reading past it moves it forward.
  /// Returns true when the stored position changed.
  Future<bool> saveAuto(int ayahId) async {
    var changed = false;
    await db.transaction((txn) async {
      final rows = await txn.query('reading_position', where: 'id = 1', limit: 1);
      if (rows.isNotEmpty) {
        final manual = rows.first['source'] == 'manual';
        final current = rows.first['ayah_id']! as int;
        if (manual && ayahId < current) return;
        if (!manual && current == ayahId) return;
      }
      await txn.insert(
        'reading_position',
        {
          'id': 1,
          'ayah_id': ayahId,
          'source': 'auto',
          'updated_at': DateTime.now().millisecondsSinceEpoch,
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
      changed = true;
    });
    return changed;
  }
}
