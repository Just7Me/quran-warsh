import 'package:sqflite/sqflite.dart';

class SettingsRepo {
  SettingsRepo(this.db);
  final Database db;

  static const String kThemeMode = 'theme_mode'; // system | light | dark
  static const String kFontSize = 'font_size'; // logical pixels, 20..44
  static const String kAutoSave = 'auto_save'; // 1 | 0

  Future<String?> get(String key) async {
    final rows = await db.query('app_settings', where: 'key = ?', whereArgs: [key], limit: 1);
    return rows.isEmpty ? null : rows.first['value'] as String;
  }

  Future<void> set(String key, String value) async {
    await db.insert('app_settings', {'key': key, 'value': value},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<Map<String, String>> all() async {
    final rows = await db.query('app_settings');
    return {for (final r in rows) r['key']! as String: r['value']! as String};
  }
}
