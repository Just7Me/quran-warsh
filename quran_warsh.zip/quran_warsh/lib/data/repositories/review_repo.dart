import 'package:sqflite/sqflite.dart';

import '../models.dart';

/// Review ranges and review sessions.
///
/// Three things are kept apart on purpose:
///  1. "memorized but needs review"  = ayahs whose memorization state is needs_review
///  2. "a range whose review was started"  = a review_session with outcome in_progress
///  3. "a review that was completed"  = a review_session with outcome completed
/// A partly reviewed range is recorded as outcome partial and is never counted as completed.
class ReviewRepo {
  ReviewRepo(this.db);
  final Database db;

  static const int maxNameLength = 80;

  String _cleanName(String name) {
    final t = name.trim();
    if (t.isEmpty) throw ArgumentError('اسم نطاق المراجعة مطلوب');
    return t.length > maxNameLength ? t.substring(0, maxNameLength) : t;
  }

  Future<int> createRange({
    required String name,
    required int startId,
    required int endId,
    int? nextReviewAt,
  }) async {
    if (startId > endId) throw ArgumentError('بداية النطاق بعد نهايته');
    final now = DateTime.now().millisecondsSinceEpoch;
    return db.insert('review_ranges', {
      'name': _cleanName(name),
      'start_id': startId,
      'end_id': endId,
      'next_review_at': nextReviewAt,
      'needs_extra': 0,
      'created_at': now,
      'updated_at': now,
    });
  }

  Future<void> updateRange({
    required int id,
    String? name,
    int? startId,
    int? endId,
  }) async {
    final cur = await db.query('review_ranges', where: 'id = ?', whereArgs: [id], limit: 1);
    if (cur.isEmpty) throw StateError('نطاق المراجعة غير موجود');
    final s = startId ?? cur.first['start_id']! as int;
    final e = endId ?? cur.first['end_id']! as int;
    if (s > e) throw ArgumentError('بداية النطاق بعد نهايته');
    await db.update(
      'review_ranges',
      {
        if (name != null) 'name': _cleanName(name),
        'start_id': s,
        'end_id': e,
        'updated_at': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<void> setNextReview(int rangeId, int? when) async {
    await db.update(
      'review_ranges',
      {'next_review_at': when, 'updated_at': DateTime.now().millisecondsSinceEpoch},
      where: 'id = ?',
      whereArgs: [rangeId],
    );
  }

  Future<void> setNeedsExtra(int rangeId, bool value) async {
    await db.update(
      'review_ranges',
      {'needs_extra': value ? 1 : 0, 'updated_at': DateTime.now().millisecondsSinceEpoch},
      where: 'id = ?',
      whereArgs: [rangeId],
    );
  }

  /// Deletes the range. Its past sessions stay in the history (range_id becomes null).
  Future<void> deleteRange(int id) async {
    await db.delete('review_ranges', where: 'id = ?', whereArgs: [id]);
  }

  static const String _rangeSelect = '''
    SELECT r.id, r.name, r.start_id, r.end_id, r.next_review_at, r.needs_extra,
      (SELECT s.id FROM review_sessions s WHERE s.range_id = r.id AND s.outcome = 'in_progress'
         ORDER BY s.id DESC LIMIT 1) AS in_progress_id,
      (SELECT MAX(s.finished_at) FROM review_sessions s
         WHERE s.range_id = r.id AND s.outcome = 'completed') AS last_completed
    FROM review_ranges r
  ''';

  ReviewRange _rangeFromRow(Map<String, Object?> r) => ReviewRange(
        id: r['id']! as int,
        name: r['name']! as String,
        startId: r['start_id']! as int,
        endId: r['end_id']! as int,
        nextReviewAt: r['next_review_at'] as int?,
        needsExtra: (r['needs_extra']! as int) == 1,
        inProgressSessionId: r['in_progress_id'] as int?,
        lastCompletedAt: r['last_completed'] as int?,
      );

  Future<List<ReviewRange>> listRanges() async {
    final rows = await db.rawQuery('$_rangeSelect ORDER BY r.start_id, r.id');
    return rows.map(_rangeFromRow).toList();
  }

  Future<ReviewRange?> getRange(int id) async {
    final rows = await db.rawQuery('$_rangeSelect WHERE r.id = ?', [id]);
    return rows.isEmpty ? null : _rangeFromRow(rows.first);
  }

  /// Ranges whose scheduled review time has come.
  Future<List<ReviewRange>> dueRanges(int nowMillis) async {
    final rows = await db.rawQuery(
        '$_rangeSelect WHERE r.next_review_at IS NOT NULL AND r.next_review_at <= ? '
        'ORDER BY r.next_review_at',
        [nowMillis]);
    return rows.map(_rangeFromRow).toList();
  }

  /// Starts a session for the range, or returns the one already in progress.
  Future<int> startOrResume(ReviewRange range) async {
    if (range.inProgressSessionId != null) return range.inProgressSessionId!;
    return db.insert('review_sessions', {
      'range_id': range.id,
      'range_name': range.name,
      'start_id': range.startId,
      'end_id': range.endId,
      'started_at': DateTime.now().millisecondsSinceEpoch,
      'finished_at': null,
      'outcome': 'in_progress',
    });
  }

  /// Records the result for one ayah inside a session. [needsMore] also marks the ayah as
  /// needs_review in the memorization table, in the same transaction.
  Future<void> markAyah({
    required int sessionId,
    required int ayahId,
    required bool needsMore,
  }) async {
    await db.transaction((txn) async {
      final s = await txn.query('review_sessions',
          where: 'id = ?', whereArgs: [sessionId], limit: 1);
      if (s.isEmpty) throw StateError('جلسة المراجعة غير موجودة');
      if (s.first['outcome'] != 'in_progress') {
        throw StateError('جلسة المراجعة منتهية');
      }
      final start = s.first['start_id']! as int;
      final end = s.first['end_id']! as int;
      if (ayahId < start || ayahId > end) {
        throw ArgumentError('الآية خارج نطاق جلسة المراجعة');
      }
      await txn.insert(
        'review_session_ayahs',
        {
          'session_id': sessionId,
          'ayah_id': ayahId,
          'result': needsMore ? 'needs_more' : 'reviewed',
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
      if (needsMore) {
        await txn.insert(
          'memorization',
          {
            'ayah_id': ayahId,
            'status': MemStatus.needsReview.dbValue,
            'updated_at': DateTime.now().millisecondsSinceEpoch,
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }
    });
  }

  Future<void> clearAyahMark(int sessionId, int ayahId) async {
    await db.delete('review_session_ayahs',
        where: 'session_id = ? AND ayah_id = ?', whereArgs: [sessionId, ayahId]);
  }

  Future<Map<int, String>> sessionResults(int sessionId) async {
    final rows = await db
        .query('review_session_ayahs', where: 'session_id = ?', whereArgs: [sessionId]);
    return {for (final r in rows) r['ayah_id']! as int: r['result']! as String};
  }

  /// Closes the session. The outcome is computed from the recorded data: `completed` only when
  /// every ayah of the range has a result, otherwise `partial`.
  /// [totalAyahs] is the number of ayahs in the range, taken from the reference database.
  Future<String> finishSession({required int sessionId, required int totalAyahs}) async {
    return db.transaction<String>((txn) async {
      final s = await txn.query('review_sessions',
          where: 'id = ?', whereArgs: [sessionId], limit: 1);
      if (s.isEmpty) throw StateError('جلسة المراجعة غير موجودة');
      if (s.first['outcome'] != 'in_progress') return s.first['outcome']! as String;
      final n = Sqflite.firstIntValue(await txn.rawQuery(
              'SELECT COUNT(*) FROM review_session_ayahs WHERE session_id = ?', [sessionId])) ??
          0;
      final outcome = (n > 0 && n >= totalAyahs) ? 'completed' : 'partial';
      await txn.update(
        'review_sessions',
        {'outcome': outcome, 'finished_at': DateTime.now().millisecondsSinceEpoch},
        where: 'id = ?',
        whereArgs: [sessionId],
      );
      return outcome;
    });
  }

  Future<List<ReviewSession>> listSessions({int limit = 100}) async {
    final rows = await db.rawQuery(
        'SELECT s.id, s.range_id, s.range_name, s.start_id, s.end_id, s.started_at, '
        's.finished_at, s.outcome, '
        '(SELECT COUNT(*) FROM review_session_ayahs a WHERE a.session_id = s.id) AS n '
        'FROM review_sessions s ORDER BY s.started_at DESC, s.id DESC LIMIT ?',
        [limit]);
    return rows
        .map((r) => ReviewSession(
              id: r['id']! as int,
              rangeId: r['range_id'] as int?,
              rangeName: r['range_name']! as String,
              startId: r['start_id']! as int,
              endId: r['end_id']! as int,
              startedAt: r['started_at']! as int,
              finishedAt: r['finished_at'] as int?,
              outcome: r['outcome']! as String,
              reviewedCount: r['n']! as int,
            ))
        .toList();
  }

  /// Statistics computed only from recorded sessions.
  Future<({int sessions, int completed, int partial, int inProgress, int? lastAt})> stats() async {
    final rows = await db.rawQuery(
        'SELECT outcome, COUNT(*) AS n, MAX(COALESCE(finished_at, started_at)) AS last '
        'FROM review_sessions GROUP BY outcome');
    var completed = 0, partial = 0, inProgress = 0;
    int? last;
    for (final r in rows) {
      final n = r['n']! as int;
      final l = r['last'] as int?;
      if (l != null && (last == null || l > last)) last = l;
      switch (r['outcome']) {
        case 'completed':
          completed = n;
        case 'partial':
          partial = n;
        case 'in_progress':
          inProgress = n;
      }
    }
    return (
      sessions: completed + partial + inProgress,
      completed: completed,
      partial: partial,
      inProgress: inProgress,
      lastAt: last,
    );
  }
}
