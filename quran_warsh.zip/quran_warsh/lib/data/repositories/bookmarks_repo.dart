import 'package:sqflite/sqflite.dart';

import '../models.dart';

class BookmarksRepo {
  BookmarksRepo(this.db);
  final Database db;

  static const int maxNoteLength = 500;

  String? _cleanNote(String? note) {
    final t = note?.trim();
    if (t == null || t.isEmpty) return null;
    return t.length > maxNoteLength ? t.substring(0, maxNoteLength) : t;
  }

  /// Several bookmarks may point at the same ayah, each with its own note.
  Future<int> add(int ayahId, {String? note}) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    return db.insert('bookmarks', {
      'ayah_id': ayahId,
      'note': _cleanNote(note),
      'created_at': now,
      'updated_at': now,
    });
  }

  Future<void> updateNote(int id, String? note) async {
    final n = await db.update(
      'bookmarks',
      {'note': _cleanNote(note), 'updated_at': DateTime.now().millisecondsSinceEpoch},
      where: 'id = ?',
      whereArgs: [id],
    );
    if (n != 1) throw StateError('العلامة غير موجودة');
  }

  Future<void> delete(int id) async {
    await db.delete('bookmarks', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Bookmark>> list() async {
    final rows = await db.query('bookmarks', orderBy: 'created_at DESC, id DESC');
    return rows.map(Bookmark.fromRow).toList();
  }

  Future<List<Bookmark>> forSurah(int surah) async {
    final rows = await db.query(
      'bookmarks',
      where: 'ayah_id BETWEEN ? AND ?',
      whereArgs: [surah * 1000 + 1, surah * 1000 + 999],
      orderBy: 'ayah_id, id',
    );
    return rows.map(Bookmark.fromRow).toList();
  }
}
