const String _arabicIndic = '٠١٢٣٤٥٦٧٨٩';
const String _easternIndic = '۰۱۲۳۴۵۶۷۸۹';

/// 255 -> ٢٥٥
String toArabicDigits(int n) {
  final s = n.toString();
  final b = StringBuffer();
  for (final c in s.split('')) {
    final d = int.tryParse(c);
    b.write(d == null ? c : _arabicIndic[d]);
  }
  return b.toString();
}

/// Parses a non-negative integer written with Latin, Arabic-Indic or Persian digits.
/// Returns null when the text is empty or is not purely digits.
int? parseDigits(String input) {
  final t = input.trim();
  if (t.isEmpty) return null;
  final b = StringBuffer();
  for (final ch in t.split('')) {
    final a = _arabicIndic.indexOf(ch);
    final e = _easternIndic.indexOf(ch);
    if (a >= 0) {
      b.write(a);
    } else if (e >= 0) {
      b.write(e);
    } else if (ch.codeUnitAt(0) >= 0x30 && ch.codeUnitAt(0) <= 0x39) {
      b.write(ch);
    } else {
      return null;
    }
  }
  return int.tryParse(b.toString());
}

/// Date as yyyy/MM/dd with Arabic-Indic digits.
String formatDate(int millis) {
  final d = DateTime.fromMillisecondsSinceEpoch(millis);
  String two(int v) => v.toString().padLeft(2, '0');
  final s = '${d.year}/${two(d.month)}/${two(d.day)}';
  final b = StringBuffer();
  for (final c in s.split('')) {
    final x = int.tryParse(c);
    b.write(x == null ? c : _arabicIndic[x]);
  }
  return b.toString();
}
