/// A reference to one ayah in the numbering of the official source.
///
/// The stable identifier is `surah * 1000 + ayah`. It never depends on the page, on the
/// position of a widget on screen, or on list order.
class AyahRef {
  const AyahRef(this.surah, this.ayah);

  factory AyahRef.fromId(int id) => AyahRef(id ~/ 1000, id % 1000);

  final int surah;
  final int ayah;

  int get id => surah * 1000 + ayah;

  @override
  bool operator ==(Object other) => other is AyahRef && other.id == id;

  @override
  int get hashCode => id;

  @override
  String toString() => '$surah:$ayah';
}
