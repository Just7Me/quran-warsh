# القرآن الكريم — رواية ورش عن نافع

تطبيق أندرويد (Flutter) يعمل بلا إنترنت، بلا إعلانات ولا حسابات ولا تتبّع. واجهة عربية RTL، وضع فاتح/داكن/النظام.

> **حالة المشروع بصراحة:** الكود وقاعدة البيانات جاهزان، لكن الكود **لم يُترجَم ولم تُشغَّل اختباراته بعد**
> (بيئة الإنشاء لا تحوي Flutter). والنص القرآني **مؤقت** حتى يُتحقَّق من بصمة الحزمة الرسمية وتُحسم 21 آية.
> التفاصيل في `reports/TEST_REPORT.md` و`reports/QURAN_DATA_REPORT.md`.

## المميزات
الصفحة الرئيسية (متابعة القراءة، تقدّم الحفظ، المستحق للمراجعة) · قائمة السور · قارئ بخط مجمع الملك فهد لورش ·
موضع القراءة (تلقائي/يدوي) · علامات متعددة بوصف · حفظ لكل آية (لم يبدأ/قيد الحفظ/محفوظة/تحتاج مراجعة) لآية أو نطاق عابر للسور مع تراجع ·
مراجعة بنطاقات مسمّاة وجلسات وسجل · بحث (سورة+آية، اسم سورة، كلمات قرآنية) · نسخ احتياطي/استعادة موثَّقان.

## بنية البيانات
- `assets/data/quran_warsh.db`: قاعدة **مرجعية للقراءة فقط**، تُقارَن بصمتها بنسخة الأصول عند كل تشغيل.
- `user_data.db`: بيانات المستخدم فقط. النسخة الاحتياطية لا تحوي نص القرآن ولا يمكنها تغييره.
- معرّف الآية الثابت = `السورة × 1000 + الآية`.

## الطريقة الأسهل: بناء APK عبر GitHub Actions (من الهاتف أو الحاسوب)
1. أنشئ مستودعاً خاصاً على GitHub وارفع محتويات هذا المجلد كلها (بما فيها `.github` و`sources`).
2. من تبويب **Actions** ← `build-apk` ← **Run workflow** (يعمل تلقائياً أيضاً عند كل رفع).
3. بعد الانتهاء افتح التشغيل ونزّل Artifact باسم `quran-warsh-apk` (ملف `app-release.apk`) وArtifact باسم `logs`.
4. **افتح `logs/flutter_test.txt` و`logs/analyze.txt` وتأكد من النتائج** قبل الاعتماد على التطبيق. إن ظهر خطأ، أرسله لي وأصلحه.
5. على أندرويد: انقل الملف وافتحه، واسمح بالتثبيت من مصدر غير معروف لهذا الملف فقط.

## البناء على Windows
1. ثبّت [Flutter 3.27.4](https://docs.flutter.dev/release/archive) وAndroid Studio (يثبّت Android SDK)، ثم `flutter doctor --android-licenses`.
2. في مجلد المشروع:
   ```
   flutter create . --platforms=android --project-name quran_warsh --org org.quranwarsh
   del test\widget_test.dart
   flutter pub get
   flutter analyze
   flutter test
   flutter build apk --release
   ```
   (`flutter test` يحتاج مكتبة SQLite في النظام؛ في Windows ضع `sqlite3.dll` في مسار PATH أو شغّل الاختبارات في CI.)
3. الناتج: `build\app\outputs\flutter-apk\app-release.apk`. للتشغيل على جهاز موصول: `flutter run`.
4. عدّل اسم التطبيق في `android/app/src/main/AndroidManifest.xml` (`android:label`) إن أردت، ولا تُضف صلاحية INTERNET.

## أدوات التحقق (بايثون، بلا تثبيت)
```
python3 -I tools/verify_dataset.py --db assets/data/quran_warsh.db \
  --layout-zip sources/kfgqpc/UthmanicWarsh_v2-1.zip --qws-json sources/quran_ws/warsh.json --out reports/quran_validation
python3 -I tools/sql_smoke_test.py
python3 -I tools/dart_static_check.py
```
(الأولى تنتهي برمز 1 عمداً ما دامت 21 آية غير محسومة.)

## إعادة بناء القاعدة من المصدر
`python3 -I tools/build_dataset.py --text-zip sources/kfgqpc/UthmanicWarsh-v-3.0.zip --layout-zip sources/kfgqpc/UthmanicWarsh_v2-1.zip --out assets/data/quran_warsh.db` ثم شغّل `verify_dataset.py --stamp`.

## المتطلبات الخارجية المتبقية
1. تشغيل CI وإصلاح أي أخطاء ترجمة/اختبار تظهر.
2. تجربة التطبيق على جهاز (قائمة الفحص اليدوي في `reports/TEST_REPORT.md`).
3. مقارنة بصمة `UthmanicWarsh-v-3.0.zip` بما يُنزَّل من موقع المجمع الرسمي (يحجب الأدوات الآلية فيُنزَّل من المتصفح).
4. مراجعة مختص بالقراءات للآيات الـ 21 غير المحسومة.

## الترخيص
نص القرآن والخط من حقوق مجمع الملك فهد لطباعة المصحف الشريف ويُستخدمان وفق شروطه المنشورة (انظر `reports/QURAN_DATA_REPORT.md`). شيفرة التطبيق لك تتصرف بها.
