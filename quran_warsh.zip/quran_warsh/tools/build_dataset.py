#!/usr/bin/env python3
"""
Build the reference Quran database (Warsh 'an Nafi') from the OFFICIAL KFGQPC package.

Primary source  : UthmanicWarsh-v-3.0.zip -> UthmanicWarsh-v-3.0.docx  (text, release 2026)
Surah names     : UthmanicWarsh_v2-1.zip  -> warshData_v2-1.csv         (release 2022)

The text is copied exactly as the package writes it. Nothing is normalised,
re-ordered or corrected. Ayah boundaries come from the package's own end-of-ayah
markers (U+06DD followed by Arabic-Indic digits).

Usage:
  python3 -I tools/build_dataset.py --text-zip A.zip --layout-zip B.zip --out assets/data/quran_warsh.db
"""
import argparse
import csv
import hashlib
import io
import json
import re
import sqlite3
import os
import sys
import zipfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fold import fold, loose
import xml.etree.ElementTree as ET
from datetime import date

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
AYAH_MARK = "۝"
NBSP = " "
ARABIC_DIGITS = "٠١٢٣٤٥٦٧٨٩"
MARKER_RE = re.compile(NBSP + AYAH_MARK + "([" + ARABIC_DIGITS + "]+)")
SURAH_HEAD = "سُورَةُ"


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def arabic_to_int(s: str) -> int:
    return int("".join(str(ARABIC_DIGITS.index(c)) for c in s))


def read_docx_paragraphs(docx_bytes: bytes):
    with zipfile.ZipFile(io.BytesIO(docx_bytes)) as z:
        root = ET.fromstring(z.read("word/document.xml"))
    paras = []
    for p in root.iter(W + "p"):
        paras.append("".join(t.text or "" for t in p.iter(W + "t")))
    return paras


def parse_text(paras):
    """Return list of surahs: {number, heading, basmalah, ayahs:[(n,text)]}"""
    heads = [i for i, t in enumerate(paras) if t.startswith(SURAH_HEAD)]
    if len(heads) != 114:
        raise SystemExit(f"FATAL: expected 114 surah headings, found {len(heads)}")
    surahs = []
    for k, h in enumerate(heads):
        end = heads[k + 1] if k + 1 < len(heads) else len(paras)
        block = paras[h + 1:end]
        body = [t for t in block if AYAH_MARK in t]
        if not body:
            raise SystemExit(f"FATAL: surah {k+1} has no body paragraph")
        # A surah body may be split over several paragraphs (e.g. surah 2). That is only
        # safe when every paragraph ends exactly on an ayah marker, so no ayah crosses
        # a paragraph break. Anything else is a hard error, never silently joined.
        for t in body:
            if not re.search(MARKER_RE.pattern + r"\s*$", t):
                raise SystemExit(f"FATAL: surah {k+1}: a body paragraph does not end on an ayah marker")
        basm = [t for t in block if AYAH_MARK not in t and t.strip()]
        if len(basm) > 1:
            raise SystemExit(f"FATAL: surah {k+1} has {len(basm)} non-body paragraphs")
        text = " ".join(t.strip() for t in body)
        ayahs = []
        pos = 0
        for m in MARKER_RE.finditer(text):
            ayahs.append((arabic_to_int(m.group(1)), text[pos:m.start()].strip(" ")))
            pos = m.end()
        tail = text[pos:].strip()
        if tail:
            raise SystemExit(f"FATAL: surah {k+1} has trailing text after last ayah marker")
        surahs.append({
            "number": k + 1,
            "heading": paras[h],
            "basmalah": basm[0].strip() if basm else None,
            "ayahs": ayahs,
        })
    return surahs


def read_layout_names(layout_zip_path):
    with zipfile.ZipFile(layout_zip_path) as z:
        name = [n for n in z.namelist() if n.endswith("warshData_v2-1.csv")][0]
        raw = z.read(name).decode("utf-8-sig")
    rows = list(csv.DictReader(io.StringIO(raw)))
    names = {}
    for r in rows:
        n = int(r["sura_no"])
        names.setdefault(n, (r["sura_name_ar"].strip(), r["sura_name_en"].strip()))
    return names


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--text-zip", required=True)
    ap.add_argument("--layout-zip", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--meta-json", help="optional extra provenance (JSON file) to embed")
    a = ap.parse_args()

    with zipfile.ZipFile(a.text_zip) as z:
        member = [n for n in z.namelist() if n.endswith(".docx")][0]
        docx = z.read(member)
    paras = read_docx_paragraphs(docx)
    surahs = parse_text(paras)
    names = read_layout_names(a.layout_zip)

    if os.path.exists(a.out):
        os.remove(a.out)
    db = sqlite3.connect(a.out)
    db.executescript("""
    PRAGMA user_version = 1;
    CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE surahs (
      number INTEGER PRIMARY KEY CHECK (number BETWEEN 1 AND 114),
      name_ar TEXT NOT NULL, name_en TEXT NOT NULL, heading TEXT NOT NULL,
      basmalah TEXT, ayah_count INTEGER NOT NULL CHECK (ayah_count > 0),
      name_fold TEXT NOT NULL
    );
    CREATE TABLE ayahs (
      id INTEGER PRIMARY KEY,            -- surah * 1000 + ayah (stable id, source numbering)
      surah INTEGER NOT NULL REFERENCES surahs(number),
      ayah INTEGER NOT NULL CHECK (ayah > 0),
      text TEXT NOT NULL CHECK (length(text) > 0),
      UNIQUE (surah, ayah),
      CHECK (id = surah * 1000 + ayah)
    );
    -- search-only folded copy of each ayah (see tools/fold.py); never displayed
    CREATE TABLE ayah_search (id INTEGER PRIMARY KEY REFERENCES ayahs(id), folded TEXT NOT NULL, loose TEXT NOT NULL);
    -- per-ayah verification status, written by tools/verify_dataset.py --stamp
    CREATE TABLE verification (
      ayah_id INTEGER PRIMARY KEY REFERENCES ayahs(id),
      status TEXT NOT NULL CHECK (status IN ('verified','disputed')),
      note TEXT);
    """)
    total = 0
    digest = hashlib.sha256()
    for s in surahs:
        n = s["number"]
        ar, en = names[n]
        db.execute("INSERT INTO surahs VALUES (?,?,?,?,?,?,?)",
                   (n, ar, en, s["heading"], s["basmalah"], len(s["ayahs"]), fold(ar)))
        for ay, text in s["ayahs"]:
            db.execute("INSERT INTO ayahs VALUES (?,?,?,?)", (n * 1000 + ay, n, ay, text))
            db.execute("INSERT INTO ayah_search VALUES (?,?,?)", (n * 1000 + ay, fold(text), loose(text)))
            digest.update(f"{n}:{ay}\t{text}\n".encode("utf-8"))
            total += 1
    meta = {
        "riwayah": "Warsh 'an Nafi' (ورش عن نافع)",
        "text_package": "UthmanicWarsh-v-3.0.zip",
        "text_member": member,
        "text_package_sha256": sha256_file(a.text_zip),
        "text_release_year": "2026",
        "names_package": "UthmanicWarsh_v2-1.zip",
        "names_package_sha256": sha256_file(a.layout_zip),
        "names_release_year": "2022",
        "font": "KFGQPC Warsh Uthmanic Script (UthmanicWarsh-v-3.0.ttf)",
        "built_on": date.today().isoformat(),
        "surah_count": str(len(surahs)),
        "ayah_count": str(total),
        "ayah_text_digest_sha256": digest.hexdigest(),
        "digest_definition": "sha256 over lines 'surah:ayah<TAB>text<LF>' in mushaf order, UTF-8",
        "official_checksum_verified": "false",
        "official_checksum_note": "Package bytes were obtained from a third-party archive (quran-ws/quran-text); the publisher's own checksum could not be fetched (qurancomplex.gov.sa blocks automated access).",
    }
    if a.meta_json:
        meta.update(json.load(open(a.meta_json, encoding="utf-8")))
    db.executemany("INSERT INTO meta VALUES (?,?)", meta.items())
    db.commit()
    db.execute("VACUUM")
    db.close()
    print(f"built {a.out}: {len(surahs)} surahs, {total} ayahs, digest {digest.hexdigest()}")
    print(f"db sha256: {sha256_file(a.out)}")


if __name__ == "__main__":
    sys.exit(main())
