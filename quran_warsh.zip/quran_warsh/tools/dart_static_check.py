#!/usr/bin/env python3
"""Cheap static checks for Dart files when no Dart SDK is available (it is NOT a compiler):
bracket balance, import targets exist, unused imports, duplicate keys in const map literals,
declared-but-undefined private classes. Run: python3 -I tools/dart_static_check.py"""
import os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
files = []
for base in ("lib", "test"):
    for d, _, fs in os.walk(os.path.join(ROOT, base)):
        files += [os.path.join(d, f) for f in fs if f.endswith(".dart")]

def strip(src):
    out, i, n = [], 0, len(src)
    while i < n:
        c = src[i]
        if src.startswith("//", i):
            while i < n and src[i] != "\n": i += 1
        elif src.startswith("/*", i):
            j = src.find("*/", i + 2); i = n if j < 0 else j + 2
        elif c in "'\"":
            raw = i > 0 and src[i-1] == "r"
            triple = src.startswith(c * 3, i)
            q = c * 3 if triple else c
            i += len(q)
            while i < n:
                if not raw and src[i] == "\\": i += 2; continue
                if src.startswith(q, i): i += len(q); break
                if not triple and src[i] == "\n": break
                i += 1
            out.append('""')
        else:
            out.append(c); i += 1
    return "".join(out)

problems = 0
def bad(f, msg):
    global problems; problems += 1; print(f"{os.path.relpath(f, ROOT)}: {msg}")

top_names = {}
for f in files:
    s = open(f, encoding="utf-8").read()
    names = set(re.findall(r"^(?:abstract\s+)?(?:class|enum|mixin|extension)\s+(\w+)", s, re.M))
    names |= set(re.findall(r"^(?:const\s+|final\s+)?(?:[\w<>?,\s()]+?)\s+(\w+)\s*(?:\(|=)", s, re.M)) & set(re.findall(r"^\w[\w<>?,\s()]*\s(\w+)\(", s, re.M))
    names |= set(re.findall(r"^(?:const|final)\s+(?:\w+\s+)?(\w+)\s*=", s, re.M))
    names |= set(re.findall(r"^typedef\s+(\w+)", s, re.M))
    top_names[f] = names

for f in files:
    raw = open(f, encoding="utf-8").read()
    s = strip(raw)
    stack = []
    pairs = {")": "(", "]": "[", "}": "{"}
    line = 1
    for ch in s:
        if ch == "\n": line += 1
        if ch in "([{": stack.append((ch, line))
        elif ch in ")]}":
            if not stack or stack[-1][0] != pairs[ch]:
                bad(f, f"unbalanced '{ch}' near line {line}"); break
            stack.pop()
    else:
        if stack: bad(f, f"unclosed '{stack[-1][0]}' opened at line {stack[-1][1]}")
    for m in re.finditer(r"^import\s+'([^']+)'(?:\s+(?:as|show|hide)[^;]*)?;", raw, re.M):
        target = m.group(1)
        if target.startswith("package:quran_warsh/"):
            path = os.path.join(ROOT, "lib", target[len("package:quran_warsh/"):])
        elif target.startswith(("dart:", "package:")): continue
        else: path = os.path.normpath(os.path.join(os.path.dirname(f), target))
        if not os.path.exists(path): bad(f, f"import not found: {target}"); continue
        if " as " in m.group(0) or " show " in m.group(0): continue
        names = top_names.get(path, set())
        body = raw.replace(m.group(0), "")
        if names and not any(re.search(r"\b" + re.escape(n) + r"\b", body) for n in names):
            bad(f, f"possibly unused import: {target}")
    # duplicate keys inside const map literals of simple 'k': 'v' pairs
    for m in re.finditer(r"const\s+Map<[^>]+>\s+\w+\s*=\s*\{(.*?)\};", raw, re.S):
        keys = re.findall(r"""(?:^|,)\s*(['"][^'"]*['"])\s*:""", m.group(1))
        dup = {k for k in keys if keys.count(k) > 1}
        if dup: bad(f, f"duplicate keys in const map: {dup}")

# every class used as _Name( in a file is declared in the same file
for f in files:
    s = open(f, encoding="utf-8").read()
    used = set(re.findall(r"\b(_[A-Z]\w+)\s*\(", s))
    declared = set(re.findall(r"\bclass\s+(_[A-Z]\w+)", s)) | set(re.findall(r"\benum\s+(_[A-Z]\w+)", s))
    for u in used - declared: bad(f, f"private class used but not declared in this file: {u}")

print("files checked:", len(files), "| problems:", problems)
sys.exit(1 if problems else 0)
