#!/usr/bin/env python3
"""
Runs the real user schema and the SQL used by the Dart repositories on SQLite, to catch SQL
errors and logic errors without needing Flutter. It mirrors the repository operations
(range apply / undo / sessions / backup restore atomicity). Run:  python3 -I tools/sql_smoke_test.py
"""
import os, re, sqlite3, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
schema = open(os.path.join(ROOT, "assets/sql/user_schema.sql"), encoding="utf-8").read()
ref = sqlite3.connect(os.path.join(ROOT, "assets/data/quran_warsh.db"))

def statements(sql):
    lines = "\n".join(l for l in sql.split("\n") if not l.lstrip().startswith("--"))
    return [s.strip() for s in lines.split(";") if s.strip()]

def new_db():
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys = ON")
    for s in statements(schema):
        db.execute(s)
    return db

passed = failed = 0
def check(name, cond, detail=""):
    global passed, failed
    if cond: passed += 1; print("PASS", name)
    else: failed += 1; print("FAIL", name, detail)

now = lambda: int(time.time() * 1000)

def ids_in_range(a, b):
    return [r[0] for r in ref.execute("SELECT id FROM ayahs WHERE id BETWEEN ? AND ? ORDER BY id", (a, b))]

def apply(db, ids, status, start, end):
    """mirror of MemorizationRepo.applyToIds"""
    lo, hi = min(ids), max(ids)
    old = dict(db.execute("SELECT ayah_id, status FROM memorization WHERE ayah_id BETWEEN ? AND ?", (lo, hi)).fetchall())
    changed = [i for i in ids if (old.get(i) is None if status == "not_started" else old.get(i) == status) is False]
    if not changed: return None, 0
    cur = db.execute("INSERT INTO memorization_batches (created_at,new_status,start_id,end_id,undone) VALUES (?,?,?,?,0)", (now(), status, start, end))
    bid = cur.lastrowid
    for i in changed:
        db.execute("INSERT INTO memorization_batch_items VALUES (?,?,?)", (bid, i, old.get(i)))
        if status == "not_started": db.execute("DELETE FROM memorization WHERE ayah_id = ?", (i,))
        else: db.execute("INSERT OR REPLACE INTO memorization VALUES (?,?,?)", (i, status, now()))
    db.execute("DELETE FROM memorization_batches WHERE id NOT IN (SELECT id FROM memorization_batches ORDER BY id DESC LIMIT ?)", (50,))
    return bid, len(changed)

def undo(db):
    row = db.execute("SELECT id FROM memorization_batches WHERE undone = 0 ORDER BY id DESC LIMIT 1").fetchone()
    if not row: return None
    bid = row[0]
    items = db.execute("SELECT ayah_id, old_status FROM memorization_batch_items WHERE batch_id = ?", (bid,)).fetchall()
    for i, before in items:
        if before is None: db.execute("DELETE FROM memorization WHERE ayah_id = ?", (i,))
        else: db.execute("INSERT OR REPLACE INTO memorization VALUES (?,?,?)", (i, before, now()))
    db.execute("UPDATE memorization_batches SET undone = 1 WHERE id = ?", (bid,))
    return len(items)

# ---------------------------------------------------------------- schema
db = new_db()
tables = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
check("schema creates all tables", {"app_settings","reading_position","bookmarks","memorization","memorization_batches","memorization_batch_items","review_ranges","review_sessions","review_session_ayahs"} <= tables)
try:
    db.execute("INSERT INTO memorization VALUES (1001,'bogus',0)"); check("invalid status rejected by CHECK", False)
except sqlite3.IntegrityError: check("invalid status rejected by CHECK", True)
try:
    db.execute("INSERT INTO review_ranges (name,start_id,end_id,needs_extra,created_at,updated_at) VALUES ('x',2010,2001,0,1,1)"); check("reversed range rejected by CHECK", False)
except sqlite3.IntegrityError: check("reversed range rejected by CHECK", True)
try:
    db.execute("INSERT INTO reading_position VALUES (2,1001,'auto',1)"); check("only one reading_position row allowed", False)
except sqlite3.IntegrityError: check("only one reading_position row allowed", True)

# ---------------------------------------------------------------- ranges and undo
s2 = ref.execute("SELECT ayah_count FROM surahs WHERE number=2").fetchone()[0]
ids = ids_in_range(2010, 2020)
check("range inside surah has 11 ids", len(ids) == 11)
apply(db, ids, "learning", 2010, 2020)
check("exactly the range changed", db.execute("SELECT COUNT(*) FROM memorization").fetchone()[0] == 11 and not db.execute("SELECT 1 FROM memorization WHERE ayah_id IN (2009,2021)").fetchall())

start = 2000 + s2 - 2
ids = ids_in_range(start, 3002)
check("cross-surah range ids exact", ids == [start, start+1, start+2, 3001, 3002], ids)
apply(db, ids, "memorized", start, 3002)
per = db.execute("SELECT ayah_id / 1000 AS s, status, COUNT(*) FROM memorization GROUP BY s, status ORDER BY s").fetchall()
check("per-surah integer division groups by surah", (3, "memorized", 2) in per and (2, "memorized", 3) in per, per)

db2 = new_db()
apply(db2, [2011], "learning", 2011, 2011)
apply(db2, [5001], "memorized", 5001, 5001)
apply(db2, ids_in_range(2010, 2012), "memorized", 2010, 2012)
n = undo(db2)
st = dict(db2.execute("SELECT ayah_id, status FROM memorization").fetchall())
check("undo restores exactly (2011 back to learning, 2010/2012 removed, 5001 kept)", n == 3 and st == {2011: "learning", 5001: "memorized"}, st)
check("undo steps back one at a time then nothing", undo(db2) == 1 and undo(db2) == 1 and undo(db2) is None)

db3 = new_db()
bid, n1 = apply(db3, [1003], "memorized", 1003, 1003)
bid2, n2 = apply(db3, [1003], "memorized", 1003, 1003)
check("same state again is a no-op without a batch", n2 == 0 and bid2 is None)
for k in range(60): apply(db3, [4000 + (k % 5) + 1], "learning" if k % 2 == 0 else "memorized", 1, 1)
check("history is pruned to 50 batches", db3.execute("SELECT COUNT(*) FROM memorization_batches").fetchone()[0] <= 50)

# whole Quran range at once (performance / correctness)
db4 = new_db()
all_ids = ids_in_range(1001, 114006)
t = time.time(); apply(db4, all_ids, "memorized", 1001, 114006); dt = time.time() - t
check(f"whole-Quran range applies atomically ({len(all_ids)} ayahs, {dt:.2f}s here)", db4.execute("SELECT COUNT(*) FROM memorization").fetchone()[0] == len(all_ids) == 6214)

# ---------------------------------------------------------------- review SQL (exact strings from review_repo.dart)
RANGE_SELECT = """
    SELECT r.id, r.name, r.start_id, r.end_id, r.next_review_at, r.needs_extra,
      (SELECT s.id FROM review_sessions s WHERE s.range_id = r.id AND s.outcome = 'in_progress'
         ORDER BY s.id DESC LIMIT 1) AS in_progress_id,
      (SELECT MAX(s.finished_at) FROM review_sessions s
         WHERE s.range_id = r.id AND s.outcome = 'completed') AS last_completed
    FROM review_ranges r
"""
db5 = new_db()
db5.execute("INSERT INTO review_ranges (name,start_id,end_id,needs_extra,created_at,updated_at) VALUES ('a',2001,2004,0,1,1)")
rows = db5.execute(RANGE_SELECT + " ORDER BY r.start_id, r.id").fetchall()
check("range select with subqueries runs", len(rows) == 1 and rows[0][6] is None and rows[0][7] is None)
db5.execute("INSERT INTO review_sessions (range_id,range_name,start_id,end_id,started_at,outcome) VALUES (1,'a',2001,2004,5,'in_progress')")
check("in-progress session is reported", db5.execute(RANGE_SELECT + " WHERE r.id = ?", (1,)).fetchone()[6] == 1)
db5.execute("INSERT INTO review_session_ayahs VALUES (1,2001,'reviewed')")
db5.execute("INSERT INTO review_session_ayahs VALUES (1,2002,'needs_more')")
n = db5.execute("SELECT COUNT(*) FROM review_session_ayahs WHERE session_id = ?", (1,)).fetchone()[0]
outcome = "completed" if (n > 0 and n >= 4) else "partial"
db5.execute("UPDATE review_sessions SET outcome=?, finished_at=? WHERE id=?", (outcome, now(), 1))
check("2 of 4 ayahs reviewed -> partial, not completed", outcome == "partial" and db5.execute(RANGE_SELECT).fetchone()[7] is None)
stats = db5.execute("SELECT outcome, COUNT(*) AS n, MAX(COALESCE(finished_at, started_at)) AS last FROM review_sessions GROUP BY outcome").fetchall()
check("stats query runs", stats and stats[0][0] == "partial")
lst = db5.execute("SELECT s.id, s.range_id, s.range_name, s.start_id, s.end_id, s.started_at, s.finished_at, s.outcome, (SELECT COUNT(*) FROM review_session_ayahs a WHERE a.session_id = s.id) AS n FROM review_sessions s ORDER BY s.started_at DESC, s.id DESC LIMIT ?", (100,)).fetchall()
check("session list reports reviewed count 2", lst[0][8] == 2)
db5.execute("DELETE FROM review_ranges WHERE id = 1")
check("deleting a range keeps the session and nulls range_id", db5.execute("SELECT range_id, range_name FROM review_sessions").fetchone() == (None, "a"))
db5.execute("DELETE FROM review_sessions WHERE id = 1")
check("deleting a session cascades its ayah marks", db5.execute("SELECT COUNT(*) FROM review_session_ayahs").fetchone()[0] == 0)

# ---------------------------------------------------------------- search SQL (exact string from reference_db.dart)
import importlib.util
spec = importlib.util.spec_from_file_location("fold", os.path.join(ROOT, "tools/fold.py")); fold = importlib.util.module_from_spec(spec); spec.loader.exec_module(fold)
q = fold.loose("الرحمن الرحيم")
rows = ref.execute("SELECT a.id AS id, a.surah AS surah, a.ayah AS ayah, a.text AS text FROM ayah_search s JOIN ayahs a ON a.id = s.id WHERE s.loose LIKE ? ORDER BY a.id LIMIT ?", (f"%{q}%", 200)).fetchall()
check("word search SQL returns ayahs that contain the folded phrase", len(rows) > 0 and all(q in fold.loose(r[3]) for r in rows))
check("every search hit has id == surah*1000+ayah", all(r[0] == r[1]*1000 + r[2] for r in rows))

# ---------------------------------------------------------------- restore atomicity (transaction rollback)
db6 = new_db()
apply(db6, [1001, 1002], "memorized", 1001, 1002)
db6.commit()
try:
    db6.execute("BEGIN")
    db6.execute("DELETE FROM memorization")
    db6.execute("INSERT INTO memorization VALUES (1005,'memorized',1)")
    db6.execute("INSERT INTO memorization VALUES (1005,'memorized',1)")   # duplicate primary key -> fails
    db6.execute("COMMIT")
except sqlite3.IntegrityError:
    db6.execute("ROLLBACK")
check("a failing restore rolls everything back (user data intact)", db6.execute("SELECT COUNT(*) FROM memorization").fetchone()[0] == 2)

# ---------------------------------------------------------------- reference DB is separate and read-only capable
ro = sqlite3.connect("file:" + os.path.join(ROOT, "assets/data/quran_warsh.db") + "?mode=ro", uri=True)
try:
    ro.execute("UPDATE ayahs SET text='x' WHERE id=1001"); check("reference database refuses writes when opened read-only", False)
except sqlite3.OperationalError: check("reference database refuses writes when opened read-only", True)

print(f"\n{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
