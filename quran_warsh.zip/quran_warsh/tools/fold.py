"""
Search folding. The SAME rules are implemented in Dart (lib/logic/search_fold.dart) and the
Dart test suite checks that fold(text) equals the value stored in the reference database
for every one of the 6214 ayahs and 114 surah names.

Rules (code points):
  keep   U+0621..U+063A and U+0641..U+064A except hamza U+0621 (dropped)
  map    U+0622 U+0623 U+0625 U+0671 and U+0870..U+0882 (alef variants)  -> U+0627
         U+0624 -> U+0648     U+0626 U+0649 U+06CC U+06D2 -> U+064A
  space  space, NBSP, tab, CR, LF, thin space -> one space (RTL/LTR marks are dropped)
  drop   everything else (vowel marks, waqf signs, tatweel, small letters, dots ...)
Result has single spaces and no leading/trailing space.
loose(text) = fold(text) with U+0627 removed (second search column).
The folded text is for SEARCH ONLY. It is never displayed and never replaces Quran text.
"""

_MAP = {0x0622: 0x0627, 0x0623: 0x0627, 0x0625: 0x0627, 0x0671: 0x0627,
        0x0624: 0x0648, 0x0626: 0x064A, 0x0649: 0x064A, 0x06CC: 0x064A, 0x06D2: 0x064A}
for _cp in range(0x0870, 0x0883):
    _MAP[_cp] = 0x0627


def _is_space(cp: int) -> bool:
    return cp in (0x20, 0xA0, 0x09, 0x0A, 0x0D, 0x2009)


def fold(text: str) -> str:
    out = []
    for ch in text:
        cp = ord(ch)
        if cp in _MAP:
            out.append(chr(_MAP[cp]))
        elif (0x0622 <= cp <= 0x063A) or (0x0641 <= cp <= 0x064A):
            out.append(ch)
        elif _is_space(cp):
            out.append(" ")
        # 0x0621 (hamza) and all other characters are dropped
    s = "".join(out)
    while "  " in s:
        s = s.replace("  ", " ")
    return s.strip()


def loose(text: str) -> str:
    """fold() with every alef removed: matches 'العالمين' typed with an alef against text that
    writes the long vowel with a dagger alef (dropped by fold). Used for search only."""
    return fold(text).replace("\u0627", "")
