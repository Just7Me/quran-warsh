#!/usr/bin/env python3
"""
Quran dataset verification. Runs every mandatory check and writes a report.
It NEVER modifies the Quran text. It can write the per-ayah verification status
into the `verification` table (the only table it touches) with --stamp.

  python3 -I tools/verify_dataset.py --db assets/data/quran_warsh.db \
     --layout-zip UthmanicWarsh_v2-1.zip --qws-json warsh.json --out reports/quran_validation [--stamp]

Exit code 1 if any hard check fails.
"""
import argparse, csv, io, json, re, sqlite3, sys, unicodedata, zipfile, hashlib
from collections import Counter

# ---------------------------------------------------------------------------------------------
# ENCODING-ONLY equivalences between KFGQPC Warsh release 2026 (v3.0 docx; Arabic Extended-B
# code points) and release 2022 (v2.1 csv; older code points). Derived by character alignment
# of the two official files and kept only where the alignment is consistent over all
# occurrences and the Unicode names agree. Applied to the 2026 side ONLY, ONLY inside this
# verifier, ONLY for comparison. The stored text is never changed.
# ---------------------------------------------------------------------------------------------
ENCODING_MAP = {
    "࣌": "ۖ",        # ARABIC SMALL HIGH WORD SAH          -> small high sad-lam-alef-maksura
    "ࡰ": "اَ",  # ALEF WITH ATTACHED FATHA            -> alef + fatha
    "ࡴ": "اِ",  # ALEF WITH ATTACHED KASRA            -> alef + kasra
    "ࡲ": "اُ",  # ALEF WITH RIGHT MIDDLE STROKE       -> alef + damma
    "ࡳ": "ا۟",  # ALEF WITH LEFT MIDDLE STROKE        -> alef + small high rounded zero
    "ࡶ": "ا۬",  # ALEF WITH ATTACHED ROUND DOT ABOVE
    "ࡹ": "ا۪",  # ALEF WITH ATTACHED ROUND DOT BELOW
    "ࡸ": "ا۟",  # ALEF WITH ATTACHED LEFT ROUND DOT   -> alef + small high rounded zero (checked on 2:39;
                               #   NFC canonical ordering then places it after the vowel exactly as the 2022 file writes it)
    "ࣰ": "ٗ",        # OPEN FATHATAN
    "ࣱ": "ٞ",        # OPEN DAMMATAN
    "ࣲ": "ٖ",        # OPEN KASRATAN
    "ٜ": "۪",        # VOWEL SIGN DOT BELOW                -> empty centre low stop
    "࢈": "۟",        # RAISED ROUND DOT                    -> small high rounded zero
    "ࢇ": "۟",        # BASELINE ROUND DOT                  -> small high rounded zero
    "ۑ": "ۧ",        # YEH WITH THREE DOTS BELOW           -> small high yeh
}
# Carriers/format characters with no phonetic value, ignored when comparing:
DROP_IN_COMPARE = "ـ‏ "          # tatweel, RTL mark, NBSP
# Annotation (waqf-type) marks; the quran.ws file keeps them in a separate layer, so they are
# removed on both sides when comparing against it:
ANNOTATION_MARKS = set("ۖۗۘۙۚۛۜ۞۩࣌")
END_MARKER_RE = re.compile("[\\u00a0 ]*[\\ue000-\\uf8ff\\ufb50-\\ufdff]\\s*$")  # layout csv ayah-end glyph
ARABIC_OK = re.compile("[\\u0600-\\u06ff\\u0750-\\u077f\\u0870-\\u089f\\u08a0-\\u08ff\\ufb50-\\ufdff\\ufe70-\\ufeff\\u00a0\\u200f ]")


def nfc(s): return unicodedata.normalize("NFC", s)


def compare_form(s, map_2026=False, drop_annotations=False):
    if map_2026:
        s = "".join(ENCODING_MAP.get(c, c) for c in s)
    drop = set(DROP_IN_COMPARE) | (ANNOTATION_MARKS if drop_annotations else set())
    return nfc("".join(c for c in s if c not in drop and not c.isspace()))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", required=True)
    ap.add_argument("--layout-zip", required=True)
    ap.add_argument("--qws-json")
    ap.add_argument("--out", required=True)
    ap.add_argument("--stamp", action="store_true", help="write per-ayah status into table `verification`")
    a = ap.parse_args()

    results, diffs = [], []

    def res(i, t, ok, d, skip=False):
        results.append((i, t, "SKIP" if skip else ("PASS" if ok else "FAIL"), d))

    db = sqlite3.connect(a.db)
    surahs = db.execute("SELECT number,name_ar,name_en,ayah_count FROM surahs ORDER BY number").fetchall()
    ayahs = db.execute("SELECT id,surah,ayah,text FROM ayahs ORDER BY surah,ayah").fetchall()
    meta = dict(db.execute("SELECT key,value FROM meta").fetchall())
    names = {s[0]: s[1] for s in surahs}

    # T1
    nums = [s[0] for s in surahs]
    res("T1", "114 surahs, ordered 1..114", nums == list(range(1, 115)), f"{len(nums)} surahs")
    # T2
    by = {}
    for _id, s, n, t in ayahs: by.setdefault(s, []).append(n)
    bad = [s for s, ns in by.items() if ns != list(range(1, len(ns) + 1))]
    cnt_mismatch = [s[0] for s in surahs if len(by.get(s[0], [])) != s[3]]
    res("T2", "contiguous ayah numbers per surah, no gap/duplicate", not bad and not cnt_mismatch,
        f"bad surahs: {bad}; count mismatches vs surahs.ayah_count: {cnt_mismatch}")
    # T3
    bad3 = []
    for _id, s, n, t in ayahs:
        if not t.strip(): bad3.append((s, n, "empty")); continue
        if re.search("[A-Za-z0-9]", t): bad3.append((s, n, "latin/digit chars"))
        elif any(not ARABIC_OK.match(c) for c in t): bad3.append((s, n, "non-arabic char"))
        if re.search("lorem|test|todo|sample", t, re.I): bad3.append((s, n, "placeholder"))
    res("T3", "no empty / placeholder / non-Arabic content in ayah text", not bad3, f"{len(bad3)} offending: {bad3[:10]}")
    # T4
    bad4 = [(i, s, n) for i, s, n, _ in ayahs if i != s * 1000 + n]
    res("T4", "ayah id == surah*1000+ayah", not bad4, f"{len(bad4)} inconsistent")
    total = len(ayahs)
    res("T0", "imported totals", True, f"surahs={len(surahs)} ayahs={total}")
    h = hashlib.sha256()
    for _id, s, n, t in ayahs: h.update(f"{s}:{n}\t{t}\n".encode())
    res("T0b", "stored text digest matches recomputed", h.hexdigest() == meta.get("ayah_text_digest_sha256"), h.hexdigest())

    mine = {(s, n): t for _, s, n, t in ayahs}
    status = {k: "verified" for k in mine}      # downgraded below
    note = {}

    # T5: official KFGQPC 2022 csv (same publisher, earlier release)
    with zipfile.ZipFile(a.layout_zip) as z:
        nm = [n for n in z.namelist() if n.endswith("warshData_v2-1.csv")][0]
        rows = list(csv.DictReader(io.StringIO(z.read(nm).decode("utf-8-sig"))))
    off = {(int(r["sura_no"]), int(r["aya_no"])): END_MARKER_RE.sub("", r["aya_text"]) for r in rows}
    only_db, only_csv = sorted(set(mine) - set(off)), sorted(set(off) - set(mine))
    res("T5a", "(surah,ayah) key set equals official KFGQPC layout CSV v2-1 (2022)",
        not only_db and not only_csv, f"only in db: {only_db[:5]}; only in csv: {only_csv[:5]}")
    tierA = tierB = 0
    unresolved = []
    for k in sorted(set(mine) & set(off)):
        raw = compare_form(mine[k])
        other = compare_form(off[k])
        if raw == other: tierA += 1; continue
        if compare_form(mine[k], map_2026=True) == other: tierB += 1; continue
        unresolved.append(k)
        status[k] = "disputed"
        note[k] = "differs from the official 2022 KFGQPC release beyond documented encoding equivalences"
        diffs.append({"source": "KFGQPC v2.1 (2022) csv", "surah": k[0], "ayah": k[1],
                      "surah_name": names[k[0]], "level": "UNRESOLVED", "db_2026": mine[k], "other_2022": off[k]})
    res("T5b", "ayah text vs official KFGQPC csv v2-1 (2022)", not unresolved,
        f"identical after NFC={tierA}; identical after documented encoding map={tierB}; UNRESOLVED={len(unresolved)}")

    # T5c/d: quran.ws derived from the SAME 2026 docx: validates our parsing, not the source
    if a.qws_json:
        q = json.load(open(a.qws_json, encoding="utf-8"))
        words, ast = q["words"], q["ayah_starts"] + [len(q["words"])]
        qk = {}
        for s in q["surahs"]:
            for j in range(s["ayah_count"]):
                k = s["first_ayah"] + j
                qk[(s["number"], j + 1)] = " ".join(words[ast[k]:ast[k + 1]])
        sym = sorted(set(qk) ^ set(mine))
        res("T5c", "(surah,ayah) key set equals quran.ws warsh.json", not sym, f"symmetric difference: {sym[:5]} ({len(sym)})")
        same, dq = 0, []
        for k in sorted(set(mine) & set(qk)):
            if compare_form(mine[k], drop_annotations=True) == compare_form(qk[k], drop_annotations=True): same += 1
            else: dq.append(k)
        for k in dq:
            diffs.append({"source": "quran.ws warsh.json", "surah": k[0], "ayah": k[1], "surah_name": names[k[0]],
                          "level": "UNRESOLVED", "db_2026": mine[k], "other_qws": qk[k]})
            if status[k] == "verified": status[k] = "disputed"; note[k] = "differs from quran.ws derived text"
        res("T5d", "ayah text vs quran.ws warsh.json (annotation marks removed, NFC)", not dq,
            f"identical={same}; UNRESOLVED={len(dq)}. NOTE: quran.ws is built from the same 2026 package, so this checks our parsing, not the source itself")
    else:
        res("T5c", "compare with quran.ws", False, "no file given", skip=True)

    res("T6", "render check of Uthmani text, diacritics, ayah marks on Android light/dark", False,
        "requires a device/emulator; NOT executed here (see test report)", skip=True)
    res("T7", "search/navigation/memorization point to correct ayah by stable id", False,
        "verified by app-level tests (see test report), not by this tool", skip=True)

    if a.stamp:
        db.executescript("""
          CREATE TABLE IF NOT EXISTS verification (
            ayah_id INTEGER PRIMARY KEY REFERENCES ayahs(id),
            status TEXT NOT NULL CHECK (status IN ('verified','disputed')),
            note TEXT);
          DELETE FROM verification;""")
        db.executemany("INSERT INTO verification VALUES (?,?,?)",
                       [(s * 1000 + n, status[(s, n)], note.get((s, n))) for (s, n) in sorted(mine)])
        disputed = sum(1 for v in status.values() if v == "disputed")
        db.execute("INSERT OR REPLACE INTO meta VALUES ('disputed_ayah_count', ?)", (str(disputed),))
        db.execute("INSERT OR REPLACE INTO meta VALUES ('verification_tool', 'tools/verify_dataset.py')")
        db.commit()

    hard_fail = [r for r in results if r[2] == "FAIL"]
    json.dump({"meta": meta, "results": results, "differences": diffs}, open(a.out + ".json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    with open(a.out + ".md", "w", encoding="utf-8") as f:
        f.write("# تقرير صحة بيانات القرآن (ورش عن نافع)\n\n## المصدر\n")
        for k in ["riwayah", "text_package", "text_package_sha256", "text_release_year", "names_package", "names_package_sha256",
                  "font", "built_on", "surah_count", "ayah_count", "ayah_text_digest_sha256", "official_checksum_verified", "official_checksum_note"]:
            f.write(f"- **{k}**: {meta.get(k)}\n")
        f.write("\n## نتائج الاختبارات\n\n| # | الاختبار | النتيجة | التفاصيل |\n|---|---|---|---|\n")
        for i, t, st, d in results: f.write(f"| {i} | {t} | {st} | {d} |\n")
        f.write(f"\n## الآيات غير المحسومة ({len(diffs)} سجل)\n\n")
        for src, n in Counter(d["source"] for d in diffs).items(): f.write(f"- {src}: {n}\n")
        f.write("\nالقائمة الكاملة في ملف JSON المرافق. أول 60:\n\n")
        for d in diffs[:60]: f.write(f"- {d['surah_name']} ({d['surah']}) آية {d['ayah']} — {d['source']}\n")
    print(open(a.out + ".md", encoding="utf-8").read())
    return 1 if hard_fail else 0


if __name__ == "__main__":
    sys.exit(main())
