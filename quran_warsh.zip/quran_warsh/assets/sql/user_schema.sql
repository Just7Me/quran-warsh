-- User data schema (version 1). Lives in its OWN database file, separate from the read-only
-- Quran reference database, so no user operation or backup restore can touch the Quran text.
-- Ayahs are referenced ONLY by the stable id surah*1000+ayah (source numbering).
-- Keep statements separated by a semicolon at the end of a line. No semicolons inside comments.

CREATE TABLE app_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE reading_position (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  ayah_id INTEGER NOT NULL,
  source TEXT NOT NULL CHECK (source IN ('auto','manual')),
  updated_at INTEGER NOT NULL
);

CREATE TABLE bookmarks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ayah_id INTEGER NOT NULL,
  note TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE INDEX idx_bookmarks_ayah ON bookmarks(ayah_id);

-- Memorization state per ayah. The state not_started is the ABSENCE of a row.
CREATE TABLE memorization (
  ayah_id INTEGER PRIMARY KEY,
  status TEXT NOT NULL CHECK (status IN ('learning','memorized','needs_review')),
  updated_at INTEGER NOT NULL
);

-- Undo history for memorization changes. One batch per user action.
CREATE TABLE memorization_batches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at INTEGER NOT NULL,
  new_status TEXT NOT NULL CHECK (new_status IN ('not_started','learning','memorized','needs_review')),
  start_id INTEGER NOT NULL,
  end_id INTEGER NOT NULL,
  undone INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE memorization_batch_items (
  batch_id INTEGER NOT NULL REFERENCES memorization_batches(id) ON DELETE CASCADE,
  ayah_id INTEGER NOT NULL,
  old_status TEXT,
  PRIMARY KEY (batch_id, ayah_id)
);

-- Named ranges the user wants to review.
CREATE TABLE review_ranges (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  start_id INTEGER NOT NULL,
  end_id INTEGER NOT NULL,
  next_review_at INTEGER,
  needs_extra INTEGER NOT NULL DEFAULT 0 CHECK (needs_extra IN (0,1)),
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  CHECK (start_id <= end_id)
);

-- One row per review session. outcome: in_progress, completed (whole range done), partial (part only).
CREATE TABLE review_sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  range_id INTEGER REFERENCES review_ranges(id) ON DELETE SET NULL,
  range_name TEXT NOT NULL,
  start_id INTEGER NOT NULL,
  end_id INTEGER NOT NULL,
  started_at INTEGER NOT NULL,
  finished_at INTEGER,
  outcome TEXT NOT NULL CHECK (outcome IN ('in_progress','completed','partial'))
);

CREATE INDEX idx_sessions_range ON review_sessions(range_id);

CREATE TABLE review_session_ayahs (
  session_id INTEGER NOT NULL REFERENCES review_sessions(id) ON DELETE CASCADE,
  ayah_id INTEGER NOT NULL,
  result TEXT NOT NULL CHECK (result IN ('reviewed','needs_more')),
  PRIMARY KEY (session_id, ayah_id)
);
