import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:quran_warsh/data/backup_service.dart';
import 'package:quran_warsh/data/models.dart';
import 'package:quran_warsh/data/services.dart';

import 'helpers.dart';

/// Rebuilds a backup file after the test edited its data, with a correct checksum, so the test
/// reaches the content checks and not only the checksum check.
String reseal(Map<String, Object?> file) {
  final data = file['data'];
  file['checksum_sha256'] = sha256.convert(utf8.encode(jsonEncode(data))).toString();
  return jsonEncode(file);
}

Map<String, Object?> decode(String json) => jsonDecode(json) as Map<String, Object?>;

void main() {
  late Services sv;

  setUp(() async {
    sv = await openServices();
  });

  tearDown(() async {
    await sv.userDb.close();
    await sv.reference.close();
  });

  Future<void> fill() async {
    await sv.settings.set('theme_mode', 'dark');
    await sv.settings.set('font_size', '34');
    await sv.position.setManual(2255);
    await sv.bookmarks.add(2255, note: 'علامة ١');
    await sv.bookmarks.add(18001);
    final ids = await sv.reference.idsInRange(2010, 2020);
    await sv.memorization.applyToIds(ids: ids, status: MemStatus.memorized, startId: 2010, endId: 2020);
    final rid = await sv.review.createRange(name: 'مراجعة', startId: 2001, endId: 2010);
    final sid = await sv.review.startOrResume((await sv.review.getRange(rid))!);
    await sv.review.markAyah(sessionId: sid, ayahId: 2003, needsMore: true);
    await sv.review.finishSession(sessionId: sid, totalAyahs: 10);
  }

  test('export contains only ids and the user own notes, never Quran text', () async {
    await fill();
    final json = await sv.backup.exportJson();
    final f = decode(json);
    final data = f['data'] as Map<String, Object?>;
    final text = (await sv.reference.ayahById(2255))!.text;
    expect(json.contains(text), false);
    for (final section in data.values) {
      for (final row in section as List) {
        expect((row as Map).containsKey('text'), false);
      }
    }
    expect(f['format'], BackupService.format);
    expect(f['reference_text_digest'], sv.reference.meta['ayah_text_digest_sha256']);
  });

  test('round trip: export, wipe, restore gives identical data', () async {
    await fill();
    final before = await sv.backup.exportJson();
    // wipe everything the user has
    await sv.userDb.db.transaction((txn) async {
      for (final t in [
        'review_session_ayahs', 'review_sessions', 'review_ranges', 'memorization_batch_items',
        'memorization_batches', 'memorization', 'bookmarks', 'reading_position', 'app_settings'
      ]) {
        await txn.delete(t);
      }
    });
    expect((await sv.memorization.counts())[MemStatus.memorized], 0);

    await sv.backup.restore(before);
    final after = await sv.backup.exportJson();
    final a = decode(before)['data'];
    final b = decode(after)['data'];
    expect(jsonEncode(b), jsonEncode(a));
    expect((await sv.memorization.counts())[MemStatus.memorized], 11);
    expect((await sv.position.get())!.ayahId, 2255);
    expect(await sv.settings.get('theme_mode'), 'dark');
  });

  test('restore returns a snapshot of the data that was replaced', () async {
    await fill();
    final backup = await sv.backup.exportJson();
    await sv.memorization.setSingle(5001, MemStatus.learning);
    final safety = await sv.backup.restore(backup);
    final safetyData = decode(safety)['data'] as Map<String, Object?>;
    final mem = (safetyData['memorization'] as List).cast<Map>();
    expect(mem.any((r) => r['ayah_id'] == 5001), true); // the pre-restore state was kept
    expect(await sv.memorization.statusOf(5001), MemStatus.notStarted); // and replaced
  });

  test('a tampered file is rejected by the checksum and nothing changes', () async {
    await fill();
    final f = decode(await sv.backup.exportJson());
    final data = f['data'] as Map<String, Object?>;
    ((data['memorization'] as List).first as Map)['status'] = 'learning'; // edit without resealing
    await sv.memorization.setSingle(7001, MemStatus.learning);
    final before = await sv.backup.exportJson();
    await expectLater(sv.backup.restore(jsonEncode(f)), throwsA(isA<BackupException>()));
    expect(jsonEncode(decode(await sv.backup.exportJson())['data']), jsonEncode(decode(before)['data']));
  });

  test('garbage, wrong format, wrong version and unknown top-level fields are rejected', () async {
    await fill();
    await expectLater(sv.backup.inspect('not json'), throwsA(isA<BackupException>()));
    await expectLater(sv.backup.inspect('[]'), throwsA(isA<BackupException>()));
    final base = decode(await sv.backup.exportJson());

    final wrongFormat = Map<String, Object?>.from(base)..['format'] = 'other';
    await expectLater(sv.backup.inspect(reseal(wrongFormat)), throwsA(isA<BackupException>()));

    final wrongVersion = Map<String, Object?>.from(base)..['version'] = 99;
    await expectLater(sv.backup.inspect(reseal(wrongVersion)), throwsA(isA<BackupException>()));

    final extra = Map<String, Object?>.from(base)..['quran_text'] = 'x';
    await expectLater(sv.backup.inspect(reseal(extra)), throwsA(isA<BackupException>()));
  });

  test('a backup cannot carry Quran text: unknown fields are refused even with a valid checksum', () async {
    await fill();
    final f = decode(await sv.backup.exportJson());
    final data = f['data'] as Map<String, Object?>;
    ((data['bookmarks'] as List).first as Map)['text'] = 'نص مدسوس';
    await expectLater(sv.backup.restore(reseal(f)), throwsA(isA<BackupException>()));

    final f2 = decode(await sv.backup.exportJson());
    (f2['data'] as Map<String, Object?>)['ayahs'] = [
      {'id': 1001, 'text': 'x'}
    ];
    await expectLater(sv.backup.restore(reseal(f2)), throwsA(isA<BackupException>()));
  });

  test('an ayah that does not exist in the Quran database is refused and nothing is changed', () async {
    await fill();
    final good = await sv.backup.exportJson();
    final f = decode(good);
    final data = f['data'] as Map<String, Object?>;
    ((data['memorization'] as List).first as Map)['ayah_id'] = 2999; // surah 2 has no ayah 999
    await sv.memorization.setSingle(9001, MemStatus.learning);
    final before = jsonEncode(decode(await sv.backup.exportJson())['data']);
    await expectLater(sv.backup.restore(reseal(f)), throwsA(isA<BackupException>()));
    expect(jsonEncode(decode(await sv.backup.exportJson())['data']), before);
  });

  test('invalid statuses, reversed ranges, duplicate ayahs and foreign keys are refused', () async {
    await fill();
    final base = await sv.backup.exportJson();

    Future<void> expectRejected(void Function(Map<String, Object?> data) edit) async {
      final f = decode(base);
      edit(f['data'] as Map<String, Object?>);
      await expectLater(sv.backup.inspect(reseal(f)), throwsA(isA<BackupException>()));
    }

    await expectRejected((d) => ((d['memorization'] as List).first as Map)['status'] = 'done');
    await expectRejected((d) => ((d['memorization'] as List).first as Map)['status'] = 'not_started');
    await expectRejected((d) => (d['memorization'] as List).add(Map.from((d['memorization'] as List).first as Map)));
    await expectRejected((d) {
      final r = (d['review_ranges'] as List).first as Map;
      final s = r['start_id'];
      r['start_id'] = r['end_id'];
      r['end_id'] = s;
    });
    await expectRejected((d) => ((d['review_session_ayahs'] as List).first as Map)['session_id'] = 12345);
    await expectRejected((d) => ((d['review_session_ayahs'] as List).first as Map)['ayah_id'] = 3001); // outside the session range
    await expectRejected((d) => ((d['settings'] as List).first as Map)['value'] = 'purple');
    await expectRejected((d) => (d['position'] as List).add({'ayah_id': 1001, 'source': 'auto', 'updated_at': 1}));
    await expectRejected((d) => ((d['bookmarks'] as List).first as Map)['note'] = 'x' * 501);
  });

  test('inspect reports what the file contains without changing anything', () async {
    await fill();
    final s = await sv.backup.inspect(await sv.backup.exportJson());
    expect(s.bookmarks, 2);
    expect(s.memorization, 12); // 11 in the range plus the needs_review mark from the session
    expect(s.reviewRanges, 1);
    expect(s.reviewSessions, 1);
    expect(s.hasPosition, true);
  });

  test('the reference database is never touched by a restore', () async {
    await fill();
    final digestBefore = sv.reference.meta['ayah_text_digest_sha256'];
    final textBefore = (await sv.reference.ayahById(2255))!.text;
    await sv.backup.restore(await sv.backup.exportJson());
    expect(sv.reference.meta['ayah_text_digest_sha256'], digestBefore);
    expect((await sv.reference.ayahById(2255))!.text, textBefore);
    expect(sv.reference.totalAyahs, 6214);
  });
}
