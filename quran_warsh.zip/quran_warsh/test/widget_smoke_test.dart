import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:quran_warsh/main.dart';
import 'package:quran_warsh/state/app_state.dart';
import 'package:quran_warsh/ui/shell.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';

import 'helpers.dart';

/// Real database I/O does not run inside the fake-async test zone, so waits go through runAsync.
Future<void> settle(WidgetTester tester) async {
  for (var i = 0; i < 6; i++) {
    await tester.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 120)));
    await tester.pump(const Duration(milliseconds: 50));
  }
}

void main() {
  testWidgets('app opens in Arabic RTL, reader opens, light and dark themes both build', (tester) async {
    late AppState state;
    await tester.runAsync(() async {
      final sv = await openServices();
      state = AppState(sv);
      await state.load();
    });

    await tester.pumpWidget(
      ChangeNotifierProvider<AppState>.value(value: state, child: const QuranApp()),
    );
    await settle(tester);

    expect(find.byType(Shell), findsOneWidget);
    expect(Directionality.of(tester.element(find.byType(Shell))), TextDirection.rtl);
    expect(find.text('ابدأ القراءة'), findsOneWidget);

    // open the reader on surah 1
    await tester.tap(find.text('ابدأ القراءة'));
    await settle(tester);
    expect(find.byType(ScrollablePositionedList), findsOneWidget);
    expect(tester.takeException(), isNull);

    // dark theme
    await tester.runAsync(() => state.setThemeMode(ThemeMode.dark));
    await settle(tester);
    expect(Theme.of(tester.element(find.byType(ScrollablePositionedList))).brightness, Brightness.dark);
    expect(tester.takeException(), isNull);

    // light theme
    await tester.runAsync(() => state.setThemeMode(ThemeMode.light));
    await settle(tester);
    expect(Theme.of(tester.element(find.byType(ScrollablePositionedList))).brightness, Brightness.light);
    expect(tester.takeException(), isNull);
  });
}
