import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:path/path.dart' as p;
import 'package:quran_warsh/data/models.dart';
import 'package:quran_warsh/data/services.dart';
import 'package:quran_warsh/data/user_db.dart';

import 'helpers.dart';

void main() {
  late Services sv;

  setUp(() async {
    sv = await openServices();
  });

  tearDown(() async {
    await sv.userDb.close();
    await sv.reference.close();
  });

  group('reading position', () {
    test('no position at first, manual position is stored', () async {
      expect(await sv.position.get(), isNull);
      await sv.position.setManual(2255);
      final pos = await sv.position.get();
      expect(pos!.ayahId, 2255);
      expect(pos.manual, true);
    });

    test('auto save moves an auto position and ignores identical saves', () async {
      expect(await sv.position.saveAuto(2001), true);
      expect(await sv.position.saveAuto(2001), false);
      expect(await sv.position.saveAuto(2010), true);
      expect((await sv.position.get())!.ayahId, 2010);
      expect((await sv.position.get())!.manual, false);
    });

    test('auto save never moves a manual position backwards, but reading past it moves forward', () async {
      await sv.position.setManual(2100);
      expect(await sv.position.saveAuto(2050), false); // browsing earlier text
      expect((await sv.position.get())!.ayahId, 2100);
      expect((await sv.position.get())!.manual, true);
      expect(await sv.position.saveAuto(2150), true); // read further
      expect((await sv.position.get())!.ayahId, 2150);
    });
  });

  group('bookmarks', () {
    test('several bookmarks, optional note, edit, delete, jump data', () async {
      final a = await sv.bookmarks.add(2255, note: '  وصلت هنا في قراءة المساء  ');
      final b = await sv.bookmarks.add(2255); // second bookmark on the same ayah
      final c = await sv.bookmarks.add(18001, note: '');
      var list = await sv.bookmarks.list();
      expect(list.length, 3);
      expect(list.firstWhere((x) => x.id == a).note, 'وصلت هنا في قراءة المساء');
      expect(list.firstWhere((x) => x.id == b).note, isNull);
      expect(list.firstWhere((x) => x.id == c).note, isNull); // empty note stored as null

      await sv.bookmarks.updateNote(b, 'ملاحظة جديدة');
      list = await sv.bookmarks.list();
      expect(list.firstWhere((x) => x.id == b).note, 'ملاحظة جديدة');

      expect((await sv.bookmarks.forSurah(2)).length, 2);
      expect((await sv.bookmarks.forSurah(18)).length, 1);

      await sv.bookmarks.delete(a);
      expect((await sv.bookmarks.list()).length, 2);
      expect(() => sv.bookmarks.updateNote(99999, 'x'), throwsA(isA<StateError>()));
    });
  });

  group('memorization per ayah', () {
    test('single ayah changes only that ayah', () async {
      await sv.memorization.setSingle(2255, MemStatus.memorized);
      expect(await sv.memorization.statusOf(2255), MemStatus.memorized);
      expect(await sv.memorization.statusOf(2254), MemStatus.notStarted);
      expect(await sv.memorization.statusOf(2256), MemStatus.notStarted);
    });

    test('range inside one surah touches exactly the ids in the range', () async {
      final ids = await sv.reference.idsInRange(2010, 2020);
      expect(ids.length, 11);
      final res = await sv.memorization
          .applyToIds(ids: ids, status: MemStatus.learning, startId: 2010, endId: 2020);
      expect(res.changed, 11);
      final m = await sv.memorization.statusesForSurah(2);
      expect(m.length, 11);
      expect(m.keys.toSet(), ids.toSet());
      expect(await sv.memorization.statusOf(2009), MemStatus.notStarted);
      expect(await sv.memorization.statusOf(2021), MemStatus.notStarted);
    });

    test('range crossing two surahs (end of 2 to start of 3) is exact', () async {
      final s2 = sv.reference.surah(2);
      final start = s2.lastId - 2;
      const end = 3002;
      final ids = await sv.reference.idsInRange(start, end);
      expect(ids, [start, start + 1, start + 2, 3001, 3002]);
      await sv.memorization.applyToIds(ids: ids, status: MemStatus.memorized, startId: start, endId: end);
      expect((await sv.memorization.statusesForSurah(2)).length, 3);
      expect((await sv.memorization.statusesForSurah(3)).length, 2);
      expect(await sv.memorization.statusOf(start - 1), MemStatus.notStarted);
      expect(await sv.memorization.statusOf(3003), MemStatus.notStarted);
    });

    test('a range spanning three surahs with a whole surah in the middle', () async {
      final last1 = sv.reference.surah(1).lastId;
      final ids = await sv.reference.idsInRange(last1, 3001);
      final expected = 1 + sv.reference.surah(2).ayahCount + 1;
      expect(ids.length, expected);
      await sv.memorization.applyToIds(ids: ids, status: MemStatus.memorized, startId: last1, endId: 3001);
      final counts = await sv.memorization.counts();
      expect(counts[MemStatus.memorized], expected);
    });

    test('changing the state of a range does not alter neighbours of other states', () async {
      await sv.memorization.setSingle(2005, MemStatus.needsReview);
      final ids = await sv.reference.idsInRange(2010, 2012);
      await sv.memorization.applyToIds(ids: ids, status: MemStatus.memorized, startId: 2010, endId: 2012);
      expect(await sv.memorization.statusOf(2005), MemStatus.needsReview);
    });

    test('undo restores previous states exactly and keeps all other data', () async {
      await sv.memorization.setSingle(2011, MemStatus.learning); // earlier state inside the range
      await sv.memorization.setSingle(5001, MemStatus.memorized); // unrelated data
      final ids = await sv.reference.idsInRange(2010, 2012);
      await sv.memorization.applyToIds(ids: ids, status: MemStatus.memorized, startId: 2010, endId: 2012);
      expect(await sv.memorization.statusOf(2011), MemStatus.memorized);

      final n = await sv.memorization.undoLast();
      expect(n, 3);
      expect(await sv.memorization.statusOf(2010), MemStatus.notStarted);
      expect(await sv.memorization.statusOf(2011), MemStatus.learning); // restored, not erased
      expect(await sv.memorization.statusOf(2012), MemStatus.notStarted);
      expect(await sv.memorization.statusOf(5001), MemStatus.memorized);
    });

    test('undo goes back one change at a time and then reports nothing to undo', () async {
      await sv.memorization.setSingle(1001, MemStatus.learning);
      await sv.memorization.setSingle(1002, MemStatus.memorized);
      expect(await sv.memorization.canUndo(), true);
      expect(await sv.memorization.undoLast(), 1);
      expect(await sv.memorization.statusOf(1002), MemStatus.notStarted);
      expect(await sv.memorization.statusOf(1001), MemStatus.learning);
      expect(await sv.memorization.undoLast(), 1);
      expect(await sv.memorization.statusOf(1001), MemStatus.notStarted);
      expect(await sv.memorization.undoLast(), isNull);
      expect(await sv.memorization.canUndo(), false);
    });

    test('setting the same state again is a no-op and records no batch', () async {
      await sv.memorization.setSingle(1003, MemStatus.memorized);
      final res = await sv.memorization.setSingle(1003, MemStatus.memorized);
      expect(res.changed, 0);
      expect(res.batchId, isNull);
    });

    test('not_started removes the row; counts and per-surah counts are computed from rows', () async {
      await sv.memorization.setSingle(1001, MemStatus.memorized);
      await sv.memorization.setSingle(2001, MemStatus.memorized);
      await sv.memorization.setSingle(2002, MemStatus.needsReview);
      await sv.memorization.setSingle(2001, MemStatus.notStarted);
      final c = await sv.memorization.counts();
      expect(c[MemStatus.memorized], 1);
      expect(c[MemStatus.needsReview], 1);
      final per = await sv.memorization.perSurah();
      expect(per.map((e) => e.surah).toList(), [1, 2]);
      expect(per[1].needsReview, 1);
      expect(await sv.memorization.idsWithStatus(MemStatus.needsReview), [2002]);
    });

    test('reading position and memorization are independent', () async {
      await sv.position.saveAuto(2050);
      expect(await sv.memorization.statusOf(2050), MemStatus.notStarted);
      expect((await sv.memorization.counts())[MemStatus.memorized], 0);
    });
  });

  group('review', () {
    test('range validation and CRUD', () async {
      expect(() => sv.review.createRange(name: 'x', startId: 2010, endId: 2001), throwsArgumentError);
      expect(() => sv.review.createRange(name: '  ', startId: 2001, endId: 2010), throwsArgumentError);
      final id = await sv.review.createRange(name: 'مراجعة سورة البقرة', startId: 2001, endId: 2286);
      var r = (await sv.review.getRange(id))!;
      expect(r.name, 'مراجعة سورة البقرة');
      expect(r.inProgressSessionId, isNull);
      await sv.review.updateRange(id: id, name: 'اسم جديد', endId: 2100);
      r = (await sv.review.getRange(id))!;
      expect(r.name, 'اسم جديد');
      expect(r.endId, 2100);
      await sv.review.deleteRange(id);
      expect(await sv.review.listRanges(), isEmpty);
    });

    test('due ranges use the optional next review time', () async {
      final now = DateTime.now().millisecondsSinceEpoch;
      await sv.review.createRange(name: 'a', startId: 1001, endId: 1007);
      final b = await sv.review.createRange(name: 'b', startId: 2001, endId: 2005, nextReviewAt: now - 1000);
      await sv.review.createRange(name: 'c', startId: 3001, endId: 3005, nextReviewAt: now + 86400000);
      final due = await sv.review.dueRanges(now);
      expect(due.map((r) => r.id), [b]);
    });

    test('partial review is never completed; full review is completed', () async {
      final rid = await sv.review.createRange(name: 'ن', startId: 2001, endId: 2004);
      var range = (await sv.review.getRange(rid))!;
      final sid = await sv.review.startOrResume(range);
      range = (await sv.review.getRange(rid))!;
      expect(range.inProgressSessionId, sid);
      expect(await sv.review.startOrResume(range), sid); // resumes, does not duplicate

      await sv.review.markAyah(sessionId: sid, ayahId: 2001, needsMore: false);
      await sv.review.markAyah(sessionId: sid, ayahId: 2002, needsMore: true);
      expect(await sv.memorization.statusOf(2002), MemStatus.needsReview);
      expect(await sv.memorization.statusOf(2001), MemStatus.notStarted); // reviewed does not memorize

      expect(await sv.review.finishSession(sessionId: sid, totalAyahs: 4), 'partial');
      range = (await sv.review.getRange(rid))!;
      expect(range.inProgressSessionId, isNull);
      expect(range.lastCompletedAt, isNull); // partial review is not a completed review

      final sid2 = await sv.review.startOrResume(range);
      expect(sid2, isNot(sid));
      for (final id in [2001, 2002, 2003, 2004]) {
        await sv.review.markAyah(sessionId: sid2, ayahId: id, needsMore: false);
      }
      expect(await sv.review.finishSession(sessionId: sid2, totalAyahs: 4), 'completed');
      range = (await sv.review.getRange(rid))!;
      expect(range.lastCompletedAt, isNotNull);

      final stats = await sv.review.stats();
      expect(stats.completed, 1);
      expect(stats.partial, 1);
      expect(stats.inProgress, 0);
      final sessions = await sv.review.listSessions();
      expect(sessions.length, 2);
      expect(sessions.firstWhere((s) => s.id == sid).reviewedCount, 2);
    });

    test('marking an ayah outside the session range or in a closed session is rejected', () async {
      final rid = await sv.review.createRange(name: 'ن', startId: 2001, endId: 2004);
      final sid = await sv.review.startOrResume((await sv.review.getRange(rid))!);
      expect(() => sv.review.markAyah(sessionId: sid, ayahId: 2005, needsMore: false), throwsArgumentError);
      await sv.review.finishSession(sessionId: sid, totalAyahs: 4);
      expect(() => sv.review.markAyah(sessionId: sid, ayahId: 2001, needsMore: false), throwsStateError);
    });

    test('deleting a range keeps its history', () async {
      final rid = await sv.review.createRange(name: 'ن', startId: 2001, endId: 2002);
      final sid = await sv.review.startOrResume((await sv.review.getRange(rid))!);
      await sv.review.markAyah(sessionId: sid, ayahId: 2001, needsMore: false);
      await sv.review.finishSession(sessionId: sid, totalAyahs: 2);
      await sv.review.deleteRange(rid);
      final sessions = await sv.review.listSessions();
      expect(sessions.length, 1);
      expect(sessions.first.rangeId, isNull);
      expect(sessions.first.rangeName, 'ن');
    });
  });

  group('settings and persistence', () {
    test('settings are stored and replaced', () async {
      await sv.settings.set('theme_mode', 'dark');
      await sv.settings.set('theme_mode', 'light');
      expect(await sv.settings.get('theme_mode'), 'light');
      expect(await sv.settings.get('missing'), isNull);
    });

    test('data survives closing and reopening the database file', () async {
      final dir = Directory.systemTemp.createTempSync('quran_warsh_test_');
      addTearDown(() => dir.deleteSync(recursive: true));
      final path = p.join(dir.path, 'user_data.db');
      var db = await UserDb.open(path, schemaSql());
      var s = Services(reference: sv.reference, userDb: db, directory: dir.path);
      await s.position.setManual(2255);
      await s.bookmarks.add(2255, note: 'x');
      await s.memorization.setSingle(1001, MemStatus.memorized);
      await s.settings.set('theme_mode', 'dark');
      await db.close(); // as if the app was killed after the writes were committed

      db = await UserDb.open(path, schemaSql());
      s = Services(reference: sv.reference, userDb: db, directory: dir.path);
      expect((await s.position.get())!.ayahId, 2255);
      expect((await s.bookmarks.list()).single.note, 'x');
      expect(await s.memorization.statusOf(1001), MemStatus.memorized);
      expect(await s.settings.get('theme_mode'), 'dark');
      await db.close();
    });
  });
}
