import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:quran_warsh/data/reference_db.dart';
import 'package:quran_warsh/data/services.dart';
import 'package:quran_warsh/data/user_db.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

bool _ffiReady = false;

void initFfi() {
  if (_ffiReady) return;
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
  _ffiReady = true;
}

String referencePath() => p.absolute('assets', 'data', 'quran_warsh.db');

String schemaSql() => File(p.absolute('assets', 'sql', 'user_schema.sql')).readAsStringSync();

Future<ReferenceDb> openReference() => ReferenceDb.openAtPath(referencePath());

/// Fresh in-memory user database with the real schema.
Future<UserDb> openMemoryUserDb() => UserDb.open(inMemoryDatabasePath, schemaSql());

Future<Services> openServices() async {
  initFfi();
  final ref = await openReference();
  final user = await openMemoryUserDb();
  return Services(reference: ref, userDb: user, directory: Directory.systemTemp.path);
}
