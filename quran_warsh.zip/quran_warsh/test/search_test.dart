import 'package:flutter_test/flutter_test.dart';
import 'package:quran_warsh/data/reference_db.dart';
import 'package:quran_warsh/logic/search_fold.dart';
import 'package:quran_warsh/ui/search_screen.dart';

import 'helpers.dart';

void main() {
  late ReferenceDb ref;

  setUpAll(() async {
    initFfi();
    ref = await openReference();
  });

  tearDownAll(() => ref.close());

  group('planSearch', () {
    test('surah and ayah with several spellings point to the same ayah', () {
      for (final q in ['2:255', '2 255', '2/255', '٢:٢٥٥', '٢ ٢٥٥', 'البقرة 255', 'البقرة ٢٥٥']) {
        final plan = planSearch(ref, q);
        expect(plan.error, isNull, reason: q);
        expect(plan.ayahTarget, (2, 255), reason: q);
      }
    });

    test('out of range surah or ayah gives a clear message', () {
      expect(planSearch(ref, '115:1').error, contains('رقم السورة'));
      expect(planSearch(ref, '0:1').error, contains('رقم السورة'));
      expect(planSearch(ref, '2:0').error, contains('غير موجودة'));
      final n = ref.surah(2).ayahCount;
      expect(planSearch(ref, '2:${n + 1}').error, contains('فيها'));
      expect(planSearch(ref, '2:${n + 1}').ayahTarget, isNull);
      expect(planSearch(ref, '500').error, contains('رقم السورة'));
      expect(planSearch(ref, 'البقرة 9999').error, contains('فيها'));
    });

    test('a surah number alone opens that surah', () {
      final plan = planSearch(ref, '18');
      expect(plan.surahs.single.number, 18);
    });

    test('a name finds the surah, a phrase searches words', () {
      expect(planSearch(ref, 'الكهف').surahs.map((s) => s.number), contains(18));
      final w = planSearch(ref, 'الرحمن الرحيم');
      expect(w.words, 'الرحمن الرحيم');
    });

    test('every ayah target is a real ayah in the reference database', () async {
      final plan = planSearch(ref, '2:255');
      final (s, a) = plan.ayahTarget!;
      expect(await ref.ayahById(s * 1000 + a), isNotNull);
    });
  });

  group('search results lead to the right ayah', () {
    test('each hit text really contains the searched words after folding', () async {
      for (final q in ['العالمين', 'الصراط المستقيم', 'يوم الدين']) {
        final hits = await ref.searchWords(q);
        expect(hits, isNotEmpty, reason: q);
        for (final a in hits) {
          expect(looseArabic(a.text).contains(looseArabic(q)), true, reason: '$q in ${a.surah}:${a.ayah}');
          expect(a.id, a.surah * 1000 + a.ayah);
        }
      }
    });
  });

  group('foldArabic', () {
    test('removes vowels and signs, unifies alef and yeh variants', () {
      expect(foldArabic('اِ۬لْحَمْدُ'), 'الحمد');
      expect(foldArabic('أَ'), 'ا');
      expect(foldArabic('إِ'), 'ا');
      expect(foldArabic('ٱ'), 'ا');
      expect(foldArabic('ى'), 'ي');
      expect(foldArabic('ئ'), 'ي');
      expect(foldArabic('ؤ'), 'و');
      expect(foldArabic('  بَ   سْ مِ '), 'ب س م');
      expect(foldArabic('ࡰل'), 'ال');
    });

    test('loose removes every alef', () {
      expect(looseArabic('العالمين'), 'لعلمين');
      expect(foldLatin('Al-Baqarah'), 'al baqarah');
    });
  });
}
