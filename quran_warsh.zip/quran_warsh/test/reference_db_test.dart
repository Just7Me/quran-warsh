import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:quran_warsh/data/reference_db.dart';
import 'package:quran_warsh/logic/search_fold.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'helpers.dart';

void main() {
  late ReferenceDb ref;
  late Database raw;

  setUpAll(() async {
    initFfi();
    ref = await openReference();
    raw = await openDatabase(referencePath(), readOnly: true, singleInstance: false);
  });

  tearDownAll(() async {
    await ref.close();
    await raw.close();
  });

  test('T1 114 surahs in order 1..114', () {
    expect(ref.surahs.length, 114);
    for (var i = 0; i < 114; i++) {
      expect(ref.surahs[i].number, i + 1);
    }
  });

  test('T2 ayah numbers are contiguous in every surah and match ayah_count', () async {
    for (final s in ref.surahs) {
      final ayahs = await ref.ayahsOfSurah(s.number);
      expect(ayahs.length, s.ayahCount, reason: 'surah ${s.number}');
      for (var i = 0; i < ayahs.length; i++) {
        expect(ayahs[i].ayah, i + 1, reason: 'surah ${s.number}');
        expect(ayahs[i].surah, s.number);
        expect(ayahs[i].id, s.number * 1000 + i + 1);
      }
    }
  });

  test('T3 no empty ayah text and no Latin letters or digits in any ayah', () async {
    final rows = await raw.rawQuery('SELECT id, text FROM ayahs');
    expect(rows.length, ref.totalAyahs);
    final latin = RegExp(r'[A-Za-z0-9]');
    for (final r in rows) {
      final t = r['text']! as String;
      expect(t.trim().isNotEmpty, true, reason: 'ayah ${r['id']}');
      expect(latin.hasMatch(t), false, reason: 'ayah ${r['id']}');
    }
  });

  test('stored text digest equals the digest recomputed from the database', () async {
    final rows = await raw.rawQuery('SELECT surah, ayah, text FROM ayahs ORDER BY surah, ayah');
    final buf = StringBuffer();
    for (final r in rows) {
      buf.write('${r['surah']}:${r['ayah']}\t${r['text']}\n');
    }
    final digest = sha256.convert(utf8.encode(buf.toString())).toString();
    expect(digest, ref.meta['ayah_text_digest_sha256']);
  });

  test('source provenance is recorded and honest about the unverified official checksum', () {
    expect(ref.meta['text_package'], 'UthmanicWarsh-v-3.0.zip');
    expect(ref.meta['text_package_sha256'], hasLength(64));
    expect(ref.meta['official_checksum_verified'], 'false');
    expect(ref.meta['riwayah'], contains('Warsh'));
  });

  test('disputed ayahs are recorded in the database and match the counter', () {
    expect(ref.disputed.length, int.parse(ref.meta['disputed_ayah_count']!));
    expect(ref.disputed.length, greaterThan(0));
    for (final id in ref.disputed.keys) {
      expect(ref.isValidId(id), true);
    }
  });

  test('isValid / ordinalOf / range across surahs', () async {
    expect(ref.isValid(1, 1), true);
    expect(ref.isValid(1, ref.surah(1).ayahCount + 1), false);
    expect(ref.isValid(0, 1), false);
    expect(ref.isValid(115, 1), false);
    expect(ref.ordinalOf(1001), 1);
    final last = ref.surah(114).lastId;
    expect(ref.ordinalOf(last), ref.totalAyahs);

    final s2 = ref.surah(2);
    final ids = await ref.idsInRange(s2.lastId - 1, 3001 + 1);
    expect(ids, [s2.lastId - 1, s2.lastId, 3001, 3002]);
    expect(await ref.countInRange(s2.lastId - 1, 3002), 4);
    // ordinal arithmetic agrees with the database count for a range spanning two surahs
    expect(ref.ordinalOf(3002) - ref.ordinalOf(s2.lastId - 1) + 1, 4);
  });

  test('search fold in Dart equals the folded values stored in the database (every ayah)', () async {
    final rows = await raw.rawQuery(
        'SELECT a.id AS id, a.text AS text, s.folded AS folded, s.loose AS loose '
        'FROM ayahs a JOIN ayah_search s ON s.id = a.id');
    expect(rows.length, ref.totalAyahs);
    for (final r in rows) {
      final t = r['text']! as String;
      expect(foldArabic(t), r['folded'], reason: 'folded ayah ${r['id']}');
      expect(looseArabic(t), r['loose'], reason: 'loose ayah ${r['id']}');
    }
  });

  test('surah name folds equal the stored name_fold', () {
    for (final s in ref.surahs) {
      expect(foldArabic(s.nameAr), s.nameFold, reason: 'surah ${s.number}');
    }
  });

  test('word search returns real ayahs that really contain the folded words', () async {
    final hits = await ref.searchWords('الرحمن الرحيم');
    expect(hits, isNotEmpty);
    for (final a in hits) {
      expect(looseArabic(a.text).contains(looseArabic('الرحمن الرحيم')), true);
      final again = await ref.ayahById(a.id);
      expect(again!.text, a.text);
    }
    expect(await ref.searchWords('ا'), isEmpty); // too short
  });

  test('surah name search works in Arabic and in transliteration', () {
    expect(ref.searchSurahs('البقرة').map((s) => s.number), contains(2));
    expect(ref.searchSurahs('baqarah').map((s) => s.number), contains(2));
    expect(ref.searchSurahs('xyzxyz'), isEmpty);
  });
}
