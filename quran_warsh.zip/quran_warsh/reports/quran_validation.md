# تقرير صحة بيانات القرآن (ورش عن نافع)

## المصدر
- **riwayah**: Warsh 'an Nafi' (ورش عن نافع)
- **text_package**: UthmanicWarsh-v-3.0.zip
- **text_package_sha256**: 68e2f1c7a504a8dde797346fd63054c744e073917380f9c56360306b28907e37
- **text_release_year**: 2026
- **names_package**: UthmanicWarsh_v2-1.zip
- **names_package_sha256**: d847a7e7002dfbed5d28db6684fd1d9c3d50b8bb63ad64cb38a46b9dad788b47
- **font**: KFGQPC Warsh Uthmanic Script (UthmanicWarsh-v-3.0.ttf)
- **built_on**: 2026-10-20
- **surah_count**: 114
- **ayah_count**: 6214
- **ayah_text_digest_sha256**: b5d021dce61246fbfaa27b2fff885e53e65fe77f76ad03666329de270164c88d
- **official_checksum_verified**: false
- **official_checksum_note**: Package bytes were obtained from a third-party archive (quran-ws/quran-text); the publisher's own checksum could not be fetched (qurancomplex.gov.sa blocks automated access).

## نتائج الاختبارات

| # | الاختبار | النتيجة | التفاصيل |
|---|---|---|---|
| T1 | 114 surahs, ordered 1..114 | PASS | 114 surahs |
| T2 | contiguous ayah numbers per surah, no gap/duplicate | PASS | bad surahs: []; count mismatches vs surahs.ayah_count: [] |
| T3 | no empty / placeholder / non-Arabic content in ayah text | PASS | 0 offending: [] |
| T4 | ayah id == surah*1000+ayah | PASS | 0 inconsistent |
| T0 | imported totals | PASS | surahs=114 ayahs=6214 |
| T0b | stored text digest matches recomputed | PASS | b5d021dce61246fbfaa27b2fff885e53e65fe77f76ad03666329de270164c88d |
| T5a | (surah,ayah) key set equals official KFGQPC layout CSV v2-1 (2022) | PASS | only in db: []; only in csv: [] |
| T5b | ayah text vs official KFGQPC csv v2-1 (2022) | FAIL | identical after NFC=160; identical after documented encoding map=6033; UNRESOLVED=21 |
| T5c | (surah,ayah) key set equals quran.ws warsh.json | PASS | symmetric difference: [] (0) |
| T5d | ayah text vs quran.ws warsh.json (annotation marks removed, NFC) | PASS | identical=6214; UNRESOLVED=0. NOTE: quran.ws is built from the same 2026 package, so this checks our parsing, not the source itself |
| T6 | render check of Uthmani text, diacritics, ayah marks on Android light/dark | SKIP | requires a device/emulator; NOT executed here (see test report) |
| T7 | search/navigation/memorization point to correct ayah by stable id | SKIP | verified by app-level tests (see test report), not by this tool |

## الآيات غير المحسومة (21 سجل)

- KFGQPC v2.1 (2022) csv: 21

القائمة الكاملة في ملف JSON المرافق. أول 60:

- البَقَرَة (2) آية 71 — KFGQPC v2.1 (2022) csv
- البَقَرَة (2) آية 139 — KFGQPC v2.1 (2022) csv
- المَائدة (5) آية 43 — KFGQPC v2.1 (2022) csv
- الأنعَام (6) آية 4 — KFGQPC v2.1 (2022) csv
- الأنعَام (6) آية 144 — KFGQPC v2.1 (2022) csv
- الأنعَام (6) آية 145 — KFGQPC v2.1 (2022) csv
- الأعرَاف (7) آية 1 — KFGQPC v2.1 (2022) csv
- التوبَة (9) آية 118 — KFGQPC v2.1 (2022) csv
- يُونس (10) آية 59 — KFGQPC v2.1 (2022) csv
- هُود (11) آية 2 — KFGQPC v2.1 (2022) csv
- يُوسُف (12) آية 110 — KFGQPC v2.1 (2022) csv
- الحِجر (15) آية 61 — KFGQPC v2.1 (2022) csv
- الأنبيَاء (21) آية 87 — KFGQPC v2.1 (2022) csv
- الأنبيَاء (21) آية 98 — KFGQPC v2.1 (2022) csv
- المؤمنُون (23) آية 44 — KFGQPC v2.1 (2022) csv
- الشعراء (26) آية 3 — KFGQPC v2.1 (2022) csv
- النَّمل (27) آية 37 — KFGQPC v2.1 (2022) csv
- الزُّخرُف (43) آية 65 — KFGQPC v2.1 (2022) csv
- النَّجم (53) آية 61 — KFGQPC v2.1 (2022) csv
- القَمَر (54) آية 41 — KFGQPC v2.1 (2022) csv
- المُجَادلة (58) آية 13 — KFGQPC v2.1 (2022) csv
